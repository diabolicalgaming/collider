﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// System.AsyncCallback
struct AsyncCallback_t74ABD1277F711E7FBDCB00E169A63DEFD39E86A2;
// System.Byte[]
struct ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8;
// System.Char[]
struct CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744;
// System.Collections.ArrayList
struct ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F;
// System.Collections.Generic.Dictionary`2<System.String,System.Int32>
struct Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1;
// System.Collections.Hashtable
struct Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82;
// System.Collections.IDictionary
struct IDictionary_tD35B9437F08BE98D1E0B295CC73C48E168CAB316;
// System.Collections.IDictionaryEnumerator
struct IDictionaryEnumerator_tFA82075E135A0ED63DE061DB58EB1B4799B3F517;
// System.Collections.IList
struct IList_t1CFF887D6A6212B2F35969C95D9FB19749BA8580;
// System.Collections.Queue
struct Queue_t2B066F5DA52AD958C3B9532F7C88339BA1427EAD;
// System.Collections.Stack
struct Stack_t7384B3BC16406A09DCD2C2D2EA591D34ACBFDBA5;
// System.DelegateData
struct DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9;
// System.Exception
struct Exception_t;
// System.IAsyncResult
struct IAsyncResult_tDA33C24465239FB383C4C2CDAAC43B9AD3CB7F05;
// System.Int32[]
struct Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074;
// System.IntPtr[]
struct IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659;
// System.MarshalByRefObject
struct MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4;
// System.Object[]
struct ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D;
// System.Reflection.MethodBase
struct MethodBase_t;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Reflection.MonoMethod
struct MonoMethod_t;
// System.Runtime.Remoting.Activation.IActivator
struct IActivator_tA609449CFC71FB3FB03376169B78DA05D8E81039;
// System.Runtime.Remoting.ChannelData
struct ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289;
// System.Runtime.Remoting.Contexts.Context
struct Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857;
// System.Runtime.Remoting.Contexts.DynamicPropertyCollection
struct DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0;
// System.Runtime.Remoting.Contexts.IDynamicMessageSink
struct IDynamicMessageSink_t8FC74B0DDD9AFA390EF842CF702CEA0B8E1038F4;
// System.Runtime.Remoting.Contexts.IDynamicProperty
struct IDynamicProperty_tCEDCBAC21437B6D146048495C2C53D328D93B7F5;
// System.Runtime.Remoting.Contexts.SynchronizationAttribute
struct SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F;
// System.Runtime.Remoting.IChannelInfo
struct IChannelInfo_t5199503CE645D94B597DA6B5289E822474449592;
// System.Runtime.Remoting.IEnvoyInfo
struct IEnvoyInfo_t09C8CB2A404F8A0810282B959C7EC4DDEEA995BD;
// System.Runtime.Remoting.IRemotingTypeInfo
struct IRemotingTypeInfo_t1BC680BFFA92334D1B1C87665D9E21DA737DBAB5;
// System.Runtime.Remoting.Identity
struct Identity_tF0CD49E50E212E64314E0241852939303E414F1C;
// System.Runtime.Remoting.Lifetime.ILease
struct ILease_tB96C8BCFA8A95A6C30A13336ABA97BD6BE9C9244;
// System.Runtime.Remoting.Lifetime.Lease/RenewalDelegate
struct RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD;
// System.Runtime.Remoting.Lifetime.LeaseManager
struct LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D;
// System.Runtime.Remoting.Messaging.ArgInfo
struct ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3;
// System.Runtime.Remoting.Messaging.AsyncResult
struct AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F;
// System.Runtime.Remoting.Messaging.CADArgHolder
struct CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120;
// System.Runtime.Remoting.Messaging.CallContextRemotingData
struct CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A;
// System.Runtime.Remoting.Messaging.ConstructionCall
struct ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82;
// System.Runtime.Remoting.Messaging.IMessage
struct IMessage_tC9586FC4B3B65966B56E30B36115F039AC0D698D;
// System.Runtime.Remoting.Messaging.IMessageCtrl
struct IMessageCtrl_t825997BD995491C738BDB275B613103675FEF991;
// System.Runtime.Remoting.Messaging.IMessageSink
struct IMessageSink_t3B360A9A9CC88FDA5F8094AAE0CA2BF917EB465C;
// System.Runtime.Remoting.Messaging.IMethodCallMessage
struct IMethodCallMessage_tE623E9915F98C2183F8EA5E8A9E203F38F741100;
// System.Runtime.Remoting.Messaging.IMethodMessage
struct IMethodMessage_t6C48CC5EC8784BB507B49DCEF7A92D8870B2DC07;
// System.Runtime.Remoting.Messaging.LogicalCallContext
struct LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394;
// System.Runtime.Remoting.Messaging.MethodCallDictionary
struct MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955;
// System.Runtime.Remoting.Messaging.MethodDictionary
struct MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D;
// System.Runtime.Remoting.Messaging.MethodReturnDictionary
struct MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66;
// System.Runtime.Remoting.Messaging.MonoMethodMessage
struct MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB;
// System.Runtime.Remoting.Messaging.ObjRefSurrogate
struct ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA;
// System.Runtime.Remoting.Messaging.RemotingSurrogate
struct RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707;
// System.Runtime.Remoting.ObjRef
struct ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E;
// System.Runtime.Remoting.Proxies.RealProxy
struct RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC;
// System.Runtime.Remoting.Proxies.RemotingProxy
struct RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC;
// System.Runtime.Remoting.ServerIdentity
struct ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C;
// System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
struct BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F;
// System.Runtime.Serialization.ISurrogateSelector
struct ISurrogateSelector_tA1E54BEB1FEBE2C4791994492E5F7E1C4E6C795C;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B;
// System.Threading.ExecutionContext
struct ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3;
// System.Threading.Mutex
struct Mutex_t439997CEED438973F1CFE782AFD9DDECBB2E1838;
// System.Threading.Thread
struct Thread_t83C301EC970792455F76D89E58140949B003EA50;
// System.Threading.Timer
struct Timer_tAB247DBC06A8C0969B6B6519866D61CFE3688FDC;
// System.Threading.WaitHandle
struct WaitHandle_t4E21379F87C00DE80B2973DCAA928C4A19D1A89E;
// System.Type
struct Type_t;
// System.Type[]
struct TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532;
// System.Void
struct Void_tDB81A15FA2AB53E2401A76B745D215397B29F783;
// System.WeakReference
struct WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C;




#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef ATTRIBUTE_T60F25EB48D5935E4C6C2BAF7F90F57A43528E469_H
#define ATTRIBUTE_T60F25EB48D5935E4C6C2BAF7F90F57A43528E469_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Attribute
struct  Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTE_T60F25EB48D5935E4C6C2BAF7F90F57A43528E469_H
#ifndef EXCEPTION_T_H
#define EXCEPTION_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.IntPtr[] System.Exception::trace_ips
	IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659* ___trace_ips_0;
	// System.Exception System.Exception::inner_exception
	Exception_t * ___inner_exception_1;
	// System.String System.Exception::message
	String_t* ___message_2;
	// System.String System.Exception::help_link
	String_t* ___help_link_3;
	// System.String System.Exception::class_name
	String_t* ___class_name_4;
	// System.String System.Exception::stack_trace
	String_t* ___stack_trace_5;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_6;
	// System.Int32 System.Exception::remote_stack_index
	int32_t ___remote_stack_index_7;
	// System.Int32 System.Exception::hresult
	int32_t ___hresult_8;
	// System.String System.Exception::source
	String_t* ___source_9;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_10;

public:
	inline static int32_t get_offset_of_trace_ips_0() { return static_cast<int32_t>(offsetof(Exception_t, ___trace_ips_0)); }
	inline IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659* get_trace_ips_0() const { return ___trace_ips_0; }
	inline IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659** get_address_of_trace_ips_0() { return &___trace_ips_0; }
	inline void set_trace_ips_0(IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659* value)
	{
		___trace_ips_0 = value;
		Il2CppCodeGenWriteBarrier((&___trace_ips_0), value);
	}

	inline static int32_t get_offset_of_inner_exception_1() { return static_cast<int32_t>(offsetof(Exception_t, ___inner_exception_1)); }
	inline Exception_t * get_inner_exception_1() const { return ___inner_exception_1; }
	inline Exception_t ** get_address_of_inner_exception_1() { return &___inner_exception_1; }
	inline void set_inner_exception_1(Exception_t * value)
	{
		___inner_exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___inner_exception_1), value);
	}

	inline static int32_t get_offset_of_message_2() { return static_cast<int32_t>(offsetof(Exception_t, ___message_2)); }
	inline String_t* get_message_2() const { return ___message_2; }
	inline String_t** get_address_of_message_2() { return &___message_2; }
	inline void set_message_2(String_t* value)
	{
		___message_2 = value;
		Il2CppCodeGenWriteBarrier((&___message_2), value);
	}

	inline static int32_t get_offset_of_help_link_3() { return static_cast<int32_t>(offsetof(Exception_t, ___help_link_3)); }
	inline String_t* get_help_link_3() const { return ___help_link_3; }
	inline String_t** get_address_of_help_link_3() { return &___help_link_3; }
	inline void set_help_link_3(String_t* value)
	{
		___help_link_3 = value;
		Il2CppCodeGenWriteBarrier((&___help_link_3), value);
	}

	inline static int32_t get_offset_of_class_name_4() { return static_cast<int32_t>(offsetof(Exception_t, ___class_name_4)); }
	inline String_t* get_class_name_4() const { return ___class_name_4; }
	inline String_t** get_address_of_class_name_4() { return &___class_name_4; }
	inline void set_class_name_4(String_t* value)
	{
		___class_name_4 = value;
		Il2CppCodeGenWriteBarrier((&___class_name_4), value);
	}

	inline static int32_t get_offset_of_stack_trace_5() { return static_cast<int32_t>(offsetof(Exception_t, ___stack_trace_5)); }
	inline String_t* get_stack_trace_5() const { return ___stack_trace_5; }
	inline String_t** get_address_of_stack_trace_5() { return &___stack_trace_5; }
	inline void set_stack_trace_5(String_t* value)
	{
		___stack_trace_5 = value;
		Il2CppCodeGenWriteBarrier((&___stack_trace_5), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_6() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_6)); }
	inline String_t* get__remoteStackTraceString_6() const { return ____remoteStackTraceString_6; }
	inline String_t** get_address_of__remoteStackTraceString_6() { return &____remoteStackTraceString_6; }
	inline void set__remoteStackTraceString_6(String_t* value)
	{
		____remoteStackTraceString_6 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_6), value);
	}

	inline static int32_t get_offset_of_remote_stack_index_7() { return static_cast<int32_t>(offsetof(Exception_t, ___remote_stack_index_7)); }
	inline int32_t get_remote_stack_index_7() const { return ___remote_stack_index_7; }
	inline int32_t* get_address_of_remote_stack_index_7() { return &___remote_stack_index_7; }
	inline void set_remote_stack_index_7(int32_t value)
	{
		___remote_stack_index_7 = value;
	}

	inline static int32_t get_offset_of_hresult_8() { return static_cast<int32_t>(offsetof(Exception_t, ___hresult_8)); }
	inline int32_t get_hresult_8() const { return ___hresult_8; }
	inline int32_t* get_address_of_hresult_8() { return &___hresult_8; }
	inline void set_hresult_8(int32_t value)
	{
		___hresult_8 = value;
	}

	inline static int32_t get_offset_of_source_9() { return static_cast<int32_t>(offsetof(Exception_t, ___source_9)); }
	inline String_t* get_source_9() const { return ___source_9; }
	inline String_t** get_address_of_source_9() { return &___source_9; }
	inline void set_source_9(String_t* value)
	{
		___source_9 = value;
		Il2CppCodeGenWriteBarrier((&___source_9), value);
	}

	inline static int32_t get_offset_of__data_10() { return static_cast<int32_t>(offsetof(Exception_t, ____data_10)); }
	inline RuntimeObject* get__data_10() const { return ____data_10; }
	inline RuntimeObject** get_address_of__data_10() { return &____data_10; }
	inline void set__data_10(RuntimeObject* value)
	{
		____data_10 = value;
		Il2CppCodeGenWriteBarrier((&____data_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTION_T_H
#ifndef MARSHALBYREFOBJECT_T05F62A8AC86E36BAE3063CA28097945DE9E179C4_H
#define MARSHALBYREFOBJECT_T05F62A8AC86E36BAE3063CA28097945DE9E179C4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MarshalByRefObject
struct  MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.ServerIdentity System.MarshalByRefObject::_identity
	ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C * ____identity_0;

public:
	inline static int32_t get_offset_of__identity_0() { return static_cast<int32_t>(offsetof(MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4, ____identity_0)); }
	inline ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C * get__identity_0() const { return ____identity_0; }
	inline ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C ** get_address_of__identity_0() { return &____identity_0; }
	inline void set__identity_0(ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C * value)
	{
		____identity_0 = value;
		Il2CppCodeGenWriteBarrier((&____identity_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MARSHALBYREFOBJECT_T05F62A8AC86E36BAE3063CA28097945DE9E179C4_H
#ifndef CHANNELDATA_T997D911D30243EF5FCD251C12F4225C983D7D289_H
#define CHANNELDATA_T997D911D30243EF5FCD251C12F4225C983D7D289_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ChannelData
struct  ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.ChannelData::Ref
	String_t* ___Ref_0;
	// System.String System.Runtime.Remoting.ChannelData::Type
	String_t* ___Type_1;
	// System.String System.Runtime.Remoting.ChannelData::Id
	String_t* ___Id_2;
	// System.String System.Runtime.Remoting.ChannelData::DelayLoadAsClientChannel
	String_t* ___DelayLoadAsClientChannel_3;
	// System.Collections.ArrayList System.Runtime.Remoting.ChannelData::_serverProviders
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ____serverProviders_4;
	// System.Collections.ArrayList System.Runtime.Remoting.ChannelData::_clientProviders
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ____clientProviders_5;
	// System.Collections.Hashtable System.Runtime.Remoting.ChannelData::_customProperties
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ____customProperties_6;

public:
	inline static int32_t get_offset_of_Ref_0() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ___Ref_0)); }
	inline String_t* get_Ref_0() const { return ___Ref_0; }
	inline String_t** get_address_of_Ref_0() { return &___Ref_0; }
	inline void set_Ref_0(String_t* value)
	{
		___Ref_0 = value;
		Il2CppCodeGenWriteBarrier((&___Ref_0), value);
	}

	inline static int32_t get_offset_of_Type_1() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ___Type_1)); }
	inline String_t* get_Type_1() const { return ___Type_1; }
	inline String_t** get_address_of_Type_1() { return &___Type_1; }
	inline void set_Type_1(String_t* value)
	{
		___Type_1 = value;
		Il2CppCodeGenWriteBarrier((&___Type_1), value);
	}

	inline static int32_t get_offset_of_Id_2() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ___Id_2)); }
	inline String_t* get_Id_2() const { return ___Id_2; }
	inline String_t** get_address_of_Id_2() { return &___Id_2; }
	inline void set_Id_2(String_t* value)
	{
		___Id_2 = value;
		Il2CppCodeGenWriteBarrier((&___Id_2), value);
	}

	inline static int32_t get_offset_of_DelayLoadAsClientChannel_3() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ___DelayLoadAsClientChannel_3)); }
	inline String_t* get_DelayLoadAsClientChannel_3() const { return ___DelayLoadAsClientChannel_3; }
	inline String_t** get_address_of_DelayLoadAsClientChannel_3() { return &___DelayLoadAsClientChannel_3; }
	inline void set_DelayLoadAsClientChannel_3(String_t* value)
	{
		___DelayLoadAsClientChannel_3 = value;
		Il2CppCodeGenWriteBarrier((&___DelayLoadAsClientChannel_3), value);
	}

	inline static int32_t get_offset_of__serverProviders_4() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ____serverProviders_4)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get__serverProviders_4() const { return ____serverProviders_4; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of__serverProviders_4() { return &____serverProviders_4; }
	inline void set__serverProviders_4(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		____serverProviders_4 = value;
		Il2CppCodeGenWriteBarrier((&____serverProviders_4), value);
	}

	inline static int32_t get_offset_of__clientProviders_5() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ____clientProviders_5)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get__clientProviders_5() const { return ____clientProviders_5; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of__clientProviders_5() { return &____clientProviders_5; }
	inline void set__clientProviders_5(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		____clientProviders_5 = value;
		Il2CppCodeGenWriteBarrier((&____clientProviders_5), value);
	}

	inline static int32_t get_offset_of__customProperties_6() { return static_cast<int32_t>(offsetof(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289, ____customProperties_6)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get__customProperties_6() const { return ____customProperties_6; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of__customProperties_6() { return &____customProperties_6; }
	inline void set__customProperties_6(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		____customProperties_6 = value;
		Il2CppCodeGenWriteBarrier((&____customProperties_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHANNELDATA_T997D911D30243EF5FCD251C12F4225C983D7D289_H
#ifndef CONFIGHANDLER_TF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_H
#define CONFIGHANDLER_TF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ConfigHandler
struct  ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7  : public RuntimeObject
{
public:
	// System.Collections.ArrayList System.Runtime.Remoting.ConfigHandler::typeEntries
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ___typeEntries_0;
	// System.Collections.ArrayList System.Runtime.Remoting.ConfigHandler::channelInstances
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ___channelInstances_1;
	// System.Runtime.Remoting.ChannelData System.Runtime.Remoting.ConfigHandler::currentChannel
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289 * ___currentChannel_2;
	// System.Collections.Stack System.Runtime.Remoting.ConfigHandler::currentProviderData
	Stack_t7384B3BC16406A09DCD2C2D2EA591D34ACBFDBA5 * ___currentProviderData_3;
	// System.String System.Runtime.Remoting.ConfigHandler::currentClientUrl
	String_t* ___currentClientUrl_4;
	// System.String System.Runtime.Remoting.ConfigHandler::appName
	String_t* ___appName_5;
	// System.String System.Runtime.Remoting.ConfigHandler::currentXmlPath
	String_t* ___currentXmlPath_6;
	// System.Boolean System.Runtime.Remoting.ConfigHandler::onlyDelayedChannels
	bool ___onlyDelayedChannels_7;

public:
	inline static int32_t get_offset_of_typeEntries_0() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___typeEntries_0)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get_typeEntries_0() const { return ___typeEntries_0; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of_typeEntries_0() { return &___typeEntries_0; }
	inline void set_typeEntries_0(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		___typeEntries_0 = value;
		Il2CppCodeGenWriteBarrier((&___typeEntries_0), value);
	}

	inline static int32_t get_offset_of_channelInstances_1() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___channelInstances_1)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get_channelInstances_1() const { return ___channelInstances_1; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of_channelInstances_1() { return &___channelInstances_1; }
	inline void set_channelInstances_1(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		___channelInstances_1 = value;
		Il2CppCodeGenWriteBarrier((&___channelInstances_1), value);
	}

	inline static int32_t get_offset_of_currentChannel_2() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___currentChannel_2)); }
	inline ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289 * get_currentChannel_2() const { return ___currentChannel_2; }
	inline ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289 ** get_address_of_currentChannel_2() { return &___currentChannel_2; }
	inline void set_currentChannel_2(ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289 * value)
	{
		___currentChannel_2 = value;
		Il2CppCodeGenWriteBarrier((&___currentChannel_2), value);
	}

	inline static int32_t get_offset_of_currentProviderData_3() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___currentProviderData_3)); }
	inline Stack_t7384B3BC16406A09DCD2C2D2EA591D34ACBFDBA5 * get_currentProviderData_3() const { return ___currentProviderData_3; }
	inline Stack_t7384B3BC16406A09DCD2C2D2EA591D34ACBFDBA5 ** get_address_of_currentProviderData_3() { return &___currentProviderData_3; }
	inline void set_currentProviderData_3(Stack_t7384B3BC16406A09DCD2C2D2EA591D34ACBFDBA5 * value)
	{
		___currentProviderData_3 = value;
		Il2CppCodeGenWriteBarrier((&___currentProviderData_3), value);
	}

	inline static int32_t get_offset_of_currentClientUrl_4() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___currentClientUrl_4)); }
	inline String_t* get_currentClientUrl_4() const { return ___currentClientUrl_4; }
	inline String_t** get_address_of_currentClientUrl_4() { return &___currentClientUrl_4; }
	inline void set_currentClientUrl_4(String_t* value)
	{
		___currentClientUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___currentClientUrl_4), value);
	}

	inline static int32_t get_offset_of_appName_5() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___appName_5)); }
	inline String_t* get_appName_5() const { return ___appName_5; }
	inline String_t** get_address_of_appName_5() { return &___appName_5; }
	inline void set_appName_5(String_t* value)
	{
		___appName_5 = value;
		Il2CppCodeGenWriteBarrier((&___appName_5), value);
	}

	inline static int32_t get_offset_of_currentXmlPath_6() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___currentXmlPath_6)); }
	inline String_t* get_currentXmlPath_6() const { return ___currentXmlPath_6; }
	inline String_t** get_address_of_currentXmlPath_6() { return &___currentXmlPath_6; }
	inline void set_currentXmlPath_6(String_t* value)
	{
		___currentXmlPath_6 = value;
		Il2CppCodeGenWriteBarrier((&___currentXmlPath_6), value);
	}

	inline static int32_t get_offset_of_onlyDelayedChannels_7() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7, ___onlyDelayedChannels_7)); }
	inline bool get_onlyDelayedChannels_7() const { return ___onlyDelayedChannels_7; }
	inline bool* get_address_of_onlyDelayedChannels_7() { return &___onlyDelayedChannels_7; }
	inline void set_onlyDelayedChannels_7(bool value)
	{
		___onlyDelayedChannels_7 = value;
	}
};

struct ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.ConfigHandler::<>f__switchU24map27
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map27_8;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.ConfigHandler::<>f__switchU24map28
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map28_9;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map27_8() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_StaticFields, ___U3CU3Ef__switchU24map27_8)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map27_8() const { return ___U3CU3Ef__switchU24map27_8; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map27_8() { return &___U3CU3Ef__switchU24map27_8; }
	inline void set_U3CU3Ef__switchU24map27_8(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map27_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map27_8), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map28_9() { return static_cast<int32_t>(offsetof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_StaticFields, ___U3CU3Ef__switchU24map28_9)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map28_9() const { return ___U3CU3Ef__switchU24map28_9; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map28_9() { return &___U3CU3Ef__switchU24map28_9; }
	inline void set_U3CU3Ef__switchU24map28_9(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map28_9 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map28_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFIGHANDLER_TF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_H
#ifndef CROSSCONTEXTCHANNEL_T829E9251B05682ACAD9FAEEB35BED50A361EA883_H
#define CROSSCONTEXTCHANNEL_T829E9251B05682ACAD9FAEEB35BED50A361EA883_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.CrossContextChannel
struct  CrossContextChannel_t829E9251B05682ACAD9FAEEB35BED50A361EA883  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CROSSCONTEXTCHANNEL_T829E9251B05682ACAD9FAEEB35BED50A361EA883_H
#ifndef CONTEXTRESTORESINK_T3D9E83C836390D19B42CA1056E073E1AB4C00B5F_H
#define CONTEXTRESTORESINK_T3D9E83C836390D19B42CA1056E073E1AB4C00B5F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.CrossContextChannel_ContextRestoreSink
struct  ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.CrossContextChannel_ContextRestoreSink::_next
	RuntimeObject* ____next_0;
	// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Contexts.CrossContextChannel_ContextRestoreSink::_context
	Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * ____context_1;
	// System.Runtime.Remoting.Messaging.IMessage System.Runtime.Remoting.Contexts.CrossContextChannel_ContextRestoreSink::_call
	RuntimeObject* ____call_2;

public:
	inline static int32_t get_offset_of__next_0() { return static_cast<int32_t>(offsetof(ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F, ____next_0)); }
	inline RuntimeObject* get__next_0() const { return ____next_0; }
	inline RuntimeObject** get_address_of__next_0() { return &____next_0; }
	inline void set__next_0(RuntimeObject* value)
	{
		____next_0 = value;
		Il2CppCodeGenWriteBarrier((&____next_0), value);
	}

	inline static int32_t get_offset_of__context_1() { return static_cast<int32_t>(offsetof(ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F, ____context_1)); }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * get__context_1() const { return ____context_1; }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 ** get_address_of__context_1() { return &____context_1; }
	inline void set__context_1(Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * value)
	{
		____context_1 = value;
		Il2CppCodeGenWriteBarrier((&____context_1), value);
	}

	inline static int32_t get_offset_of__call_2() { return static_cast<int32_t>(offsetof(ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F, ____call_2)); }
	inline RuntimeObject* get__call_2() const { return ____call_2; }
	inline RuntimeObject** get_address_of__call_2() { return &____call_2; }
	inline void set__call_2(RuntimeObject* value)
	{
		____call_2 = value;
		Il2CppCodeGenWriteBarrier((&____call_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTEXTRESTORESINK_T3D9E83C836390D19B42CA1056E073E1AB4C00B5F_H
#ifndef DYNAMICPROPERTYREG_T235A8D7D81829009D705A9CE5994E9999E9099EF_H
#define DYNAMICPROPERTYREG_T235A8D7D81829009D705A9CE5994E9999E9099EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.DynamicPropertyCollection_DynamicPropertyReg
struct  DynamicPropertyReg_t235A8D7D81829009D705A9CE5994E9999E9099EF  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Contexts.IDynamicProperty System.Runtime.Remoting.Contexts.DynamicPropertyCollection_DynamicPropertyReg::Property
	RuntimeObject* ___Property_0;
	// System.Runtime.Remoting.Contexts.IDynamicMessageSink System.Runtime.Remoting.Contexts.DynamicPropertyCollection_DynamicPropertyReg::Sink
	RuntimeObject* ___Sink_1;

public:
	inline static int32_t get_offset_of_Property_0() { return static_cast<int32_t>(offsetof(DynamicPropertyReg_t235A8D7D81829009D705A9CE5994E9999E9099EF, ___Property_0)); }
	inline RuntimeObject* get_Property_0() const { return ___Property_0; }
	inline RuntimeObject** get_address_of_Property_0() { return &___Property_0; }
	inline void set_Property_0(RuntimeObject* value)
	{
		___Property_0 = value;
		Il2CppCodeGenWriteBarrier((&___Property_0), value);
	}

	inline static int32_t get_offset_of_Sink_1() { return static_cast<int32_t>(offsetof(DynamicPropertyReg_t235A8D7D81829009D705A9CE5994E9999E9099EF, ___Sink_1)); }
	inline RuntimeObject* get_Sink_1() const { return ___Sink_1; }
	inline RuntimeObject** get_address_of_Sink_1() { return &___Sink_1; }
	inline void set_Sink_1(RuntimeObject* value)
	{
		___Sink_1 = value;
		Il2CppCodeGenWriteBarrier((&___Sink_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DYNAMICPROPERTYREG_T235A8D7D81829009D705A9CE5994E9999E9099EF_H
#ifndef SYNCHRONIZEDCLIENTCONTEXTSINK_T5F678409C7E397E3789342AF86487D14D2B7D434_H
#define SYNCHRONIZEDCLIENTCONTEXTSINK_T5F678409C7E397E3789342AF86487D14D2B7D434_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.SynchronizedClientContextSink
struct  SynchronizedClientContextSink_t5F678409C7E397E3789342AF86487D14D2B7D434  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.SynchronizedClientContextSink::_next
	RuntimeObject* ____next_0;
	// System.Runtime.Remoting.Contexts.SynchronizationAttribute System.Runtime.Remoting.Contexts.SynchronizedClientContextSink::_att
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * ____att_1;

public:
	inline static int32_t get_offset_of__next_0() { return static_cast<int32_t>(offsetof(SynchronizedClientContextSink_t5F678409C7E397E3789342AF86487D14D2B7D434, ____next_0)); }
	inline RuntimeObject* get__next_0() const { return ____next_0; }
	inline RuntimeObject** get_address_of__next_0() { return &____next_0; }
	inline void set__next_0(RuntimeObject* value)
	{
		____next_0 = value;
		Il2CppCodeGenWriteBarrier((&____next_0), value);
	}

	inline static int32_t get_offset_of__att_1() { return static_cast<int32_t>(offsetof(SynchronizedClientContextSink_t5F678409C7E397E3789342AF86487D14D2B7D434, ____att_1)); }
	inline SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * get__att_1() const { return ____att_1; }
	inline SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F ** get_address_of__att_1() { return &____att_1; }
	inline void set__att_1(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * value)
	{
		____att_1 = value;
		Il2CppCodeGenWriteBarrier((&____att_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYNCHRONIZEDCLIENTCONTEXTSINK_T5F678409C7E397E3789342AF86487D14D2B7D434_H
#ifndef SYNCHRONIZEDCONTEXTREPLYSINK_T7DBC565402D49BB7648400D9299BEC0903A0F7EB_H
#define SYNCHRONIZEDCONTEXTREPLYSINK_T7DBC565402D49BB7648400D9299BEC0903A0F7EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.SynchronizedContextReplySink
struct  SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.SynchronizedContextReplySink::_next
	RuntimeObject* ____next_0;
	// System.Boolean System.Runtime.Remoting.Contexts.SynchronizedContextReplySink::_newLock
	bool ____newLock_1;
	// System.Runtime.Remoting.Contexts.SynchronizationAttribute System.Runtime.Remoting.Contexts.SynchronizedContextReplySink::_att
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * ____att_2;

public:
	inline static int32_t get_offset_of__next_0() { return static_cast<int32_t>(offsetof(SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB, ____next_0)); }
	inline RuntimeObject* get__next_0() const { return ____next_0; }
	inline RuntimeObject** get_address_of__next_0() { return &____next_0; }
	inline void set__next_0(RuntimeObject* value)
	{
		____next_0 = value;
		Il2CppCodeGenWriteBarrier((&____next_0), value);
	}

	inline static int32_t get_offset_of__newLock_1() { return static_cast<int32_t>(offsetof(SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB, ____newLock_1)); }
	inline bool get__newLock_1() const { return ____newLock_1; }
	inline bool* get_address_of__newLock_1() { return &____newLock_1; }
	inline void set__newLock_1(bool value)
	{
		____newLock_1 = value;
	}

	inline static int32_t get_offset_of__att_2() { return static_cast<int32_t>(offsetof(SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB, ____att_2)); }
	inline SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * get__att_2() const { return ____att_2; }
	inline SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F ** get_address_of__att_2() { return &____att_2; }
	inline void set__att_2(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * value)
	{
		____att_2 = value;
		Il2CppCodeGenWriteBarrier((&____att_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYNCHRONIZEDCONTEXTREPLYSINK_T7DBC565402D49BB7648400D9299BEC0903A0F7EB_H
#ifndef SYNCHRONIZEDSERVERCONTEXTSINK_TDA1E9099B9197694F96B872E96E9CDD250AFDD80_H
#define SYNCHRONIZEDSERVERCONTEXTSINK_TDA1E9099B9197694F96B872E96E9CDD250AFDD80_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.SynchronizedServerContextSink
struct  SynchronizedServerContextSink_tDA1E9099B9197694F96B872E96E9CDD250AFDD80  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.SynchronizedServerContextSink::_next
	RuntimeObject* ____next_0;
	// System.Runtime.Remoting.Contexts.SynchronizationAttribute System.Runtime.Remoting.Contexts.SynchronizedServerContextSink::_att
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * ____att_1;

public:
	inline static int32_t get_offset_of__next_0() { return static_cast<int32_t>(offsetof(SynchronizedServerContextSink_tDA1E9099B9197694F96B872E96E9CDD250AFDD80, ____next_0)); }
	inline RuntimeObject* get__next_0() const { return ____next_0; }
	inline RuntimeObject** get_address_of__next_0() { return &____next_0; }
	inline void set__next_0(RuntimeObject* value)
	{
		____next_0 = value;
		Il2CppCodeGenWriteBarrier((&____next_0), value);
	}

	inline static int32_t get_offset_of__att_1() { return static_cast<int32_t>(offsetof(SynchronizedServerContextSink_tDA1E9099B9197694F96B872E96E9CDD250AFDD80, ____att_1)); }
	inline SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * get__att_1() const { return ____att_1; }
	inline SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F ** get_address_of__att_1() { return &____att_1; }
	inline void set__att_1(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F * value)
	{
		____att_1 = value;
		Il2CppCodeGenWriteBarrier((&____att_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYNCHRONIZEDSERVERCONTEXTSINK_TDA1E9099B9197694F96B872E96E9CDD250AFDD80_H
#ifndef ENVOYINFO_T79CF15F10598F653E9EB2EAE84843DE26879895F_H
#define ENVOYINFO_T79CF15F10598F653E9EB2EAE84843DE26879895F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.EnvoyInfo
struct  EnvoyInfo_t79CF15F10598F653E9EB2EAE84843DE26879895F  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.EnvoyInfo::envoySinks
	RuntimeObject* ___envoySinks_0;

public:
	inline static int32_t get_offset_of_envoySinks_0() { return static_cast<int32_t>(offsetof(EnvoyInfo_t79CF15F10598F653E9EB2EAE84843DE26879895F, ___envoySinks_0)); }
	inline RuntimeObject* get_envoySinks_0() const { return ___envoySinks_0; }
	inline RuntimeObject** get_address_of_envoySinks_0() { return &___envoySinks_0; }
	inline void set_envoySinks_0(RuntimeObject* value)
	{
		___envoySinks_0 = value;
		Il2CppCodeGenWriteBarrier((&___envoySinks_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENVOYINFO_T79CF15F10598F653E9EB2EAE84843DE26879895F_H
#ifndef IDENTITY_TF0CD49E50E212E64314E0241852939303E414F1C_H
#define IDENTITY_TF0CD49E50E212E64314E0241852939303E414F1C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Identity
struct  Identity_tF0CD49E50E212E64314E0241852939303E414F1C  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Identity::_objectUri
	String_t* ____objectUri_0;
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Identity::_channelSink
	RuntimeObject* ____channelSink_1;
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Identity::_envoySink
	RuntimeObject* ____envoySink_2;
	// System.Runtime.Remoting.Contexts.DynamicPropertyCollection System.Runtime.Remoting.Identity::_clientDynamicProperties
	DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 * ____clientDynamicProperties_3;
	// System.Runtime.Remoting.Contexts.DynamicPropertyCollection System.Runtime.Remoting.Identity::_serverDynamicProperties
	DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 * ____serverDynamicProperties_4;
	// System.Runtime.Remoting.ObjRef System.Runtime.Remoting.Identity::_objRef
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E * ____objRef_5;
	// System.Boolean System.Runtime.Remoting.Identity::_disposed
	bool ____disposed_6;

public:
	inline static int32_t get_offset_of__objectUri_0() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____objectUri_0)); }
	inline String_t* get__objectUri_0() const { return ____objectUri_0; }
	inline String_t** get_address_of__objectUri_0() { return &____objectUri_0; }
	inline void set__objectUri_0(String_t* value)
	{
		____objectUri_0 = value;
		Il2CppCodeGenWriteBarrier((&____objectUri_0), value);
	}

	inline static int32_t get_offset_of__channelSink_1() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____channelSink_1)); }
	inline RuntimeObject* get__channelSink_1() const { return ____channelSink_1; }
	inline RuntimeObject** get_address_of__channelSink_1() { return &____channelSink_1; }
	inline void set__channelSink_1(RuntimeObject* value)
	{
		____channelSink_1 = value;
		Il2CppCodeGenWriteBarrier((&____channelSink_1), value);
	}

	inline static int32_t get_offset_of__envoySink_2() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____envoySink_2)); }
	inline RuntimeObject* get__envoySink_2() const { return ____envoySink_2; }
	inline RuntimeObject** get_address_of__envoySink_2() { return &____envoySink_2; }
	inline void set__envoySink_2(RuntimeObject* value)
	{
		____envoySink_2 = value;
		Il2CppCodeGenWriteBarrier((&____envoySink_2), value);
	}

	inline static int32_t get_offset_of__clientDynamicProperties_3() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____clientDynamicProperties_3)); }
	inline DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 * get__clientDynamicProperties_3() const { return ____clientDynamicProperties_3; }
	inline DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 ** get_address_of__clientDynamicProperties_3() { return &____clientDynamicProperties_3; }
	inline void set__clientDynamicProperties_3(DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 * value)
	{
		____clientDynamicProperties_3 = value;
		Il2CppCodeGenWriteBarrier((&____clientDynamicProperties_3), value);
	}

	inline static int32_t get_offset_of__serverDynamicProperties_4() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____serverDynamicProperties_4)); }
	inline DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 * get__serverDynamicProperties_4() const { return ____serverDynamicProperties_4; }
	inline DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 ** get_address_of__serverDynamicProperties_4() { return &____serverDynamicProperties_4; }
	inline void set__serverDynamicProperties_4(DynamicPropertyCollection_t2BCB365C3945EA6A5EEF98AAFAD09E70AFBE24B0 * value)
	{
		____serverDynamicProperties_4 = value;
		Il2CppCodeGenWriteBarrier((&____serverDynamicProperties_4), value);
	}

	inline static int32_t get_offset_of__objRef_5() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____objRef_5)); }
	inline ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E * get__objRef_5() const { return ____objRef_5; }
	inline ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E ** get_address_of__objRef_5() { return &____objRef_5; }
	inline void set__objRef_5(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E * value)
	{
		____objRef_5 = value;
		Il2CppCodeGenWriteBarrier((&____objRef_5), value);
	}

	inline static int32_t get_offset_of__disposed_6() { return static_cast<int32_t>(offsetof(Identity_tF0CD49E50E212E64314E0241852939303E414F1C, ____disposed_6)); }
	inline bool get__disposed_6() const { return ____disposed_6; }
	inline bool* get_address_of__disposed_6() { return &____disposed_6; }
	inline void set__disposed_6(bool value)
	{
		____disposed_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // IDENTITY_TF0CD49E50E212E64314E0241852939303E414F1C_H
#ifndef INTERNALREMOTINGSERVICES_T7D245B274133CEAFA377675A79E8A24FD14DC940_H
#define INTERNALREMOTINGSERVICES_T7D245B274133CEAFA377675A79E8A24FD14DC940_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.InternalRemotingServices
struct  InternalRemotingServices_t7D245B274133CEAFA377675A79E8A24FD14DC940  : public RuntimeObject
{
public:

public:
};

struct InternalRemotingServices_t7D245B274133CEAFA377675A79E8A24FD14DC940_StaticFields
{
public:
	// System.Collections.Hashtable System.Runtime.Remoting.InternalRemotingServices::_soapAttributes
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ____soapAttributes_0;

public:
	inline static int32_t get_offset_of__soapAttributes_0() { return static_cast<int32_t>(offsetof(InternalRemotingServices_t7D245B274133CEAFA377675A79E8A24FD14DC940_StaticFields, ____soapAttributes_0)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get__soapAttributes_0() const { return ____soapAttributes_0; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of__soapAttributes_0() { return &____soapAttributes_0; }
	inline void set__soapAttributes_0(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		____soapAttributes_0 = value;
		Il2CppCodeGenWriteBarrier((&____soapAttributes_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNALREMOTINGSERVICES_T7D245B274133CEAFA377675A79E8A24FD14DC940_H
#ifndef LEASEMANAGER_TE0A31CEC9A976AC72C54B4D87B5FA124B461049D_H
#define LEASEMANAGER_TE0A31CEC9A976AC72C54B4D87B5FA124B461049D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Lifetime.LeaseManager
struct  LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D  : public RuntimeObject
{
public:
	// System.Collections.ArrayList System.Runtime.Remoting.Lifetime.LeaseManager::_objects
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ____objects_0;
	// System.Threading.Timer System.Runtime.Remoting.Lifetime.LeaseManager::_timer
	Timer_tAB247DBC06A8C0969B6B6519866D61CFE3688FDC * ____timer_1;

public:
	inline static int32_t get_offset_of__objects_0() { return static_cast<int32_t>(offsetof(LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D, ____objects_0)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get__objects_0() const { return ____objects_0; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of__objects_0() { return &____objects_0; }
	inline void set__objects_0(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		____objects_0 = value;
		Il2CppCodeGenWriteBarrier((&____objects_0), value);
	}

	inline static int32_t get_offset_of__timer_1() { return static_cast<int32_t>(offsetof(LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D, ____timer_1)); }
	inline Timer_tAB247DBC06A8C0969B6B6519866D61CFE3688FDC * get__timer_1() const { return ____timer_1; }
	inline Timer_tAB247DBC06A8C0969B6B6519866D61CFE3688FDC ** get_address_of__timer_1() { return &____timer_1; }
	inline void set__timer_1(Timer_tAB247DBC06A8C0969B6B6519866D61CFE3688FDC * value)
	{
		____timer_1 = value;
		Il2CppCodeGenWriteBarrier((&____timer_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEASEMANAGER_TE0A31CEC9A976AC72C54B4D87B5FA124B461049D_H
#ifndef LEASESINK_T4782A8795E980D5DCFB300E06675F7AD96059114_H
#define LEASESINK_T4782A8795E980D5DCFB300E06675F7AD96059114_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Lifetime.LeaseSink
struct  LeaseSink_t4782A8795E980D5DCFB300E06675F7AD96059114  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Lifetime.LeaseSink::_nextSink
	RuntimeObject* ____nextSink_0;

public:
	inline static int32_t get_offset_of__nextSink_0() { return static_cast<int32_t>(offsetof(LeaseSink_t4782A8795E980D5DCFB300E06675F7AD96059114, ____nextSink_0)); }
	inline RuntimeObject* get__nextSink_0() const { return ____nextSink_0; }
	inline RuntimeObject** get_address_of__nextSink_0() { return &____nextSink_0; }
	inline void set__nextSink_0(RuntimeObject* value)
	{
		____nextSink_0 = value;
		Il2CppCodeGenWriteBarrier((&____nextSink_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEASESINK_T4782A8795E980D5DCFB300E06675F7AD96059114_H
#ifndef ARGINFO_TC55D916C7CFDDB6ECA541A413FFD67895BD594A3_H
#define ARGINFO_TC55D916C7CFDDB6ECA541A413FFD67895BD594A3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ArgInfo
struct  ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3  : public RuntimeObject
{
public:
	// System.Int32[] System.Runtime.Remoting.Messaging.ArgInfo::_paramMap
	Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* ____paramMap_0;
	// System.Int32 System.Runtime.Remoting.Messaging.ArgInfo::_inoutArgCount
	int32_t ____inoutArgCount_1;
	// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.ArgInfo::_method
	MethodBase_t * ____method_2;

public:
	inline static int32_t get_offset_of__paramMap_0() { return static_cast<int32_t>(offsetof(ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3, ____paramMap_0)); }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* get__paramMap_0() const { return ____paramMap_0; }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074** get_address_of__paramMap_0() { return &____paramMap_0; }
	inline void set__paramMap_0(Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* value)
	{
		____paramMap_0 = value;
		Il2CppCodeGenWriteBarrier((&____paramMap_0), value);
	}

	inline static int32_t get_offset_of__inoutArgCount_1() { return static_cast<int32_t>(offsetof(ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3, ____inoutArgCount_1)); }
	inline int32_t get__inoutArgCount_1() const { return ____inoutArgCount_1; }
	inline int32_t* get_address_of__inoutArgCount_1() { return &____inoutArgCount_1; }
	inline void set__inoutArgCount_1(int32_t value)
	{
		____inoutArgCount_1 = value;
	}

	inline static int32_t get_offset_of__method_2() { return static_cast<int32_t>(offsetof(ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3, ____method_2)); }
	inline MethodBase_t * get__method_2() const { return ____method_2; }
	inline MethodBase_t ** get_address_of__method_2() { return &____method_2; }
	inline void set__method_2(MethodBase_t * value)
	{
		____method_2 = value;
		Il2CppCodeGenWriteBarrier((&____method_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGINFO_TC55D916C7CFDDB6ECA541A413FFD67895BD594A3_H
#ifndef CADARGHOLDER_T496415C662E90A308A1160B8487C05033DE4A120_H
#define CADARGHOLDER_T496415C662E90A308A1160B8487C05033DE4A120_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CADArgHolder
struct  CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120  : public RuntimeObject
{
public:
	// System.Int32 System.Runtime.Remoting.Messaging.CADArgHolder::index
	int32_t ___index_0;

public:
	inline static int32_t get_offset_of_index_0() { return static_cast<int32_t>(offsetof(CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120, ___index_0)); }
	inline int32_t get_index_0() const { return ___index_0; }
	inline int32_t* get_address_of_index_0() { return &___index_0; }
	inline void set_index_0(int32_t value)
	{
		___index_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CADARGHOLDER_T496415C662E90A308A1160B8487C05033DE4A120_H
#ifndef CADMESSAGEBASE_TDDC7ADA64877C910A0AFC09B02477A2D293D46D3_H
#define CADMESSAGEBASE_TDDC7ADA64877C910A0AFC09B02477A2D293D46D3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CADMessageBase
struct  CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3  : public RuntimeObject
{
public:
	// System.Object[] System.Runtime.Remoting.Messaging.CADMessageBase::_args
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____args_0;
	// System.Byte[] System.Runtime.Remoting.Messaging.CADMessageBase::_serializedArgs
	ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8* ____serializedArgs_1;
	// System.Int32 System.Runtime.Remoting.Messaging.CADMessageBase::_propertyCount
	int32_t ____propertyCount_2;
	// System.Runtime.Remoting.Messaging.CADArgHolder System.Runtime.Remoting.Messaging.CADMessageBase::_callContext
	CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 * ____callContext_3;

public:
	inline static int32_t get_offset_of__args_0() { return static_cast<int32_t>(offsetof(CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3, ____args_0)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__args_0() const { return ____args_0; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__args_0() { return &____args_0; }
	inline void set__args_0(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____args_0 = value;
		Il2CppCodeGenWriteBarrier((&____args_0), value);
	}

	inline static int32_t get_offset_of__serializedArgs_1() { return static_cast<int32_t>(offsetof(CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3, ____serializedArgs_1)); }
	inline ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8* get__serializedArgs_1() const { return ____serializedArgs_1; }
	inline ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8** get_address_of__serializedArgs_1() { return &____serializedArgs_1; }
	inline void set__serializedArgs_1(ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8* value)
	{
		____serializedArgs_1 = value;
		Il2CppCodeGenWriteBarrier((&____serializedArgs_1), value);
	}

	inline static int32_t get_offset_of__propertyCount_2() { return static_cast<int32_t>(offsetof(CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3, ____propertyCount_2)); }
	inline int32_t get__propertyCount_2() const { return ____propertyCount_2; }
	inline int32_t* get_address_of__propertyCount_2() { return &____propertyCount_2; }
	inline void set__propertyCount_2(int32_t value)
	{
		____propertyCount_2 = value;
	}

	inline static int32_t get_offset_of__callContext_3() { return static_cast<int32_t>(offsetof(CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3, ____callContext_3)); }
	inline CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 * get__callContext_3() const { return ____callContext_3; }
	inline CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 ** get_address_of__callContext_3() { return &____callContext_3; }
	inline void set__callContext_3(CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 * value)
	{
		____callContext_3 = value;
		Il2CppCodeGenWriteBarrier((&____callContext_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CADMESSAGEBASE_TDDC7ADA64877C910A0AFC09B02477A2D293D46D3_H
#ifndef CADOBJREF_T48D330C04C98DCBB71727B2DE3026035567ADC64_H
#define CADOBJREF_T48D330C04C98DCBB71727B2DE3026035567ADC64_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CADObjRef
struct  CADObjRef_t48D330C04C98DCBB71727B2DE3026035567ADC64  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.ObjRef System.Runtime.Remoting.Messaging.CADObjRef::objref
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E * ___objref_0;
	// System.Int32 System.Runtime.Remoting.Messaging.CADObjRef::SourceDomain
	int32_t ___SourceDomain_1;

public:
	inline static int32_t get_offset_of_objref_0() { return static_cast<int32_t>(offsetof(CADObjRef_t48D330C04C98DCBB71727B2DE3026035567ADC64, ___objref_0)); }
	inline ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E * get_objref_0() const { return ___objref_0; }
	inline ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E ** get_address_of_objref_0() { return &___objref_0; }
	inline void set_objref_0(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E * value)
	{
		___objref_0 = value;
		Il2CppCodeGenWriteBarrier((&___objref_0), value);
	}

	inline static int32_t get_offset_of_SourceDomain_1() { return static_cast<int32_t>(offsetof(CADObjRef_t48D330C04C98DCBB71727B2DE3026035567ADC64, ___SourceDomain_1)); }
	inline int32_t get_SourceDomain_1() const { return ___SourceDomain_1; }
	inline int32_t* get_address_of_SourceDomain_1() { return &___SourceDomain_1; }
	inline void set_SourceDomain_1(int32_t value)
	{
		___SourceDomain_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CADOBJREF_T48D330C04C98DCBB71727B2DE3026035567ADC64_H
#ifndef CALLCONTEXT_T0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_H
#define CALLCONTEXT_T0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CallContext
struct  CallContext_t0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE  : public RuntimeObject
{
public:

public:
};

struct CallContext_t0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_ThreadStaticFields
{
public:
	// System.Collections.Hashtable System.Runtime.Remoting.Messaging.CallContext::datastore
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___datastore_0;

public:
	inline static int32_t get_offset_of_datastore_0() { return static_cast<int32_t>(offsetof(CallContext_t0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_ThreadStaticFields, ___datastore_0)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_datastore_0() const { return ___datastore_0; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_datastore_0() { return &___datastore_0; }
	inline void set_datastore_0(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___datastore_0 = value;
		Il2CppCodeGenWriteBarrier((&___datastore_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLCONTEXT_T0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_H
#ifndef CALLCONTEXTREMOTINGDATA_T3609DDA17E5FECC992B01CCEBB0C2FD5424D390A_H
#define CALLCONTEXTREMOTINGDATA_T3609DDA17E5FECC992B01CCEBB0C2FD5424D390A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CallContextRemotingData
struct  CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Messaging.CallContextRemotingData::_logicalCallID
	String_t* ____logicalCallID_0;

public:
	inline static int32_t get_offset_of__logicalCallID_0() { return static_cast<int32_t>(offsetof(CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A, ____logicalCallID_0)); }
	inline String_t* get__logicalCallID_0() const { return ____logicalCallID_0; }
	inline String_t** get_address_of__logicalCallID_0() { return &____logicalCallID_0; }
	inline void set__logicalCallID_0(String_t* value)
	{
		____logicalCallID_0 = value;
		Il2CppCodeGenWriteBarrier((&____logicalCallID_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLCONTEXTREMOTINGDATA_T3609DDA17E5FECC992B01CCEBB0C2FD5424D390A_H
#ifndef CLIENTCONTEXTREPLYSINK_T199694E57B7E4C90D73CE97E3502366BFF803487_H
#define CLIENTCONTEXTREPLYSINK_T199694E57B7E4C90D73CE97E3502366BFF803487_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ClientContextReplySink
struct  ClientContextReplySink_t199694E57B7E4C90D73CE97E3502366BFF803487  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Messaging.ClientContextReplySink::_replySink
	RuntimeObject* ____replySink_0;
	// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Messaging.ClientContextReplySink::_context
	Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * ____context_1;

public:
	inline static int32_t get_offset_of__replySink_0() { return static_cast<int32_t>(offsetof(ClientContextReplySink_t199694E57B7E4C90D73CE97E3502366BFF803487, ____replySink_0)); }
	inline RuntimeObject* get__replySink_0() const { return ____replySink_0; }
	inline RuntimeObject** get_address_of__replySink_0() { return &____replySink_0; }
	inline void set__replySink_0(RuntimeObject* value)
	{
		____replySink_0 = value;
		Il2CppCodeGenWriteBarrier((&____replySink_0), value);
	}

	inline static int32_t get_offset_of__context_1() { return static_cast<int32_t>(offsetof(ClientContextReplySink_t199694E57B7E4C90D73CE97E3502366BFF803487, ____context_1)); }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * get__context_1() const { return ____context_1; }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 ** get_address_of__context_1() { return &____context_1; }
	inline void set__context_1(Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * value)
	{
		____context_1 = value;
		Il2CppCodeGenWriteBarrier((&____context_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLIENTCONTEXTREPLYSINK_T199694E57B7E4C90D73CE97E3502366BFF803487_H
#ifndef CLIENTCONTEXTTERMINATORSINK_TF01CDC694E6619B1959C265E9D41B3A0086828A3_H
#define CLIENTCONTEXTTERMINATORSINK_TF01CDC694E6619B1959C265E9D41B3A0086828A3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ClientContextTerminatorSink
struct  ClientContextTerminatorSink_tF01CDC694E6619B1959C265E9D41B3A0086828A3  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Messaging.ClientContextTerminatorSink::_context
	Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * ____context_0;

public:
	inline static int32_t get_offset_of__context_0() { return static_cast<int32_t>(offsetof(ClientContextTerminatorSink_tF01CDC694E6619B1959C265E9D41B3A0086828A3, ____context_0)); }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * get__context_0() const { return ____context_0; }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 ** get_address_of__context_0() { return &____context_0; }
	inline void set__context_0(Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * value)
	{
		____context_0 = value;
		Il2CppCodeGenWriteBarrier((&____context_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLIENTCONTEXTTERMINATORSINK_TF01CDC694E6619B1959C265E9D41B3A0086828A3_H
#ifndef ENVOYTERMINATORSINK_T429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_H
#define ENVOYTERMINATORSINK_T429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.EnvoyTerminatorSink
struct  EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE  : public RuntimeObject
{
public:

public:
};

struct EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_StaticFields
{
public:
	// System.Runtime.Remoting.Messaging.EnvoyTerminatorSink System.Runtime.Remoting.Messaging.EnvoyTerminatorSink::Instance
	EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE * ___Instance_0;

public:
	inline static int32_t get_offset_of_Instance_0() { return static_cast<int32_t>(offsetof(EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_StaticFields, ___Instance_0)); }
	inline EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE * get_Instance_0() const { return ___Instance_0; }
	inline EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE ** get_address_of_Instance_0() { return &___Instance_0; }
	inline void set_Instance_0(EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE * value)
	{
		___Instance_0 = value;
		Il2CppCodeGenWriteBarrier((&___Instance_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENVOYTERMINATORSINK_T429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_H
#ifndef ERRORMESSAGE_TCD2EB85BCC8F58121C393D677E33836B2F006928_H
#define ERRORMESSAGE_TCD2EB85BCC8F58121C393D677E33836B2F006928_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ErrorMessage
struct  ErrorMessage_tCD2EB85BCC8F58121C393D677E33836B2F006928  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Messaging.ErrorMessage::_uri
	String_t* ____uri_0;

public:
	inline static int32_t get_offset_of__uri_0() { return static_cast<int32_t>(offsetof(ErrorMessage_tCD2EB85BCC8F58121C393D677E33836B2F006928, ____uri_0)); }
	inline String_t* get__uri_0() const { return ____uri_0; }
	inline String_t** get_address_of__uri_0() { return &____uri_0; }
	inline void set__uri_0(String_t* value)
	{
		____uri_0 = value;
		Il2CppCodeGenWriteBarrier((&____uri_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERRORMESSAGE_TCD2EB85BCC8F58121C393D677E33836B2F006928_H
#ifndef HEADER_T60102AE64AB00EA81BC9A7743769B4C6BCB6466C_H
#define HEADER_T60102AE64AB00EA81BC9A7743769B4C6BCB6466C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.Header
struct  Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Messaging.Header::HeaderNamespace
	String_t* ___HeaderNamespace_0;
	// System.Boolean System.Runtime.Remoting.Messaging.Header::MustUnderstand
	bool ___MustUnderstand_1;
	// System.String System.Runtime.Remoting.Messaging.Header::Name
	String_t* ___Name_2;
	// System.Object System.Runtime.Remoting.Messaging.Header::Value
	RuntimeObject * ___Value_3;

public:
	inline static int32_t get_offset_of_HeaderNamespace_0() { return static_cast<int32_t>(offsetof(Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C, ___HeaderNamespace_0)); }
	inline String_t* get_HeaderNamespace_0() const { return ___HeaderNamespace_0; }
	inline String_t** get_address_of_HeaderNamespace_0() { return &___HeaderNamespace_0; }
	inline void set_HeaderNamespace_0(String_t* value)
	{
		___HeaderNamespace_0 = value;
		Il2CppCodeGenWriteBarrier((&___HeaderNamespace_0), value);
	}

	inline static int32_t get_offset_of_MustUnderstand_1() { return static_cast<int32_t>(offsetof(Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C, ___MustUnderstand_1)); }
	inline bool get_MustUnderstand_1() const { return ___MustUnderstand_1; }
	inline bool* get_address_of_MustUnderstand_1() { return &___MustUnderstand_1; }
	inline void set_MustUnderstand_1(bool value)
	{
		___MustUnderstand_1 = value;
	}

	inline static int32_t get_offset_of_Name_2() { return static_cast<int32_t>(offsetof(Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C, ___Name_2)); }
	inline String_t* get_Name_2() const { return ___Name_2; }
	inline String_t** get_address_of_Name_2() { return &___Name_2; }
	inline void set_Name_2(String_t* value)
	{
		___Name_2 = value;
		Il2CppCodeGenWriteBarrier((&___Name_2), value);
	}

	inline static int32_t get_offset_of_Value_3() { return static_cast<int32_t>(offsetof(Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C, ___Value_3)); }
	inline RuntimeObject * get_Value_3() const { return ___Value_3; }
	inline RuntimeObject ** get_address_of_Value_3() { return &___Value_3; }
	inline void set_Value_3(RuntimeObject * value)
	{
		___Value_3 = value;
		Il2CppCodeGenWriteBarrier((&___Value_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HEADER_T60102AE64AB00EA81BC9A7743769B4C6BCB6466C_H
#ifndef LOGICALCALLCONTEXT_T8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394_H
#define LOGICALCALLCONTEXT_T8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.LogicalCallContext
struct  LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394  : public RuntimeObject
{
public:
	// System.Collections.Hashtable System.Runtime.Remoting.Messaging.LogicalCallContext::_data
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ____data_0;
	// System.Runtime.Remoting.Messaging.CallContextRemotingData System.Runtime.Remoting.Messaging.LogicalCallContext::_remotingData
	CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A * ____remotingData_1;

public:
	inline static int32_t get_offset_of__data_0() { return static_cast<int32_t>(offsetof(LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394, ____data_0)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get__data_0() const { return ____data_0; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of__data_0() { return &____data_0; }
	inline void set__data_0(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		____data_0 = value;
		Il2CppCodeGenWriteBarrier((&____data_0), value);
	}

	inline static int32_t get_offset_of__remotingData_1() { return static_cast<int32_t>(offsetof(LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394, ____remotingData_1)); }
	inline CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A * get__remotingData_1() const { return ____remotingData_1; }
	inline CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A ** get_address_of__remotingData_1() { return &____remotingData_1; }
	inline void set__remotingData_1(CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A * value)
	{
		____remotingData_1 = value;
		Il2CppCodeGenWriteBarrier((&____remotingData_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGICALCALLCONTEXT_T8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394_H
#ifndef METHODCALL_T85B750F7999345054735594566D42DDF9C378FD3_H
#define METHODCALL_T85B750F7999345054735594566D42DDF9C378FD3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MethodCall
struct  MethodCall_t85B750F7999345054735594566D42DDF9C378FD3  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Messaging.MethodCall::_uri
	String_t* ____uri_0;
	// System.String System.Runtime.Remoting.Messaging.MethodCall::_typeName
	String_t* ____typeName_1;
	// System.String System.Runtime.Remoting.Messaging.MethodCall::_methodName
	String_t* ____methodName_2;
	// System.Object[] System.Runtime.Remoting.Messaging.MethodCall::_args
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____args_3;
	// System.Type[] System.Runtime.Remoting.Messaging.MethodCall::_methodSignature
	TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* ____methodSignature_4;
	// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.MethodCall::_methodBase
	MethodBase_t * ____methodBase_5;
	// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.MethodCall::_callContext
	LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * ____callContext_6;
	// System.Runtime.Remoting.Identity System.Runtime.Remoting.Messaging.MethodCall::_targetIdentity
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C * ____targetIdentity_7;
	// System.Type[] System.Runtime.Remoting.Messaging.MethodCall::_genericArguments
	TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* ____genericArguments_8;
	// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodCall::ExternalProperties
	RuntimeObject* ___ExternalProperties_9;
	// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodCall::InternalProperties
	RuntimeObject* ___InternalProperties_10;

public:
	inline static int32_t get_offset_of__uri_0() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____uri_0)); }
	inline String_t* get__uri_0() const { return ____uri_0; }
	inline String_t** get_address_of__uri_0() { return &____uri_0; }
	inline void set__uri_0(String_t* value)
	{
		____uri_0 = value;
		Il2CppCodeGenWriteBarrier((&____uri_0), value);
	}

	inline static int32_t get_offset_of__typeName_1() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____typeName_1)); }
	inline String_t* get__typeName_1() const { return ____typeName_1; }
	inline String_t** get_address_of__typeName_1() { return &____typeName_1; }
	inline void set__typeName_1(String_t* value)
	{
		____typeName_1 = value;
		Il2CppCodeGenWriteBarrier((&____typeName_1), value);
	}

	inline static int32_t get_offset_of__methodName_2() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____methodName_2)); }
	inline String_t* get__methodName_2() const { return ____methodName_2; }
	inline String_t** get_address_of__methodName_2() { return &____methodName_2; }
	inline void set__methodName_2(String_t* value)
	{
		____methodName_2 = value;
		Il2CppCodeGenWriteBarrier((&____methodName_2), value);
	}

	inline static int32_t get_offset_of__args_3() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____args_3)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__args_3() const { return ____args_3; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__args_3() { return &____args_3; }
	inline void set__args_3(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____args_3 = value;
		Il2CppCodeGenWriteBarrier((&____args_3), value);
	}

	inline static int32_t get_offset_of__methodSignature_4() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____methodSignature_4)); }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* get__methodSignature_4() const { return ____methodSignature_4; }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532** get_address_of__methodSignature_4() { return &____methodSignature_4; }
	inline void set__methodSignature_4(TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* value)
	{
		____methodSignature_4 = value;
		Il2CppCodeGenWriteBarrier((&____methodSignature_4), value);
	}

	inline static int32_t get_offset_of__methodBase_5() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____methodBase_5)); }
	inline MethodBase_t * get__methodBase_5() const { return ____methodBase_5; }
	inline MethodBase_t ** get_address_of__methodBase_5() { return &____methodBase_5; }
	inline void set__methodBase_5(MethodBase_t * value)
	{
		____methodBase_5 = value;
		Il2CppCodeGenWriteBarrier((&____methodBase_5), value);
	}

	inline static int32_t get_offset_of__callContext_6() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____callContext_6)); }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * get__callContext_6() const { return ____callContext_6; }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 ** get_address_of__callContext_6() { return &____callContext_6; }
	inline void set__callContext_6(LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * value)
	{
		____callContext_6 = value;
		Il2CppCodeGenWriteBarrier((&____callContext_6), value);
	}

	inline static int32_t get_offset_of__targetIdentity_7() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____targetIdentity_7)); }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C * get__targetIdentity_7() const { return ____targetIdentity_7; }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C ** get_address_of__targetIdentity_7() { return &____targetIdentity_7; }
	inline void set__targetIdentity_7(Identity_tF0CD49E50E212E64314E0241852939303E414F1C * value)
	{
		____targetIdentity_7 = value;
		Il2CppCodeGenWriteBarrier((&____targetIdentity_7), value);
	}

	inline static int32_t get_offset_of__genericArguments_8() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ____genericArguments_8)); }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* get__genericArguments_8() const { return ____genericArguments_8; }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532** get_address_of__genericArguments_8() { return &____genericArguments_8; }
	inline void set__genericArguments_8(TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* value)
	{
		____genericArguments_8 = value;
		Il2CppCodeGenWriteBarrier((&____genericArguments_8), value);
	}

	inline static int32_t get_offset_of_ExternalProperties_9() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ___ExternalProperties_9)); }
	inline RuntimeObject* get_ExternalProperties_9() const { return ___ExternalProperties_9; }
	inline RuntimeObject** get_address_of_ExternalProperties_9() { return &___ExternalProperties_9; }
	inline void set_ExternalProperties_9(RuntimeObject* value)
	{
		___ExternalProperties_9 = value;
		Il2CppCodeGenWriteBarrier((&___ExternalProperties_9), value);
	}

	inline static int32_t get_offset_of_InternalProperties_10() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3, ___InternalProperties_10)); }
	inline RuntimeObject* get_InternalProperties_10() const { return ___InternalProperties_10; }
	inline RuntimeObject** get_address_of_InternalProperties_10() { return &___InternalProperties_10; }
	inline void set_InternalProperties_10(RuntimeObject* value)
	{
		___InternalProperties_10 = value;
		Il2CppCodeGenWriteBarrier((&___InternalProperties_10), value);
	}
};

struct MethodCall_t85B750F7999345054735594566D42DDF9C378FD3_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.MethodCall::<>f__switchU24map1F
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map1F_11;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map1F_11() { return static_cast<int32_t>(offsetof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3_StaticFields, ___U3CU3Ef__switchU24map1F_11)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map1F_11() const { return ___U3CU3Ef__switchU24map1F_11; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map1F_11() { return &___U3CU3Ef__switchU24map1F_11; }
	inline void set_U3CU3Ef__switchU24map1F_11(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map1F_11 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map1F_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODCALL_T85B750F7999345054735594566D42DDF9C378FD3_H
#ifndef METHODDICTIONARY_TA35F7EE01E1D34F2D45912618AB057B0FD411A9D_H
#define METHODDICTIONARY_TA35F7EE01E1D34F2D45912618AB057B0FD411A9D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MethodDictionary
struct  MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D  : public RuntimeObject
{
public:
	// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodDictionary::_internalProperties
	RuntimeObject* ____internalProperties_0;
	// System.Runtime.Remoting.Messaging.IMethodMessage System.Runtime.Remoting.Messaging.MethodDictionary::_message
	RuntimeObject* ____message_1;
	// System.String[] System.Runtime.Remoting.Messaging.MethodDictionary::_methodKeys
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ____methodKeys_2;
	// System.Boolean System.Runtime.Remoting.Messaging.MethodDictionary::_ownProperties
	bool ____ownProperties_3;

public:
	inline static int32_t get_offset_of__internalProperties_0() { return static_cast<int32_t>(offsetof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D, ____internalProperties_0)); }
	inline RuntimeObject* get__internalProperties_0() const { return ____internalProperties_0; }
	inline RuntimeObject** get_address_of__internalProperties_0() { return &____internalProperties_0; }
	inline void set__internalProperties_0(RuntimeObject* value)
	{
		____internalProperties_0 = value;
		Il2CppCodeGenWriteBarrier((&____internalProperties_0), value);
	}

	inline static int32_t get_offset_of__message_1() { return static_cast<int32_t>(offsetof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D, ____message_1)); }
	inline RuntimeObject* get__message_1() const { return ____message_1; }
	inline RuntimeObject** get_address_of__message_1() { return &____message_1; }
	inline void set__message_1(RuntimeObject* value)
	{
		____message_1 = value;
		Il2CppCodeGenWriteBarrier((&____message_1), value);
	}

	inline static int32_t get_offset_of__methodKeys_2() { return static_cast<int32_t>(offsetof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D, ____methodKeys_2)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get__methodKeys_2() const { return ____methodKeys_2; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of__methodKeys_2() { return &____methodKeys_2; }
	inline void set__methodKeys_2(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		____methodKeys_2 = value;
		Il2CppCodeGenWriteBarrier((&____methodKeys_2), value);
	}

	inline static int32_t get_offset_of__ownProperties_3() { return static_cast<int32_t>(offsetof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D, ____ownProperties_3)); }
	inline bool get__ownProperties_3() const { return ____ownProperties_3; }
	inline bool* get_address_of__ownProperties_3() { return &____ownProperties_3; }
	inline void set__ownProperties_3(bool value)
	{
		____ownProperties_3 = value;
	}
};

struct MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.MethodDictionary::<>f__switchU24map21
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map21_4;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.MethodDictionary::<>f__switchU24map22
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map22_5;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map21_4() { return static_cast<int32_t>(offsetof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D_StaticFields, ___U3CU3Ef__switchU24map21_4)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map21_4() const { return ___U3CU3Ef__switchU24map21_4; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map21_4() { return &___U3CU3Ef__switchU24map21_4; }
	inline void set_U3CU3Ef__switchU24map21_4(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map21_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map21_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map22_5() { return static_cast<int32_t>(offsetof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D_StaticFields, ___U3CU3Ef__switchU24map22_5)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map22_5() const { return ___U3CU3Ef__switchU24map22_5; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map22_5() { return &___U3CU3Ef__switchU24map22_5; }
	inline void set_U3CU3Ef__switchU24map22_5(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map22_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map22_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODDICTIONARY_TA35F7EE01E1D34F2D45912618AB057B0FD411A9D_H
#ifndef DICTIONARYENUMERATOR_T3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4_H
#define DICTIONARYENUMERATOR_T3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MethodDictionary_DictionaryEnumerator
struct  DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.MethodDictionary System.Runtime.Remoting.Messaging.MethodDictionary_DictionaryEnumerator::_methodDictionary
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D * ____methodDictionary_0;
	// System.Collections.IDictionaryEnumerator System.Runtime.Remoting.Messaging.MethodDictionary_DictionaryEnumerator::_hashtableEnum
	RuntimeObject* ____hashtableEnum_1;
	// System.Int32 System.Runtime.Remoting.Messaging.MethodDictionary_DictionaryEnumerator::_posMethod
	int32_t ____posMethod_2;

public:
	inline static int32_t get_offset_of__methodDictionary_0() { return static_cast<int32_t>(offsetof(DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4, ____methodDictionary_0)); }
	inline MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D * get__methodDictionary_0() const { return ____methodDictionary_0; }
	inline MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D ** get_address_of__methodDictionary_0() { return &____methodDictionary_0; }
	inline void set__methodDictionary_0(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D * value)
	{
		____methodDictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&____methodDictionary_0), value);
	}

	inline static int32_t get_offset_of__hashtableEnum_1() { return static_cast<int32_t>(offsetof(DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4, ____hashtableEnum_1)); }
	inline RuntimeObject* get__hashtableEnum_1() const { return ____hashtableEnum_1; }
	inline RuntimeObject** get_address_of__hashtableEnum_1() { return &____hashtableEnum_1; }
	inline void set__hashtableEnum_1(RuntimeObject* value)
	{
		____hashtableEnum_1 = value;
		Il2CppCodeGenWriteBarrier((&____hashtableEnum_1), value);
	}

	inline static int32_t get_offset_of__posMethod_2() { return static_cast<int32_t>(offsetof(DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4, ____posMethod_2)); }
	inline int32_t get__posMethod_2() const { return ____posMethod_2; }
	inline int32_t* get_address_of__posMethod_2() { return &____posMethod_2; }
	inline void set__posMethod_2(int32_t value)
	{
		____posMethod_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARYENUMERATOR_T3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4_H
#ifndef METHODRESPONSE_T381DAAD69EA6A5CAC84E42D0736613009CD43BFD_H
#define METHODRESPONSE_T381DAAD69EA6A5CAC84E42D0736613009CD43BFD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MethodResponse
struct  MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Messaging.MethodResponse::_methodName
	String_t* ____methodName_0;
	// System.String System.Runtime.Remoting.Messaging.MethodResponse::_uri
	String_t* ____uri_1;
	// System.String System.Runtime.Remoting.Messaging.MethodResponse::_typeName
	String_t* ____typeName_2;
	// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.MethodResponse::_methodBase
	MethodBase_t * ____methodBase_3;
	// System.Object System.Runtime.Remoting.Messaging.MethodResponse::_returnValue
	RuntimeObject * ____returnValue_4;
	// System.Exception System.Runtime.Remoting.Messaging.MethodResponse::_exception
	Exception_t * ____exception_5;
	// System.Type[] System.Runtime.Remoting.Messaging.MethodResponse::_methodSignature
	TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* ____methodSignature_6;
	// System.Runtime.Remoting.Messaging.ArgInfo System.Runtime.Remoting.Messaging.MethodResponse::_inArgInfo
	ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 * ____inArgInfo_7;
	// System.Object[] System.Runtime.Remoting.Messaging.MethodResponse::_args
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____args_8;
	// System.Object[] System.Runtime.Remoting.Messaging.MethodResponse::_outArgs
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____outArgs_9;
	// System.Runtime.Remoting.Messaging.IMethodCallMessage System.Runtime.Remoting.Messaging.MethodResponse::_callMsg
	RuntimeObject* ____callMsg_10;
	// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.MethodResponse::_callContext
	LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * ____callContext_11;
	// System.Runtime.Remoting.Identity System.Runtime.Remoting.Messaging.MethodResponse::_targetIdentity
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C * ____targetIdentity_12;
	// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodResponse::ExternalProperties
	RuntimeObject* ___ExternalProperties_13;
	// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodResponse::InternalProperties
	RuntimeObject* ___InternalProperties_14;

public:
	inline static int32_t get_offset_of__methodName_0() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____methodName_0)); }
	inline String_t* get__methodName_0() const { return ____methodName_0; }
	inline String_t** get_address_of__methodName_0() { return &____methodName_0; }
	inline void set__methodName_0(String_t* value)
	{
		____methodName_0 = value;
		Il2CppCodeGenWriteBarrier((&____methodName_0), value);
	}

	inline static int32_t get_offset_of__uri_1() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____uri_1)); }
	inline String_t* get__uri_1() const { return ____uri_1; }
	inline String_t** get_address_of__uri_1() { return &____uri_1; }
	inline void set__uri_1(String_t* value)
	{
		____uri_1 = value;
		Il2CppCodeGenWriteBarrier((&____uri_1), value);
	}

	inline static int32_t get_offset_of__typeName_2() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____typeName_2)); }
	inline String_t* get__typeName_2() const { return ____typeName_2; }
	inline String_t** get_address_of__typeName_2() { return &____typeName_2; }
	inline void set__typeName_2(String_t* value)
	{
		____typeName_2 = value;
		Il2CppCodeGenWriteBarrier((&____typeName_2), value);
	}

	inline static int32_t get_offset_of__methodBase_3() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____methodBase_3)); }
	inline MethodBase_t * get__methodBase_3() const { return ____methodBase_3; }
	inline MethodBase_t ** get_address_of__methodBase_3() { return &____methodBase_3; }
	inline void set__methodBase_3(MethodBase_t * value)
	{
		____methodBase_3 = value;
		Il2CppCodeGenWriteBarrier((&____methodBase_3), value);
	}

	inline static int32_t get_offset_of__returnValue_4() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____returnValue_4)); }
	inline RuntimeObject * get__returnValue_4() const { return ____returnValue_4; }
	inline RuntimeObject ** get_address_of__returnValue_4() { return &____returnValue_4; }
	inline void set__returnValue_4(RuntimeObject * value)
	{
		____returnValue_4 = value;
		Il2CppCodeGenWriteBarrier((&____returnValue_4), value);
	}

	inline static int32_t get_offset_of__exception_5() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____exception_5)); }
	inline Exception_t * get__exception_5() const { return ____exception_5; }
	inline Exception_t ** get_address_of__exception_5() { return &____exception_5; }
	inline void set__exception_5(Exception_t * value)
	{
		____exception_5 = value;
		Il2CppCodeGenWriteBarrier((&____exception_5), value);
	}

	inline static int32_t get_offset_of__methodSignature_6() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____methodSignature_6)); }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* get__methodSignature_6() const { return ____methodSignature_6; }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532** get_address_of__methodSignature_6() { return &____methodSignature_6; }
	inline void set__methodSignature_6(TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* value)
	{
		____methodSignature_6 = value;
		Il2CppCodeGenWriteBarrier((&____methodSignature_6), value);
	}

	inline static int32_t get_offset_of__inArgInfo_7() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____inArgInfo_7)); }
	inline ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 * get__inArgInfo_7() const { return ____inArgInfo_7; }
	inline ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 ** get_address_of__inArgInfo_7() { return &____inArgInfo_7; }
	inline void set__inArgInfo_7(ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 * value)
	{
		____inArgInfo_7 = value;
		Il2CppCodeGenWriteBarrier((&____inArgInfo_7), value);
	}

	inline static int32_t get_offset_of__args_8() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____args_8)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__args_8() const { return ____args_8; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__args_8() { return &____args_8; }
	inline void set__args_8(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____args_8 = value;
		Il2CppCodeGenWriteBarrier((&____args_8), value);
	}

	inline static int32_t get_offset_of__outArgs_9() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____outArgs_9)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__outArgs_9() const { return ____outArgs_9; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__outArgs_9() { return &____outArgs_9; }
	inline void set__outArgs_9(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____outArgs_9 = value;
		Il2CppCodeGenWriteBarrier((&____outArgs_9), value);
	}

	inline static int32_t get_offset_of__callMsg_10() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____callMsg_10)); }
	inline RuntimeObject* get__callMsg_10() const { return ____callMsg_10; }
	inline RuntimeObject** get_address_of__callMsg_10() { return &____callMsg_10; }
	inline void set__callMsg_10(RuntimeObject* value)
	{
		____callMsg_10 = value;
		Il2CppCodeGenWriteBarrier((&____callMsg_10), value);
	}

	inline static int32_t get_offset_of__callContext_11() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____callContext_11)); }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * get__callContext_11() const { return ____callContext_11; }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 ** get_address_of__callContext_11() { return &____callContext_11; }
	inline void set__callContext_11(LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * value)
	{
		____callContext_11 = value;
		Il2CppCodeGenWriteBarrier((&____callContext_11), value);
	}

	inline static int32_t get_offset_of__targetIdentity_12() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ____targetIdentity_12)); }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C * get__targetIdentity_12() const { return ____targetIdentity_12; }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C ** get_address_of__targetIdentity_12() { return &____targetIdentity_12; }
	inline void set__targetIdentity_12(Identity_tF0CD49E50E212E64314E0241852939303E414F1C * value)
	{
		____targetIdentity_12 = value;
		Il2CppCodeGenWriteBarrier((&____targetIdentity_12), value);
	}

	inline static int32_t get_offset_of_ExternalProperties_13() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ___ExternalProperties_13)); }
	inline RuntimeObject* get_ExternalProperties_13() const { return ___ExternalProperties_13; }
	inline RuntimeObject** get_address_of_ExternalProperties_13() { return &___ExternalProperties_13; }
	inline void set_ExternalProperties_13(RuntimeObject* value)
	{
		___ExternalProperties_13 = value;
		Il2CppCodeGenWriteBarrier((&___ExternalProperties_13), value);
	}

	inline static int32_t get_offset_of_InternalProperties_14() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD, ___InternalProperties_14)); }
	inline RuntimeObject* get_InternalProperties_14() const { return ___InternalProperties_14; }
	inline RuntimeObject** get_address_of_InternalProperties_14() { return &___InternalProperties_14; }
	inline void set_InternalProperties_14(RuntimeObject* value)
	{
		___InternalProperties_14 = value;
		Il2CppCodeGenWriteBarrier((&___InternalProperties_14), value);
	}
};

struct MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.MethodResponse::<>f__switchU24map25
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map25_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map25_15() { return static_cast<int32_t>(offsetof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD_StaticFields, ___U3CU3Ef__switchU24map25_15)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map25_15() const { return ___U3CU3Ef__switchU24map25_15; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map25_15() { return &___U3CU3Ef__switchU24map25_15; }
	inline void set_U3CU3Ef__switchU24map25_15(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map25_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map25_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODRESPONSE_T381DAAD69EA6A5CAC84E42D0736613009CD43BFD_H
#ifndef OBJREFSURROGATE_TC4BC6525B31A9362AF31243F87A6E4FCB13A37DA_H
#define OBJREFSURROGATE_TC4BC6525B31A9362AF31243F87A6E4FCB13A37DA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ObjRefSurrogate
struct  ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJREFSURROGATE_TC4BC6525B31A9362AF31243F87A6E4FCB13A37DA_H
#ifndef REMOTINGSURROGATE_TD5197EE223360C43095A27049D0F97F699D13707_H
#define REMOTINGSURROGATE_TD5197EE223360C43095A27049D0F97F699D13707_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.RemotingSurrogate
struct  RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTINGSURROGATE_TD5197EE223360C43095A27049D0F97F699D13707_H
#ifndef REMOTINGSURROGATESELECTOR_T890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_H
#define REMOTINGSURROGATESELECTOR_T890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.RemotingSurrogateSelector
struct  RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2  : public RuntimeObject
{
public:
	// System.Runtime.Serialization.ISurrogateSelector System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::_next
	RuntimeObject* ____next_3;

public:
	inline static int32_t get_offset_of__next_3() { return static_cast<int32_t>(offsetof(RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2, ____next_3)); }
	inline RuntimeObject* get__next_3() const { return ____next_3; }
	inline RuntimeObject** get_address_of__next_3() { return &____next_3; }
	inline void set__next_3(RuntimeObject* value)
	{
		____next_3 = value;
		Il2CppCodeGenWriteBarrier((&____next_3), value);
	}
};

struct RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields
{
public:
	// System.Type System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::s_cachedTypeObjRef
	Type_t * ___s_cachedTypeObjRef_0;
	// System.Runtime.Remoting.Messaging.ObjRefSurrogate System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::_objRefSurrogate
	ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA * ____objRefSurrogate_1;
	// System.Runtime.Remoting.Messaging.RemotingSurrogate System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::_objRemotingSurrogate
	RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707 * ____objRemotingSurrogate_2;

public:
	inline static int32_t get_offset_of_s_cachedTypeObjRef_0() { return static_cast<int32_t>(offsetof(RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields, ___s_cachedTypeObjRef_0)); }
	inline Type_t * get_s_cachedTypeObjRef_0() const { return ___s_cachedTypeObjRef_0; }
	inline Type_t ** get_address_of_s_cachedTypeObjRef_0() { return &___s_cachedTypeObjRef_0; }
	inline void set_s_cachedTypeObjRef_0(Type_t * value)
	{
		___s_cachedTypeObjRef_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_cachedTypeObjRef_0), value);
	}

	inline static int32_t get_offset_of__objRefSurrogate_1() { return static_cast<int32_t>(offsetof(RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields, ____objRefSurrogate_1)); }
	inline ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA * get__objRefSurrogate_1() const { return ____objRefSurrogate_1; }
	inline ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA ** get_address_of__objRefSurrogate_1() { return &____objRefSurrogate_1; }
	inline void set__objRefSurrogate_1(ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA * value)
	{
		____objRefSurrogate_1 = value;
		Il2CppCodeGenWriteBarrier((&____objRefSurrogate_1), value);
	}

	inline static int32_t get_offset_of__objRemotingSurrogate_2() { return static_cast<int32_t>(offsetof(RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields, ____objRemotingSurrogate_2)); }
	inline RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707 * get__objRemotingSurrogate_2() const { return ____objRemotingSurrogate_2; }
	inline RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707 ** get_address_of__objRemotingSurrogate_2() { return &____objRemotingSurrogate_2; }
	inline void set__objRemotingSurrogate_2(RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707 * value)
	{
		____objRemotingSurrogate_2 = value;
		Il2CppCodeGenWriteBarrier((&____objRemotingSurrogate_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTINGSURROGATESELECTOR_T890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_H
#ifndef RETURNMESSAGE_T81F6C70C9CF551ACF6EF3582C87ACD0861B41F89_H
#define RETURNMESSAGE_T81F6C70C9CF551ACF6EF3582C87ACD0861B41F89_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ReturnMessage
struct  ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89  : public RuntimeObject
{
public:
	// System.Object[] System.Runtime.Remoting.Messaging.ReturnMessage::_outArgs
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____outArgs_0;
	// System.Object[] System.Runtime.Remoting.Messaging.ReturnMessage::_args
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____args_1;
	// System.Int32 System.Runtime.Remoting.Messaging.ReturnMessage::_outArgsCount
	int32_t ____outArgsCount_2;
	// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.ReturnMessage::_callCtx
	LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * ____callCtx_3;
	// System.Object System.Runtime.Remoting.Messaging.ReturnMessage::_returnValue
	RuntimeObject * ____returnValue_4;
	// System.String System.Runtime.Remoting.Messaging.ReturnMessage::_uri
	String_t* ____uri_5;
	// System.Exception System.Runtime.Remoting.Messaging.ReturnMessage::_exception
	Exception_t * ____exception_6;
	// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.ReturnMessage::_methodBase
	MethodBase_t * ____methodBase_7;
	// System.String System.Runtime.Remoting.Messaging.ReturnMessage::_methodName
	String_t* ____methodName_8;
	// System.Type[] System.Runtime.Remoting.Messaging.ReturnMessage::_methodSignature
	TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* ____methodSignature_9;
	// System.String System.Runtime.Remoting.Messaging.ReturnMessage::_typeName
	String_t* ____typeName_10;
	// System.Runtime.Remoting.Messaging.MethodReturnDictionary System.Runtime.Remoting.Messaging.ReturnMessage::_properties
	MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66 * ____properties_11;
	// System.Runtime.Remoting.Identity System.Runtime.Remoting.Messaging.ReturnMessage::_targetIdentity
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C * ____targetIdentity_12;
	// System.Runtime.Remoting.Messaging.ArgInfo System.Runtime.Remoting.Messaging.ReturnMessage::_inArgInfo
	ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 * ____inArgInfo_13;

public:
	inline static int32_t get_offset_of__outArgs_0() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____outArgs_0)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__outArgs_0() const { return ____outArgs_0; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__outArgs_0() { return &____outArgs_0; }
	inline void set__outArgs_0(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____outArgs_0 = value;
		Il2CppCodeGenWriteBarrier((&____outArgs_0), value);
	}

	inline static int32_t get_offset_of__args_1() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____args_1)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__args_1() const { return ____args_1; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__args_1() { return &____args_1; }
	inline void set__args_1(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____args_1 = value;
		Il2CppCodeGenWriteBarrier((&____args_1), value);
	}

	inline static int32_t get_offset_of__outArgsCount_2() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____outArgsCount_2)); }
	inline int32_t get__outArgsCount_2() const { return ____outArgsCount_2; }
	inline int32_t* get_address_of__outArgsCount_2() { return &____outArgsCount_2; }
	inline void set__outArgsCount_2(int32_t value)
	{
		____outArgsCount_2 = value;
	}

	inline static int32_t get_offset_of__callCtx_3() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____callCtx_3)); }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * get__callCtx_3() const { return ____callCtx_3; }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 ** get_address_of__callCtx_3() { return &____callCtx_3; }
	inline void set__callCtx_3(LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * value)
	{
		____callCtx_3 = value;
		Il2CppCodeGenWriteBarrier((&____callCtx_3), value);
	}

	inline static int32_t get_offset_of__returnValue_4() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____returnValue_4)); }
	inline RuntimeObject * get__returnValue_4() const { return ____returnValue_4; }
	inline RuntimeObject ** get_address_of__returnValue_4() { return &____returnValue_4; }
	inline void set__returnValue_4(RuntimeObject * value)
	{
		____returnValue_4 = value;
		Il2CppCodeGenWriteBarrier((&____returnValue_4), value);
	}

	inline static int32_t get_offset_of__uri_5() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____uri_5)); }
	inline String_t* get__uri_5() const { return ____uri_5; }
	inline String_t** get_address_of__uri_5() { return &____uri_5; }
	inline void set__uri_5(String_t* value)
	{
		____uri_5 = value;
		Il2CppCodeGenWriteBarrier((&____uri_5), value);
	}

	inline static int32_t get_offset_of__exception_6() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____exception_6)); }
	inline Exception_t * get__exception_6() const { return ____exception_6; }
	inline Exception_t ** get_address_of__exception_6() { return &____exception_6; }
	inline void set__exception_6(Exception_t * value)
	{
		____exception_6 = value;
		Il2CppCodeGenWriteBarrier((&____exception_6), value);
	}

	inline static int32_t get_offset_of__methodBase_7() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____methodBase_7)); }
	inline MethodBase_t * get__methodBase_7() const { return ____methodBase_7; }
	inline MethodBase_t ** get_address_of__methodBase_7() { return &____methodBase_7; }
	inline void set__methodBase_7(MethodBase_t * value)
	{
		____methodBase_7 = value;
		Il2CppCodeGenWriteBarrier((&____methodBase_7), value);
	}

	inline static int32_t get_offset_of__methodName_8() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____methodName_8)); }
	inline String_t* get__methodName_8() const { return ____methodName_8; }
	inline String_t** get_address_of__methodName_8() { return &____methodName_8; }
	inline void set__methodName_8(String_t* value)
	{
		____methodName_8 = value;
		Il2CppCodeGenWriteBarrier((&____methodName_8), value);
	}

	inline static int32_t get_offset_of__methodSignature_9() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____methodSignature_9)); }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* get__methodSignature_9() const { return ____methodSignature_9; }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532** get_address_of__methodSignature_9() { return &____methodSignature_9; }
	inline void set__methodSignature_9(TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* value)
	{
		____methodSignature_9 = value;
		Il2CppCodeGenWriteBarrier((&____methodSignature_9), value);
	}

	inline static int32_t get_offset_of__typeName_10() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____typeName_10)); }
	inline String_t* get__typeName_10() const { return ____typeName_10; }
	inline String_t** get_address_of__typeName_10() { return &____typeName_10; }
	inline void set__typeName_10(String_t* value)
	{
		____typeName_10 = value;
		Il2CppCodeGenWriteBarrier((&____typeName_10), value);
	}

	inline static int32_t get_offset_of__properties_11() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____properties_11)); }
	inline MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66 * get__properties_11() const { return ____properties_11; }
	inline MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66 ** get_address_of__properties_11() { return &____properties_11; }
	inline void set__properties_11(MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66 * value)
	{
		____properties_11 = value;
		Il2CppCodeGenWriteBarrier((&____properties_11), value);
	}

	inline static int32_t get_offset_of__targetIdentity_12() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____targetIdentity_12)); }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C * get__targetIdentity_12() const { return ____targetIdentity_12; }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C ** get_address_of__targetIdentity_12() { return &____targetIdentity_12; }
	inline void set__targetIdentity_12(Identity_tF0CD49E50E212E64314E0241852939303E414F1C * value)
	{
		____targetIdentity_12 = value;
		Il2CppCodeGenWriteBarrier((&____targetIdentity_12), value);
	}

	inline static int32_t get_offset_of__inArgInfo_13() { return static_cast<int32_t>(offsetof(ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89, ____inArgInfo_13)); }
	inline ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 * get__inArgInfo_13() const { return ____inArgInfo_13; }
	inline ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 ** get_address_of__inArgInfo_13() { return &____inArgInfo_13; }
	inline void set__inArgInfo_13(ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3 * value)
	{
		____inArgInfo_13 = value;
		Il2CppCodeGenWriteBarrier((&____inArgInfo_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RETURNMESSAGE_T81F6C70C9CF551ACF6EF3582C87ACD0861B41F89_H
#ifndef SERVERCONTEXTTERMINATORSINK_TD6DFD5D259D3377EB5E770C520190215895AFA24_H
#define SERVERCONTEXTTERMINATORSINK_TD6DFD5D259D3377EB5E770C520190215895AFA24_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ServerContextTerminatorSink
struct  ServerContextTerminatorSink_tD6DFD5D259D3377EB5E770C520190215895AFA24  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERVERCONTEXTTERMINATORSINK_TD6DFD5D259D3377EB5E770C520190215895AFA24_H
#ifndef SERVEROBJECTREPLYSINK_T97058531C779A237BF58FDA6CFB4263A8A23521B_H
#define SERVEROBJECTREPLYSINK_T97058531C779A237BF58FDA6CFB4263A8A23521B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ServerObjectReplySink
struct  ServerObjectReplySink_t97058531C779A237BF58FDA6CFB4263A8A23521B  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Messaging.ServerObjectReplySink::_replySink
	RuntimeObject* ____replySink_0;
	// System.Runtime.Remoting.ServerIdentity System.Runtime.Remoting.Messaging.ServerObjectReplySink::_identity
	ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C * ____identity_1;

public:
	inline static int32_t get_offset_of__replySink_0() { return static_cast<int32_t>(offsetof(ServerObjectReplySink_t97058531C779A237BF58FDA6CFB4263A8A23521B, ____replySink_0)); }
	inline RuntimeObject* get__replySink_0() const { return ____replySink_0; }
	inline RuntimeObject** get_address_of__replySink_0() { return &____replySink_0; }
	inline void set__replySink_0(RuntimeObject* value)
	{
		____replySink_0 = value;
		Il2CppCodeGenWriteBarrier((&____replySink_0), value);
	}

	inline static int32_t get_offset_of__identity_1() { return static_cast<int32_t>(offsetof(ServerObjectReplySink_t97058531C779A237BF58FDA6CFB4263A8A23521B, ____identity_1)); }
	inline ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C * get__identity_1() const { return ____identity_1; }
	inline ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C ** get_address_of__identity_1() { return &____identity_1; }
	inline void set__identity_1(ServerIdentity_t3C5F8BAEFAC94CF69694273ACCB6CB41355E0B5C * value)
	{
		____identity_1 = value;
		Il2CppCodeGenWriteBarrier((&____identity_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERVEROBJECTREPLYSINK_T97058531C779A237BF58FDA6CFB4263A8A23521B_H
#ifndef SERVEROBJECTTERMINATORSINK_TA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373_H
#define SERVEROBJECTTERMINATORSINK_TA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ServerObjectTerminatorSink
struct  ServerObjectTerminatorSink_tA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Messaging.ServerObjectTerminatorSink::_nextSink
	RuntimeObject* ____nextSink_0;

public:
	inline static int32_t get_offset_of__nextSink_0() { return static_cast<int32_t>(offsetof(ServerObjectTerminatorSink_tA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373, ____nextSink_0)); }
	inline RuntimeObject* get__nextSink_0() const { return ____nextSink_0; }
	inline RuntimeObject** get_address_of__nextSink_0() { return &____nextSink_0; }
	inline void set__nextSink_0(RuntimeObject* value)
	{
		____nextSink_0 = value;
		Il2CppCodeGenWriteBarrier((&____nextSink_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERVEROBJECTTERMINATORSINK_TA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373_H
#ifndef STACKBUILDERSINK_T0714062B96AD616BED7912BB6D8B36EEB08743AD_H
#define STACKBUILDERSINK_T0714062B96AD616BED7912BB6D8B36EEB08743AD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.StackBuilderSink
struct  StackBuilderSink_t0714062B96AD616BED7912BB6D8B36EEB08743AD  : public RuntimeObject
{
public:
	// System.MarshalByRefObject System.Runtime.Remoting.Messaging.StackBuilderSink::_target
	MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 * ____target_0;
	// System.Runtime.Remoting.Proxies.RealProxy System.Runtime.Remoting.Messaging.StackBuilderSink::_rp
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC * ____rp_1;

public:
	inline static int32_t get_offset_of__target_0() { return static_cast<int32_t>(offsetof(StackBuilderSink_t0714062B96AD616BED7912BB6D8B36EEB08743AD, ____target_0)); }
	inline MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 * get__target_0() const { return ____target_0; }
	inline MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 ** get_address_of__target_0() { return &____target_0; }
	inline void set__target_0(MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 * value)
	{
		____target_0 = value;
		Il2CppCodeGenWriteBarrier((&____target_0), value);
	}

	inline static int32_t get_offset_of__rp_1() { return static_cast<int32_t>(offsetof(StackBuilderSink_t0714062B96AD616BED7912BB6D8B36EEB08743AD, ____rp_1)); }
	inline RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC * get__rp_1() const { return ____rp_1; }
	inline RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC ** get_address_of__rp_1() { return &____rp_1; }
	inline void set__rp_1(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC * value)
	{
		____rp_1 = value;
		Il2CppCodeGenWriteBarrier((&____rp_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STACKBUILDERSINK_T0714062B96AD616BED7912BB6D8B36EEB08743AD_H
#ifndef OBJREF_T2E5ABE92709BF374001BFE686A4709CADAFDC43E_H
#define OBJREF_T2E5ABE92709BF374001BFE686A4709CADAFDC43E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ObjRef
struct  ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.IChannelInfo System.Runtime.Remoting.ObjRef::channel_info
	RuntimeObject* ___channel_info_0;
	// System.String System.Runtime.Remoting.ObjRef::uri
	String_t* ___uri_1;
	// System.Runtime.Remoting.IRemotingTypeInfo System.Runtime.Remoting.ObjRef::typeInfo
	RuntimeObject* ___typeInfo_2;
	// System.Runtime.Remoting.IEnvoyInfo System.Runtime.Remoting.ObjRef::envoyInfo
	RuntimeObject* ___envoyInfo_3;
	// System.Int32 System.Runtime.Remoting.ObjRef::flags
	int32_t ___flags_4;
	// System.Type System.Runtime.Remoting.ObjRef::_serverType
	Type_t * ____serverType_5;

public:
	inline static int32_t get_offset_of_channel_info_0() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E, ___channel_info_0)); }
	inline RuntimeObject* get_channel_info_0() const { return ___channel_info_0; }
	inline RuntimeObject** get_address_of_channel_info_0() { return &___channel_info_0; }
	inline void set_channel_info_0(RuntimeObject* value)
	{
		___channel_info_0 = value;
		Il2CppCodeGenWriteBarrier((&___channel_info_0), value);
	}

	inline static int32_t get_offset_of_uri_1() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E, ___uri_1)); }
	inline String_t* get_uri_1() const { return ___uri_1; }
	inline String_t** get_address_of_uri_1() { return &___uri_1; }
	inline void set_uri_1(String_t* value)
	{
		___uri_1 = value;
		Il2CppCodeGenWriteBarrier((&___uri_1), value);
	}

	inline static int32_t get_offset_of_typeInfo_2() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E, ___typeInfo_2)); }
	inline RuntimeObject* get_typeInfo_2() const { return ___typeInfo_2; }
	inline RuntimeObject** get_address_of_typeInfo_2() { return &___typeInfo_2; }
	inline void set_typeInfo_2(RuntimeObject* value)
	{
		___typeInfo_2 = value;
		Il2CppCodeGenWriteBarrier((&___typeInfo_2), value);
	}

	inline static int32_t get_offset_of_envoyInfo_3() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E, ___envoyInfo_3)); }
	inline RuntimeObject* get_envoyInfo_3() const { return ___envoyInfo_3; }
	inline RuntimeObject** get_address_of_envoyInfo_3() { return &___envoyInfo_3; }
	inline void set_envoyInfo_3(RuntimeObject* value)
	{
		___envoyInfo_3 = value;
		Il2CppCodeGenWriteBarrier((&___envoyInfo_3), value);
	}

	inline static int32_t get_offset_of_flags_4() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E, ___flags_4)); }
	inline int32_t get_flags_4() const { return ___flags_4; }
	inline int32_t* get_address_of_flags_4() { return &___flags_4; }
	inline void set_flags_4(int32_t value)
	{
		___flags_4 = value;
	}

	inline static int32_t get_offset_of__serverType_5() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E, ____serverType_5)); }
	inline Type_t * get__serverType_5() const { return ____serverType_5; }
	inline Type_t ** get_address_of__serverType_5() { return &____serverType_5; }
	inline void set__serverType_5(Type_t * value)
	{
		____serverType_5 = value;
		Il2CppCodeGenWriteBarrier((&____serverType_5), value);
	}
};

struct ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields
{
public:
	// System.Int32 System.Runtime.Remoting.ObjRef::MarshalledObjectRef
	int32_t ___MarshalledObjectRef_6;
	// System.Int32 System.Runtime.Remoting.ObjRef::WellKnowObjectRef
	int32_t ___WellKnowObjectRef_7;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.ObjRef::<>f__switchU24map26
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map26_8;

public:
	inline static int32_t get_offset_of_MarshalledObjectRef_6() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields, ___MarshalledObjectRef_6)); }
	inline int32_t get_MarshalledObjectRef_6() const { return ___MarshalledObjectRef_6; }
	inline int32_t* get_address_of_MarshalledObjectRef_6() { return &___MarshalledObjectRef_6; }
	inline void set_MarshalledObjectRef_6(int32_t value)
	{
		___MarshalledObjectRef_6 = value;
	}

	inline static int32_t get_offset_of_WellKnowObjectRef_7() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields, ___WellKnowObjectRef_7)); }
	inline int32_t get_WellKnowObjectRef_7() const { return ___WellKnowObjectRef_7; }
	inline int32_t* get_address_of_WellKnowObjectRef_7() { return &___WellKnowObjectRef_7; }
	inline void set_WellKnowObjectRef_7(int32_t value)
	{
		___WellKnowObjectRef_7 = value;
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map26_8() { return static_cast<int32_t>(offsetof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields, ___U3CU3Ef__switchU24map26_8)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map26_8() const { return ___U3CU3Ef__switchU24map26_8; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map26_8() { return &___U3CU3Ef__switchU24map26_8; }
	inline void set_U3CU3Ef__switchU24map26_8(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map26_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map26_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJREF_T2E5ABE92709BF374001BFE686A4709CADAFDC43E_H
#ifndef PROVIDERDATA_TF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB_H
#define PROVIDERDATA_TF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ProviderData
struct  ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.ProviderData::Ref
	String_t* ___Ref_0;
	// System.String System.Runtime.Remoting.ProviderData::Type
	String_t* ___Type_1;
	// System.String System.Runtime.Remoting.ProviderData::Id
	String_t* ___Id_2;
	// System.Collections.Hashtable System.Runtime.Remoting.ProviderData::CustomProperties
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___CustomProperties_3;
	// System.Collections.IList System.Runtime.Remoting.ProviderData::CustomData
	RuntimeObject* ___CustomData_4;

public:
	inline static int32_t get_offset_of_Ref_0() { return static_cast<int32_t>(offsetof(ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB, ___Ref_0)); }
	inline String_t* get_Ref_0() const { return ___Ref_0; }
	inline String_t** get_address_of_Ref_0() { return &___Ref_0; }
	inline void set_Ref_0(String_t* value)
	{
		___Ref_0 = value;
		Il2CppCodeGenWriteBarrier((&___Ref_0), value);
	}

	inline static int32_t get_offset_of_Type_1() { return static_cast<int32_t>(offsetof(ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB, ___Type_1)); }
	inline String_t* get_Type_1() const { return ___Type_1; }
	inline String_t** get_address_of_Type_1() { return &___Type_1; }
	inline void set_Type_1(String_t* value)
	{
		___Type_1 = value;
		Il2CppCodeGenWriteBarrier((&___Type_1), value);
	}

	inline static int32_t get_offset_of_Id_2() { return static_cast<int32_t>(offsetof(ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB, ___Id_2)); }
	inline String_t* get_Id_2() const { return ___Id_2; }
	inline String_t** get_address_of_Id_2() { return &___Id_2; }
	inline void set_Id_2(String_t* value)
	{
		___Id_2 = value;
		Il2CppCodeGenWriteBarrier((&___Id_2), value);
	}

	inline static int32_t get_offset_of_CustomProperties_3() { return static_cast<int32_t>(offsetof(ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB, ___CustomProperties_3)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_CustomProperties_3() const { return ___CustomProperties_3; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_CustomProperties_3() { return &___CustomProperties_3; }
	inline void set_CustomProperties_3(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___CustomProperties_3 = value;
		Il2CppCodeGenWriteBarrier((&___CustomProperties_3), value);
	}

	inline static int32_t get_offset_of_CustomData_4() { return static_cast<int32_t>(offsetof(ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB, ___CustomData_4)); }
	inline RuntimeObject* get_CustomData_4() const { return ___CustomData_4; }
	inline RuntimeObject** get_address_of_CustomData_4() { return &___CustomData_4; }
	inline void set_CustomData_4(RuntimeObject* value)
	{
		___CustomData_4 = value;
		Il2CppCodeGenWriteBarrier((&___CustomData_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROVIDERDATA_TF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB_H
#ifndef REALPROXY_TC971069F7F85FD850F1C09B18D93E965629C11DC_H
#define REALPROXY_TC971069F7F85FD850F1C09B18D93E965629C11DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Proxies.RealProxy
struct  RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC  : public RuntimeObject
{
public:
	// System.Type System.Runtime.Remoting.Proxies.RealProxy::class_to_proxy
	Type_t * ___class_to_proxy_0;
	// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Proxies.RealProxy::_targetContext
	Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * ____targetContext_1;
	// System.MarshalByRefObject System.Runtime.Remoting.Proxies.RealProxy::_server
	MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 * ____server_2;
	// System.Int32 System.Runtime.Remoting.Proxies.RealProxy::_targetDomainId
	int32_t ____targetDomainId_3;
	// System.String System.Runtime.Remoting.Proxies.RealProxy::_targetUri
	String_t* ____targetUri_4;
	// System.Runtime.Remoting.Identity System.Runtime.Remoting.Proxies.RealProxy::_objectIdentity
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C * ____objectIdentity_5;
	// System.Object System.Runtime.Remoting.Proxies.RealProxy::_objTP
	RuntimeObject * ____objTP_6;
	// System.Object System.Runtime.Remoting.Proxies.RealProxy::_stubData
	RuntimeObject * ____stubData_7;

public:
	inline static int32_t get_offset_of_class_to_proxy_0() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ___class_to_proxy_0)); }
	inline Type_t * get_class_to_proxy_0() const { return ___class_to_proxy_0; }
	inline Type_t ** get_address_of_class_to_proxy_0() { return &___class_to_proxy_0; }
	inline void set_class_to_proxy_0(Type_t * value)
	{
		___class_to_proxy_0 = value;
		Il2CppCodeGenWriteBarrier((&___class_to_proxy_0), value);
	}

	inline static int32_t get_offset_of__targetContext_1() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____targetContext_1)); }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * get__targetContext_1() const { return ____targetContext_1; }
	inline Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 ** get_address_of__targetContext_1() { return &____targetContext_1; }
	inline void set__targetContext_1(Context_tC9A59044A4AB0B4896882D2288C2BA5C1D160857 * value)
	{
		____targetContext_1 = value;
		Il2CppCodeGenWriteBarrier((&____targetContext_1), value);
	}

	inline static int32_t get_offset_of__server_2() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____server_2)); }
	inline MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 * get__server_2() const { return ____server_2; }
	inline MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 ** get_address_of__server_2() { return &____server_2; }
	inline void set__server_2(MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4 * value)
	{
		____server_2 = value;
		Il2CppCodeGenWriteBarrier((&____server_2), value);
	}

	inline static int32_t get_offset_of__targetDomainId_3() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____targetDomainId_3)); }
	inline int32_t get__targetDomainId_3() const { return ____targetDomainId_3; }
	inline int32_t* get_address_of__targetDomainId_3() { return &____targetDomainId_3; }
	inline void set__targetDomainId_3(int32_t value)
	{
		____targetDomainId_3 = value;
	}

	inline static int32_t get_offset_of__targetUri_4() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____targetUri_4)); }
	inline String_t* get__targetUri_4() const { return ____targetUri_4; }
	inline String_t** get_address_of__targetUri_4() { return &____targetUri_4; }
	inline void set__targetUri_4(String_t* value)
	{
		____targetUri_4 = value;
		Il2CppCodeGenWriteBarrier((&____targetUri_4), value);
	}

	inline static int32_t get_offset_of__objectIdentity_5() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____objectIdentity_5)); }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C * get__objectIdentity_5() const { return ____objectIdentity_5; }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C ** get_address_of__objectIdentity_5() { return &____objectIdentity_5; }
	inline void set__objectIdentity_5(Identity_tF0CD49E50E212E64314E0241852939303E414F1C * value)
	{
		____objectIdentity_5 = value;
		Il2CppCodeGenWriteBarrier((&____objectIdentity_5), value);
	}

	inline static int32_t get_offset_of__objTP_6() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____objTP_6)); }
	inline RuntimeObject * get__objTP_6() const { return ____objTP_6; }
	inline RuntimeObject ** get_address_of__objTP_6() { return &____objTP_6; }
	inline void set__objTP_6(RuntimeObject * value)
	{
		____objTP_6 = value;
		Il2CppCodeGenWriteBarrier((&____objTP_6), value);
	}

	inline static int32_t get_offset_of__stubData_7() { return static_cast<int32_t>(offsetof(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC, ____stubData_7)); }
	inline RuntimeObject * get__stubData_7() const { return ____stubData_7; }
	inline RuntimeObject ** get_address_of__stubData_7() { return &____stubData_7; }
	inline void set__stubData_7(RuntimeObject * value)
	{
		____stubData_7 = value;
		Il2CppCodeGenWriteBarrier((&____stubData_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REALPROXY_TC971069F7F85FD850F1C09B18D93E965629C11DC_H
#ifndef TRANSPARENTPROXY_T6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82_H
#define TRANSPARENTPROXY_T6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Proxies.TransparentProxy
struct  TransparentProxy_t6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82  : public RuntimeObject
{
public:
	// System.Runtime.Remoting.Proxies.RealProxy System.Runtime.Remoting.Proxies.TransparentProxy::_rp
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC * ____rp_0;

public:
	inline static int32_t get_offset_of__rp_0() { return static_cast<int32_t>(offsetof(TransparentProxy_t6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82, ____rp_0)); }
	inline RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC * get__rp_0() const { return ____rp_0; }
	inline RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC ** get_address_of__rp_0() { return &____rp_0; }
	inline void set__rp_0(RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC * value)
	{
		____rp_0 = value;
		Il2CppCodeGenWriteBarrier((&____rp_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRANSPARENTPROXY_T6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82_H
#ifndef REMOTINGCONFIGURATION_T8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_H
#define REMOTINGCONFIGURATION_T8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.RemotingConfiguration
struct  RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE  : public RuntimeObject
{
public:

public:
};

struct RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields
{
public:
	// System.String System.Runtime.Remoting.RemotingConfiguration::applicationID
	String_t* ___applicationID_0;
	// System.String System.Runtime.Remoting.RemotingConfiguration::applicationName
	String_t* ___applicationName_1;
	// System.String System.Runtime.Remoting.RemotingConfiguration::processGuid
	String_t* ___processGuid_2;
	// System.Boolean System.Runtime.Remoting.RemotingConfiguration::defaultConfigRead
	bool ___defaultConfigRead_3;
	// System.Boolean System.Runtime.Remoting.RemotingConfiguration::defaultDelayedConfigRead
	bool ___defaultDelayedConfigRead_4;
	// System.String System.Runtime.Remoting.RemotingConfiguration::_errorMode
	String_t* ____errorMode_5;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::wellKnownClientEntries
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___wellKnownClientEntries_6;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::activatedClientEntries
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___activatedClientEntries_7;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::wellKnownServiceEntries
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___wellKnownServiceEntries_8;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::activatedServiceEntries
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___activatedServiceEntries_9;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::channelTemplates
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___channelTemplates_10;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::clientProviderTemplates
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___clientProviderTemplates_11;
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingConfiguration::serverProviderTemplates
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___serverProviderTemplates_12;

public:
	inline static int32_t get_offset_of_applicationID_0() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___applicationID_0)); }
	inline String_t* get_applicationID_0() const { return ___applicationID_0; }
	inline String_t** get_address_of_applicationID_0() { return &___applicationID_0; }
	inline void set_applicationID_0(String_t* value)
	{
		___applicationID_0 = value;
		Il2CppCodeGenWriteBarrier((&___applicationID_0), value);
	}

	inline static int32_t get_offset_of_applicationName_1() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___applicationName_1)); }
	inline String_t* get_applicationName_1() const { return ___applicationName_1; }
	inline String_t** get_address_of_applicationName_1() { return &___applicationName_1; }
	inline void set_applicationName_1(String_t* value)
	{
		___applicationName_1 = value;
		Il2CppCodeGenWriteBarrier((&___applicationName_1), value);
	}

	inline static int32_t get_offset_of_processGuid_2() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___processGuid_2)); }
	inline String_t* get_processGuid_2() const { return ___processGuid_2; }
	inline String_t** get_address_of_processGuid_2() { return &___processGuid_2; }
	inline void set_processGuid_2(String_t* value)
	{
		___processGuid_2 = value;
		Il2CppCodeGenWriteBarrier((&___processGuid_2), value);
	}

	inline static int32_t get_offset_of_defaultConfigRead_3() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___defaultConfigRead_3)); }
	inline bool get_defaultConfigRead_3() const { return ___defaultConfigRead_3; }
	inline bool* get_address_of_defaultConfigRead_3() { return &___defaultConfigRead_3; }
	inline void set_defaultConfigRead_3(bool value)
	{
		___defaultConfigRead_3 = value;
	}

	inline static int32_t get_offset_of_defaultDelayedConfigRead_4() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___defaultDelayedConfigRead_4)); }
	inline bool get_defaultDelayedConfigRead_4() const { return ___defaultDelayedConfigRead_4; }
	inline bool* get_address_of_defaultDelayedConfigRead_4() { return &___defaultDelayedConfigRead_4; }
	inline void set_defaultDelayedConfigRead_4(bool value)
	{
		___defaultDelayedConfigRead_4 = value;
	}

	inline static int32_t get_offset_of__errorMode_5() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ____errorMode_5)); }
	inline String_t* get__errorMode_5() const { return ____errorMode_5; }
	inline String_t** get_address_of__errorMode_5() { return &____errorMode_5; }
	inline void set__errorMode_5(String_t* value)
	{
		____errorMode_5 = value;
		Il2CppCodeGenWriteBarrier((&____errorMode_5), value);
	}

	inline static int32_t get_offset_of_wellKnownClientEntries_6() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___wellKnownClientEntries_6)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_wellKnownClientEntries_6() const { return ___wellKnownClientEntries_6; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_wellKnownClientEntries_6() { return &___wellKnownClientEntries_6; }
	inline void set_wellKnownClientEntries_6(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___wellKnownClientEntries_6 = value;
		Il2CppCodeGenWriteBarrier((&___wellKnownClientEntries_6), value);
	}

	inline static int32_t get_offset_of_activatedClientEntries_7() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___activatedClientEntries_7)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_activatedClientEntries_7() const { return ___activatedClientEntries_7; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_activatedClientEntries_7() { return &___activatedClientEntries_7; }
	inline void set_activatedClientEntries_7(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___activatedClientEntries_7 = value;
		Il2CppCodeGenWriteBarrier((&___activatedClientEntries_7), value);
	}

	inline static int32_t get_offset_of_wellKnownServiceEntries_8() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___wellKnownServiceEntries_8)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_wellKnownServiceEntries_8() const { return ___wellKnownServiceEntries_8; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_wellKnownServiceEntries_8() { return &___wellKnownServiceEntries_8; }
	inline void set_wellKnownServiceEntries_8(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___wellKnownServiceEntries_8 = value;
		Il2CppCodeGenWriteBarrier((&___wellKnownServiceEntries_8), value);
	}

	inline static int32_t get_offset_of_activatedServiceEntries_9() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___activatedServiceEntries_9)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_activatedServiceEntries_9() const { return ___activatedServiceEntries_9; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_activatedServiceEntries_9() { return &___activatedServiceEntries_9; }
	inline void set_activatedServiceEntries_9(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___activatedServiceEntries_9 = value;
		Il2CppCodeGenWriteBarrier((&___activatedServiceEntries_9), value);
	}

	inline static int32_t get_offset_of_channelTemplates_10() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___channelTemplates_10)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_channelTemplates_10() const { return ___channelTemplates_10; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_channelTemplates_10() { return &___channelTemplates_10; }
	inline void set_channelTemplates_10(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___channelTemplates_10 = value;
		Il2CppCodeGenWriteBarrier((&___channelTemplates_10), value);
	}

	inline static int32_t get_offset_of_clientProviderTemplates_11() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___clientProviderTemplates_11)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_clientProviderTemplates_11() const { return ___clientProviderTemplates_11; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_clientProviderTemplates_11() { return &___clientProviderTemplates_11; }
	inline void set_clientProviderTemplates_11(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___clientProviderTemplates_11 = value;
		Il2CppCodeGenWriteBarrier((&___clientProviderTemplates_11), value);
	}

	inline static int32_t get_offset_of_serverProviderTemplates_12() { return static_cast<int32_t>(offsetof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields, ___serverProviderTemplates_12)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_serverProviderTemplates_12() const { return ___serverProviderTemplates_12; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_serverProviderTemplates_12() { return &___serverProviderTemplates_12; }
	inline void set_serverProviderTemplates_12(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___serverProviderTemplates_12 = value;
		Il2CppCodeGenWriteBarrier((&___serverProviderTemplates_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTINGCONFIGURATION_T8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_H
#ifndef TRACKINGSERVICES_T7A66467D14B401CDC816062629135DA735ACB540_H
#define TRACKINGSERVICES_T7A66467D14B401CDC816062629135DA735ACB540_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Services.TrackingServices
struct  TrackingServices_t7A66467D14B401CDC816062629135DA735ACB540  : public RuntimeObject
{
public:

public:
};

struct TrackingServices_t7A66467D14B401CDC816062629135DA735ACB540_StaticFields
{
public:
	// System.Collections.ArrayList System.Runtime.Remoting.Services.TrackingServices::_handlers
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ____handlers_0;

public:
	inline static int32_t get_offset_of__handlers_0() { return static_cast<int32_t>(offsetof(TrackingServices_t7A66467D14B401CDC816062629135DA735ACB540_StaticFields, ____handlers_0)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get__handlers_0() const { return ____handlers_0; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of__handlers_0() { return &____handlers_0; }
	inline void set__handlers_0(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		____handlers_0 = value;
		Il2CppCodeGenWriteBarrier((&____handlers_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKINGSERVICES_T7A66467D14B401CDC816062629135DA735ACB540_H
#ifndef TYPEENTRY_T21A4723C7E833CB4AC88028C4EC326F432B057B9_H
#define TYPEENTRY_T21A4723C7E833CB4AC88028C4EC326F432B057B9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.TypeEntry
struct  TypeEntry_t21A4723C7E833CB4AC88028C4EC326F432B057B9  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.TypeEntry::assembly_name
	String_t* ___assembly_name_0;
	// System.String System.Runtime.Remoting.TypeEntry::type_name
	String_t* ___type_name_1;

public:
	inline static int32_t get_offset_of_assembly_name_0() { return static_cast<int32_t>(offsetof(TypeEntry_t21A4723C7E833CB4AC88028C4EC326F432B057B9, ___assembly_name_0)); }
	inline String_t* get_assembly_name_0() const { return ___assembly_name_0; }
	inline String_t** get_address_of_assembly_name_0() { return &___assembly_name_0; }
	inline void set_assembly_name_0(String_t* value)
	{
		___assembly_name_0 = value;
		Il2CppCodeGenWriteBarrier((&___assembly_name_0), value);
	}

	inline static int32_t get_offset_of_type_name_1() { return static_cast<int32_t>(offsetof(TypeEntry_t21A4723C7E833CB4AC88028C4EC326F432B057B9, ___type_name_1)); }
	inline String_t* get_type_name_1() const { return ___type_name_1; }
	inline String_t** get_address_of_type_name_1() { return &___type_name_1; }
	inline void set_type_name_1(String_t* value)
	{
		___type_name_1 = value;
		Il2CppCodeGenWriteBarrier((&___type_name_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEENTRY_T21A4723C7E833CB4AC88028C4EC326F432B057B9_H
#ifndef VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#define VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_marshaled_com
{
};
#endif // VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#ifndef CONTEXTBOUNDOBJECT_T94A5F8CEB9A27868EB51B4E763AD5042C0FF09DF_H
#define CONTEXTBOUNDOBJECT_T94A5F8CEB9A27868EB51B4E763AD5042C0FF09DF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ContextBoundObject
struct  ContextBoundObject_t94A5F8CEB9A27868EB51B4E763AD5042C0FF09DF  : public MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTEXTBOUNDOBJECT_T94A5F8CEB9A27868EB51B4E763AD5042C0FF09DF_H
#ifndef ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#define ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF  : public ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C
{
public:

public:
};

struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_marshaled_com
{
};
#endif // ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef ACTIVATEDCLIENTTYPEENTRY_T51132D05D449780F0436A6E96BE6CBF20DE73A0E_H
#define ACTIVATEDCLIENTTYPEENTRY_T51132D05D449780F0436A6E96BE6CBF20DE73A0E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ActivatedClientTypeEntry
struct  ActivatedClientTypeEntry_t51132D05D449780F0436A6E96BE6CBF20DE73A0E  : public TypeEntry_t21A4723C7E833CB4AC88028C4EC326F432B057B9
{
public:
	// System.String System.Runtime.Remoting.ActivatedClientTypeEntry::applicationUrl
	String_t* ___applicationUrl_2;
	// System.Type System.Runtime.Remoting.ActivatedClientTypeEntry::obj_type
	Type_t * ___obj_type_3;

public:
	inline static int32_t get_offset_of_applicationUrl_2() { return static_cast<int32_t>(offsetof(ActivatedClientTypeEntry_t51132D05D449780F0436A6E96BE6CBF20DE73A0E, ___applicationUrl_2)); }
	inline String_t* get_applicationUrl_2() const { return ___applicationUrl_2; }
	inline String_t** get_address_of_applicationUrl_2() { return &___applicationUrl_2; }
	inline void set_applicationUrl_2(String_t* value)
	{
		___applicationUrl_2 = value;
		Il2CppCodeGenWriteBarrier((&___applicationUrl_2), value);
	}

	inline static int32_t get_offset_of_obj_type_3() { return static_cast<int32_t>(offsetof(ActivatedClientTypeEntry_t51132D05D449780F0436A6E96BE6CBF20DE73A0E, ___obj_type_3)); }
	inline Type_t * get_obj_type_3() const { return ___obj_type_3; }
	inline Type_t ** get_address_of_obj_type_3() { return &___obj_type_3; }
	inline void set_obj_type_3(Type_t * value)
	{
		___obj_type_3 = value;
		Il2CppCodeGenWriteBarrier((&___obj_type_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTIVATEDCLIENTTYPEENTRY_T51132D05D449780F0436A6E96BE6CBF20DE73A0E_H
#ifndef ACTIVATEDSERVICETYPEENTRY_TFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166_H
#define ACTIVATEDSERVICETYPEENTRY_TFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ActivatedServiceTypeEntry
struct  ActivatedServiceTypeEntry_tFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166  : public TypeEntry_t21A4723C7E833CB4AC88028C4EC326F432B057B9
{
public:
	// System.Type System.Runtime.Remoting.ActivatedServiceTypeEntry::obj_type
	Type_t * ___obj_type_2;

public:
	inline static int32_t get_offset_of_obj_type_2() { return static_cast<int32_t>(offsetof(ActivatedServiceTypeEntry_tFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166, ___obj_type_2)); }
	inline Type_t * get_obj_type_2() const { return ___obj_type_2; }
	inline Type_t ** get_address_of_obj_type_2() { return &___obj_type_2; }
	inline void set_obj_type_2(Type_t * value)
	{
		___obj_type_2 = value;
		Il2CppCodeGenWriteBarrier((&___obj_type_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTIVATEDSERVICETYPEENTRY_TFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166_H
#ifndef CLIENTIDENTITY_TE7070C34A48491598CA7EA0F84F62CD137DF0ABA_H
#define CLIENTIDENTITY_TE7070C34A48491598CA7EA0F84F62CD137DF0ABA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.ClientIdentity
struct  ClientIdentity_tE7070C34A48491598CA7EA0F84F62CD137DF0ABA  : public Identity_tF0CD49E50E212E64314E0241852939303E414F1C
{
public:
	// System.WeakReference System.Runtime.Remoting.ClientIdentity::_proxyReference
	WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C * ____proxyReference_7;

public:
	inline static int32_t get_offset_of__proxyReference_7() { return static_cast<int32_t>(offsetof(ClientIdentity_tE7070C34A48491598CA7EA0F84F62CD137DF0ABA, ____proxyReference_7)); }
	inline WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C * get__proxyReference_7() const { return ____proxyReference_7; }
	inline WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C ** get_address_of__proxyReference_7() { return &____proxyReference_7; }
	inline void set__proxyReference_7(WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C * value)
	{
		____proxyReference_7 = value;
		Il2CppCodeGenWriteBarrier((&____proxyReference_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLIENTIDENTITY_TE7070C34A48491598CA7EA0F84F62CD137DF0ABA_H
#ifndef CONTEXTATTRIBUTE_T1FF262D37B13FE267B0362600ACCFF5A8CD4603E_H
#define CONTEXTATTRIBUTE_T1FF262D37B13FE267B0362600ACCFF5A8CD4603E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.ContextAttribute
struct  ContextAttribute_t1FF262D37B13FE267B0362600ACCFF5A8CD4603E  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:
	// System.String System.Runtime.Remoting.Contexts.ContextAttribute::AttributeName
	String_t* ___AttributeName_0;

public:
	inline static int32_t get_offset_of_AttributeName_0() { return static_cast<int32_t>(offsetof(ContextAttribute_t1FF262D37B13FE267B0362600ACCFF5A8CD4603E, ___AttributeName_0)); }
	inline String_t* get_AttributeName_0() const { return ___AttributeName_0; }
	inline String_t** get_address_of_AttributeName_0() { return &___AttributeName_0; }
	inline void set_AttributeName_0(String_t* value)
	{
		___AttributeName_0 = value;
		Il2CppCodeGenWriteBarrier((&___AttributeName_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTEXTATTRIBUTE_T1FF262D37B13FE267B0362600ACCFF5A8CD4603E_H
#ifndef FORMATTERDATA_T0CA61A6A29D9A253AE45809E1A2F56FE9D323A9D_H
#define FORMATTERDATA_T0CA61A6A29D9A253AE45809E1A2F56FE9D323A9D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.FormatterData
struct  FormatterData_t0CA61A6A29D9A253AE45809E1A2F56FE9D323A9D  : public ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FORMATTERDATA_T0CA61A6A29D9A253AE45809E1A2F56FE9D323A9D_H
#ifndef CADMETHODRETURNMESSAGE_T37697335001303C9589BF01160C9EF847CCC25F4_H
#define CADMETHODRETURNMESSAGE_T37697335001303C9589BF01160C9EF847CCC25F4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CADMethodReturnMessage
struct  CADMethodReturnMessage_t37697335001303C9589BF01160C9EF847CCC25F4  : public CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3
{
public:
	// System.Object System.Runtime.Remoting.Messaging.CADMethodReturnMessage::_returnValue
	RuntimeObject * ____returnValue_4;
	// System.Runtime.Remoting.Messaging.CADArgHolder System.Runtime.Remoting.Messaging.CADMethodReturnMessage::_exception
	CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 * ____exception_5;

public:
	inline static int32_t get_offset_of__returnValue_4() { return static_cast<int32_t>(offsetof(CADMethodReturnMessage_t37697335001303C9589BF01160C9EF847CCC25F4, ____returnValue_4)); }
	inline RuntimeObject * get__returnValue_4() const { return ____returnValue_4; }
	inline RuntimeObject ** get_address_of__returnValue_4() { return &____returnValue_4; }
	inline void set__returnValue_4(RuntimeObject * value)
	{
		____returnValue_4 = value;
		Il2CppCodeGenWriteBarrier((&____returnValue_4), value);
	}

	inline static int32_t get_offset_of__exception_5() { return static_cast<int32_t>(offsetof(CADMethodReturnMessage_t37697335001303C9589BF01160C9EF847CCC25F4, ____exception_5)); }
	inline CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 * get__exception_5() const { return ____exception_5; }
	inline CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 ** get_address_of__exception_5() { return &____exception_5; }
	inline void set__exception_5(CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120 * value)
	{
		____exception_5 = value;
		Il2CppCodeGenWriteBarrier((&____exception_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CADMETHODRETURNMESSAGE_T37697335001303C9589BF01160C9EF847CCC25F4_H
#ifndef CONSTRUCTIONCALL_T48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_H
#define CONSTRUCTIONCALL_T48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ConstructionCall
struct  ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82  : public MethodCall_t85B750F7999345054735594566D42DDF9C378FD3
{
public:
	// System.Runtime.Remoting.Activation.IActivator System.Runtime.Remoting.Messaging.ConstructionCall::_activator
	RuntimeObject* ____activator_12;
	// System.Object[] System.Runtime.Remoting.Messaging.ConstructionCall::_activationAttributes
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ____activationAttributes_13;
	// System.Collections.IList System.Runtime.Remoting.Messaging.ConstructionCall::_contextProperties
	RuntimeObject* ____contextProperties_14;
	// System.Type System.Runtime.Remoting.Messaging.ConstructionCall::_activationType
	Type_t * ____activationType_15;
	// System.String System.Runtime.Remoting.Messaging.ConstructionCall::_activationTypeName
	String_t* ____activationTypeName_16;
	// System.Boolean System.Runtime.Remoting.Messaging.ConstructionCall::_isContextOk
	bool ____isContextOk_17;
	// System.Runtime.Remoting.Proxies.RemotingProxy System.Runtime.Remoting.Messaging.ConstructionCall::_sourceProxy
	RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC * ____sourceProxy_18;

public:
	inline static int32_t get_offset_of__activator_12() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____activator_12)); }
	inline RuntimeObject* get__activator_12() const { return ____activator_12; }
	inline RuntimeObject** get_address_of__activator_12() { return &____activator_12; }
	inline void set__activator_12(RuntimeObject* value)
	{
		____activator_12 = value;
		Il2CppCodeGenWriteBarrier((&____activator_12), value);
	}

	inline static int32_t get_offset_of__activationAttributes_13() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____activationAttributes_13)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get__activationAttributes_13() const { return ____activationAttributes_13; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of__activationAttributes_13() { return &____activationAttributes_13; }
	inline void set__activationAttributes_13(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		____activationAttributes_13 = value;
		Il2CppCodeGenWriteBarrier((&____activationAttributes_13), value);
	}

	inline static int32_t get_offset_of__contextProperties_14() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____contextProperties_14)); }
	inline RuntimeObject* get__contextProperties_14() const { return ____contextProperties_14; }
	inline RuntimeObject** get_address_of__contextProperties_14() { return &____contextProperties_14; }
	inline void set__contextProperties_14(RuntimeObject* value)
	{
		____contextProperties_14 = value;
		Il2CppCodeGenWriteBarrier((&____contextProperties_14), value);
	}

	inline static int32_t get_offset_of__activationType_15() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____activationType_15)); }
	inline Type_t * get__activationType_15() const { return ____activationType_15; }
	inline Type_t ** get_address_of__activationType_15() { return &____activationType_15; }
	inline void set__activationType_15(Type_t * value)
	{
		____activationType_15 = value;
		Il2CppCodeGenWriteBarrier((&____activationType_15), value);
	}

	inline static int32_t get_offset_of__activationTypeName_16() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____activationTypeName_16)); }
	inline String_t* get__activationTypeName_16() const { return ____activationTypeName_16; }
	inline String_t** get_address_of__activationTypeName_16() { return &____activationTypeName_16; }
	inline void set__activationTypeName_16(String_t* value)
	{
		____activationTypeName_16 = value;
		Il2CppCodeGenWriteBarrier((&____activationTypeName_16), value);
	}

	inline static int32_t get_offset_of__isContextOk_17() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____isContextOk_17)); }
	inline bool get__isContextOk_17() const { return ____isContextOk_17; }
	inline bool* get_address_of__isContextOk_17() { return &____isContextOk_17; }
	inline void set__isContextOk_17(bool value)
	{
		____isContextOk_17 = value;
	}

	inline static int32_t get_offset_of__sourceProxy_18() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82, ____sourceProxy_18)); }
	inline RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC * get__sourceProxy_18() const { return ____sourceProxy_18; }
	inline RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC ** get_address_of__sourceProxy_18() { return &____sourceProxy_18; }
	inline void set__sourceProxy_18(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC * value)
	{
		____sourceProxy_18 = value;
		Il2CppCodeGenWriteBarrier((&____sourceProxy_18), value);
	}
};

struct ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.ConstructionCall::<>f__switchU24map20
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map20_19;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map20_19() { return static_cast<int32_t>(offsetof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_StaticFields, ___U3CU3Ef__switchU24map20_19)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map20_19() const { return ___U3CU3Ef__switchU24map20_19; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map20_19() { return &___U3CU3Ef__switchU24map20_19; }
	inline void set_U3CU3Ef__switchU24map20_19(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map20_19 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map20_19), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONSTRUCTIONCALL_T48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_H
#ifndef CONSTRUCTIONCALLDICTIONARY_TD8AE20934AD23930822FC405FBB8606AAC2F11BB_H
#define CONSTRUCTIONCALLDICTIONARY_TD8AE20934AD23930822FC405FBB8606AAC2F11BB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ConstructionCallDictionary
struct  ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB  : public MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D
{
public:

public:
};

struct ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields
{
public:
	// System.String[] System.Runtime.Remoting.Messaging.ConstructionCallDictionary::InternalKeys
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___InternalKeys_6;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.ConstructionCallDictionary::<>f__switchU24map23
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map23_7;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Runtime.Remoting.Messaging.ConstructionCallDictionary::<>f__switchU24map24
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map24_8;

public:
	inline static int32_t get_offset_of_InternalKeys_6() { return static_cast<int32_t>(offsetof(ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields, ___InternalKeys_6)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_InternalKeys_6() const { return ___InternalKeys_6; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_InternalKeys_6() { return &___InternalKeys_6; }
	inline void set_InternalKeys_6(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___InternalKeys_6 = value;
		Il2CppCodeGenWriteBarrier((&___InternalKeys_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map23_7() { return static_cast<int32_t>(offsetof(ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields, ___U3CU3Ef__switchU24map23_7)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map23_7() const { return ___U3CU3Ef__switchU24map23_7; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map23_7() { return &___U3CU3Ef__switchU24map23_7; }
	inline void set_U3CU3Ef__switchU24map23_7(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map23_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map23_7), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map24_8() { return static_cast<int32_t>(offsetof(ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields, ___U3CU3Ef__switchU24map24_8)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map24_8() const { return ___U3CU3Ef__switchU24map24_8; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map24_8() { return &___U3CU3Ef__switchU24map24_8; }
	inline void set_U3CU3Ef__switchU24map24_8(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map24_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map24_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONSTRUCTIONCALLDICTIONARY_TD8AE20934AD23930822FC405FBB8606AAC2F11BB_H
#ifndef CONSTRUCTIONRESPONSE_TC25C1658A8BC826BA04B8BD2C2FB8F2CB3A08178_H
#define CONSTRUCTIONRESPONSE_TC25C1658A8BC826BA04B8BD2C2FB8F2CB3A08178_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ConstructionResponse
struct  ConstructionResponse_tC25C1658A8BC826BA04B8BD2C2FB8F2CB3A08178  : public MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONSTRUCTIONRESPONSE_TC25C1658A8BC826BA04B8BD2C2FB8F2CB3A08178_H
#ifndef METHODCALLDICTIONARY_T81152FFCAEB2709A693B1BF9900E3B71BFC83955_H
#define METHODCALLDICTIONARY_T81152FFCAEB2709A693B1BF9900E3B71BFC83955_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MethodCallDictionary
struct  MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955  : public MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D
{
public:

public:
};

struct MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955_StaticFields
{
public:
	// System.String[] System.Runtime.Remoting.Messaging.MethodCallDictionary::InternalKeys
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___InternalKeys_6;

public:
	inline static int32_t get_offset_of_InternalKeys_6() { return static_cast<int32_t>(offsetof(MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955_StaticFields, ___InternalKeys_6)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_InternalKeys_6() const { return ___InternalKeys_6; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_InternalKeys_6() { return &___InternalKeys_6; }
	inline void set_InternalKeys_6(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___InternalKeys_6 = value;
		Il2CppCodeGenWriteBarrier((&___InternalKeys_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODCALLDICTIONARY_T81152FFCAEB2709A693B1BF9900E3B71BFC83955_H
#ifndef METHODRETURNDICTIONARY_TF861BE703565E068497C6AEDEC97A98A24C97B66_H
#define METHODRETURNDICTIONARY_TF861BE703565E068497C6AEDEC97A98A24C97B66_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MethodReturnDictionary
struct  MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66  : public MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D
{
public:

public:
};

struct MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66_StaticFields
{
public:
	// System.String[] System.Runtime.Remoting.Messaging.MethodReturnDictionary::InternalReturnKeys
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___InternalReturnKeys_6;
	// System.String[] System.Runtime.Remoting.Messaging.MethodReturnDictionary::InternalExceptionKeys
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___InternalExceptionKeys_7;

public:
	inline static int32_t get_offset_of_InternalReturnKeys_6() { return static_cast<int32_t>(offsetof(MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66_StaticFields, ___InternalReturnKeys_6)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_InternalReturnKeys_6() const { return ___InternalReturnKeys_6; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_InternalReturnKeys_6() { return &___InternalReturnKeys_6; }
	inline void set_InternalReturnKeys_6(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___InternalReturnKeys_6 = value;
		Il2CppCodeGenWriteBarrier((&___InternalReturnKeys_6), value);
	}

	inline static int32_t get_offset_of_InternalExceptionKeys_7() { return static_cast<int32_t>(offsetof(MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66_StaticFields, ___InternalExceptionKeys_7)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_InternalExceptionKeys_7() const { return ___InternalExceptionKeys_7; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_InternalExceptionKeys_7() { return &___InternalExceptionKeys_7; }
	inline void set_InternalExceptionKeys_7(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___InternalExceptionKeys_7 = value;
		Il2CppCodeGenWriteBarrier((&___InternalExceptionKeys_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODRETURNDICTIONARY_TF861BE703565E068497C6AEDEC97A98A24C97B66_H
#ifndef ONEWAYATTRIBUTE_T6F328E7A9D112A58CAACA1DE7899FAD3A7B12C5A_H
#define ONEWAYATTRIBUTE_T6F328E7A9D112A58CAACA1DE7899FAD3A7B12C5A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.OneWayAttribute
struct  OneWayAttribute_t6F328E7A9D112A58CAACA1DE7899FAD3A7B12C5A  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONEWAYATTRIBUTE_T6F328E7A9D112A58CAACA1DE7899FAD3A7B12C5A_H
#ifndef SOAPATTRIBUTE_T34BB5310349A1A042D17B95AAF6E3FE21113213C_H
#define SOAPATTRIBUTE_T34BB5310349A1A042D17B95AAF6E3FE21113213C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Metadata.SoapAttribute
struct  SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:
	// System.Boolean System.Runtime.Remoting.Metadata.SoapAttribute::_useAttribute
	bool ____useAttribute_0;
	// System.String System.Runtime.Remoting.Metadata.SoapAttribute::ProtXmlNamespace
	String_t* ___ProtXmlNamespace_1;
	// System.Object System.Runtime.Remoting.Metadata.SoapAttribute::ReflectInfo
	RuntimeObject * ___ReflectInfo_2;

public:
	inline static int32_t get_offset_of__useAttribute_0() { return static_cast<int32_t>(offsetof(SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C, ____useAttribute_0)); }
	inline bool get__useAttribute_0() const { return ____useAttribute_0; }
	inline bool* get_address_of__useAttribute_0() { return &____useAttribute_0; }
	inline void set__useAttribute_0(bool value)
	{
		____useAttribute_0 = value;
	}

	inline static int32_t get_offset_of_ProtXmlNamespace_1() { return static_cast<int32_t>(offsetof(SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C, ___ProtXmlNamespace_1)); }
	inline String_t* get_ProtXmlNamespace_1() const { return ___ProtXmlNamespace_1; }
	inline String_t** get_address_of_ProtXmlNamespace_1() { return &___ProtXmlNamespace_1; }
	inline void set_ProtXmlNamespace_1(String_t* value)
	{
		___ProtXmlNamespace_1 = value;
		Il2CppCodeGenWriteBarrier((&___ProtXmlNamespace_1), value);
	}

	inline static int32_t get_offset_of_ReflectInfo_2() { return static_cast<int32_t>(offsetof(SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C, ___ReflectInfo_2)); }
	inline RuntimeObject * get_ReflectInfo_2() const { return ___ReflectInfo_2; }
	inline RuntimeObject ** get_address_of_ReflectInfo_2() { return &___ReflectInfo_2; }
	inline void set_ReflectInfo_2(RuntimeObject * value)
	{
		___ReflectInfo_2 = value;
		Il2CppCodeGenWriteBarrier((&___ReflectInfo_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOAPATTRIBUTE_T34BB5310349A1A042D17B95AAF6E3FE21113213C_H
#ifndef PROXYATTRIBUTE_TB6D3B943A5E0554E3864C06D36FB99E16D8B92D3_H
#define PROXYATTRIBUTE_TB6D3B943A5E0554E3864C06D36FB99E16D8B92D3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Proxies.ProxyAttribute
struct  ProxyAttribute_tB6D3B943A5E0554E3864C06D36FB99E16D8B92D3  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROXYATTRIBUTE_TB6D3B943A5E0554E3864C06D36FB99E16D8B92D3_H
#ifndef REMOTINGPROXY_TAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_H
#define REMOTINGPROXY_TAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Proxies.RemotingProxy
struct  RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC  : public RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC
{
public:
	// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Proxies.RemotingProxy::_sink
	RuntimeObject* ____sink_10;
	// System.Boolean System.Runtime.Remoting.Proxies.RemotingProxy::_hasEnvoySink
	bool ____hasEnvoySink_11;
	// System.Runtime.Remoting.Messaging.ConstructionCall System.Runtime.Remoting.Proxies.RemotingProxy::_ctorCall
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82 * ____ctorCall_12;

public:
	inline static int32_t get_offset_of__sink_10() { return static_cast<int32_t>(offsetof(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC, ____sink_10)); }
	inline RuntimeObject* get__sink_10() const { return ____sink_10; }
	inline RuntimeObject** get_address_of__sink_10() { return &____sink_10; }
	inline void set__sink_10(RuntimeObject* value)
	{
		____sink_10 = value;
		Il2CppCodeGenWriteBarrier((&____sink_10), value);
	}

	inline static int32_t get_offset_of__hasEnvoySink_11() { return static_cast<int32_t>(offsetof(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC, ____hasEnvoySink_11)); }
	inline bool get__hasEnvoySink_11() const { return ____hasEnvoySink_11; }
	inline bool* get_address_of__hasEnvoySink_11() { return &____hasEnvoySink_11; }
	inline void set__hasEnvoySink_11(bool value)
	{
		____hasEnvoySink_11 = value;
	}

	inline static int32_t get_offset_of__ctorCall_12() { return static_cast<int32_t>(offsetof(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC, ____ctorCall_12)); }
	inline ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82 * get__ctorCall_12() const { return ____ctorCall_12; }
	inline ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82 ** get_address_of__ctorCall_12() { return &____ctorCall_12; }
	inline void set__ctorCall_12(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82 * value)
	{
		____ctorCall_12 = value;
		Il2CppCodeGenWriteBarrier((&____ctorCall_12), value);
	}
};

struct RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_StaticFields
{
public:
	// System.Reflection.MethodInfo System.Runtime.Remoting.Proxies.RemotingProxy::_cache_GetTypeMethod
	MethodInfo_t * ____cache_GetTypeMethod_8;
	// System.Reflection.MethodInfo System.Runtime.Remoting.Proxies.RemotingProxy::_cache_GetHashCodeMethod
	MethodInfo_t * ____cache_GetHashCodeMethod_9;

public:
	inline static int32_t get_offset_of__cache_GetTypeMethod_8() { return static_cast<int32_t>(offsetof(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_StaticFields, ____cache_GetTypeMethod_8)); }
	inline MethodInfo_t * get__cache_GetTypeMethod_8() const { return ____cache_GetTypeMethod_8; }
	inline MethodInfo_t ** get_address_of__cache_GetTypeMethod_8() { return &____cache_GetTypeMethod_8; }
	inline void set__cache_GetTypeMethod_8(MethodInfo_t * value)
	{
		____cache_GetTypeMethod_8 = value;
		Il2CppCodeGenWriteBarrier((&____cache_GetTypeMethod_8), value);
	}

	inline static int32_t get_offset_of__cache_GetHashCodeMethod_9() { return static_cast<int32_t>(offsetof(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_StaticFields, ____cache_GetHashCodeMethod_9)); }
	inline MethodInfo_t * get__cache_GetHashCodeMethod_9() const { return ____cache_GetHashCodeMethod_9; }
	inline MethodInfo_t ** get_address_of__cache_GetHashCodeMethod_9() { return &____cache_GetHashCodeMethod_9; }
	inline void set__cache_GetHashCodeMethod_9(MethodInfo_t * value)
	{
		____cache_GetHashCodeMethod_9 = value;
		Il2CppCodeGenWriteBarrier((&____cache_GetHashCodeMethod_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTINGPROXY_TAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_H
#ifndef SYSTEMEXCEPTION_T81A06ADD519539D252788D75E44AFFBE6580E301_H
#define SYSTEMEXCEPTION_T81A06ADD519539D252788D75E44AFFBE6580E301_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301  : public Exception_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T81A06ADD519539D252788D75E44AFFBE6580E301_H
#ifndef TIMESPAN_T26DE4373EA745C072A5FBDEAD8373348955FC374_H
#define TIMESPAN_T26DE4373EA745C072A5FBDEAD8373348955FC374_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TimeSpan
struct  TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 
{
public:
	// System.Int64 System.TimeSpan::_ticks
	int64_t ____ticks_3;

public:
	inline static int32_t get_offset_of__ticks_3() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374, ____ticks_3)); }
	inline int64_t get__ticks_3() const { return ____ticks_3; }
	inline int64_t* get_address_of__ticks_3() { return &____ticks_3; }
	inline void set__ticks_3(int64_t value)
	{
		____ticks_3 = value;
	}
};

struct TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields
{
public:
	// System.TimeSpan System.TimeSpan::MaxValue
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___MaxValue_0;
	// System.TimeSpan System.TimeSpan::MinValue
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___MinValue_1;
	// System.TimeSpan System.TimeSpan::Zero
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___Zero_2;

public:
	inline static int32_t get_offset_of_MaxValue_0() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields, ___MaxValue_0)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_MaxValue_0() const { return ___MaxValue_0; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_MaxValue_0() { return &___MaxValue_0; }
	inline void set_MaxValue_0(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___MaxValue_0 = value;
	}

	inline static int32_t get_offset_of_MinValue_1() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields, ___MinValue_1)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_MinValue_1() const { return ___MinValue_1; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_MinValue_1() { return &___MinValue_1; }
	inline void set_MinValue_1(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___MinValue_1 = value;
	}

	inline static int32_t get_offset_of_Zero_2() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields, ___Zero_2)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_Zero_2() const { return ___Zero_2; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_Zero_2() { return &___Zero_2; }
	inline void set_Zero_2(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___Zero_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TIMESPAN_T26DE4373EA745C072A5FBDEAD8373348955FC374_H
#ifndef DATETIMEKIND_T922DC40070B8AD59CB650E3FE023C4A58ED4568A_H
#define DATETIMEKIND_T922DC40070B8AD59CB650E3FE023C4A58ED4568A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DateTimeKind
struct  DateTimeKind_t922DC40070B8AD59CB650E3FE023C4A58ED4568A 
{
public:
	// System.Int32 System.DateTimeKind::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DateTimeKind_t922DC40070B8AD59CB650E3FE023C4A58ED4568A, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIMEKIND_T922DC40070B8AD59CB650E3FE023C4A58ED4568A_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_5;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_6;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_7;
	// System.DelegateData System.Delegate::data
	DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 * ___data_8;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_method_code_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_5)); }
	inline intptr_t get_method_code_5() const { return ___method_code_5; }
	inline intptr_t* get_address_of_method_code_5() { return &___method_code_5; }
	inline void set_method_code_5(intptr_t value)
	{
		___method_code_5 = value;
	}

	inline static int32_t get_offset_of_method_info_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_6)); }
	inline MethodInfo_t * get_method_info_6() const { return ___method_info_6; }
	inline MethodInfo_t ** get_address_of_method_info_6() { return &___method_info_6; }
	inline void set_method_info_6(MethodInfo_t * value)
	{
		___method_info_6 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_6), value);
	}

	inline static int32_t get_offset_of_original_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_7)); }
	inline MethodInfo_t * get_original_method_info_7() const { return ___original_method_info_7; }
	inline MethodInfo_t ** get_address_of_original_method_info_7() { return &___original_method_info_7; }
	inline void set_original_method_info_7(MethodInfo_t * value)
	{
		___original_method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_7), value);
	}

	inline static int32_t get_offset_of_data_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_8)); }
	inline DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 * get_data_8() const { return ___data_8; }
	inline DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 ** get_address_of_data_8() { return &___data_8; }
	inline void set_data_8(DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 * value)
	{
		___data_8 = value;
		Il2CppCodeGenWriteBarrier((&___data_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DELEGATE_T_H
#ifndef BINDINGFLAGS_T7FD4941D9115FF77D5F573F63A93BFBC5D1F63B2_H
#define BINDINGFLAGS_T7FD4941D9115FF77D5F573F63A93BFBC5D1F63B2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.BindingFlags
struct  BindingFlags_t7FD4941D9115FF77D5F573F63A93BFBC5D1F63B2 
{
public:
	// System.Int32 System.Reflection.BindingFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(BindingFlags_t7FD4941D9115FF77D5F573F63A93BFBC5D1F63B2, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BINDINGFLAGS_T7FD4941D9115FF77D5F573F63A93BFBC5D1F63B2_H
#ifndef CONTEXTCALLBACKOBJECT_T5FEDC6283CDC9DF160A27AF9728358C628299D0B_H
#define CONTEXTCALLBACKOBJECT_T5FEDC6283CDC9DF160A27AF9728358C628299D0B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.ContextCallbackObject
struct  ContextCallbackObject_t5FEDC6283CDC9DF160A27AF9728358C628299D0B  : public ContextBoundObject_t94A5F8CEB9A27868EB51B4E763AD5042C0FF09DF
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTEXTCALLBACKOBJECT_T5FEDC6283CDC9DF160A27AF9728358C628299D0B_H
#ifndef SYNCHRONIZATIONATTRIBUTE_T3A33565C21222F3107329890095AA5B7B484BC2F_H
#define SYNCHRONIZATIONATTRIBUTE_T3A33565C21222F3107329890095AA5B7B484BC2F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.SynchronizationAttribute
struct  SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F  : public ContextAttribute_t1FF262D37B13FE267B0362600ACCFF5A8CD4603E
{
public:
	// System.Boolean System.Runtime.Remoting.Contexts.SynchronizationAttribute::_bReEntrant
	bool ____bReEntrant_1;
	// System.Int32 System.Runtime.Remoting.Contexts.SynchronizationAttribute::_flavor
	int32_t ____flavor_2;
	// System.Int32 System.Runtime.Remoting.Contexts.SynchronizationAttribute::_lockCount
	int32_t ____lockCount_3;
	// System.Threading.Mutex System.Runtime.Remoting.Contexts.SynchronizationAttribute::_mutex
	Mutex_t439997CEED438973F1CFE782AFD9DDECBB2E1838 * ____mutex_4;
	// System.Threading.Thread System.Runtime.Remoting.Contexts.SynchronizationAttribute::_ownerThread
	Thread_t83C301EC970792455F76D89E58140949B003EA50 * ____ownerThread_5;

public:
	inline static int32_t get_offset_of__bReEntrant_1() { return static_cast<int32_t>(offsetof(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F, ____bReEntrant_1)); }
	inline bool get__bReEntrant_1() const { return ____bReEntrant_1; }
	inline bool* get_address_of__bReEntrant_1() { return &____bReEntrant_1; }
	inline void set__bReEntrant_1(bool value)
	{
		____bReEntrant_1 = value;
	}

	inline static int32_t get_offset_of__flavor_2() { return static_cast<int32_t>(offsetof(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F, ____flavor_2)); }
	inline int32_t get__flavor_2() const { return ____flavor_2; }
	inline int32_t* get_address_of__flavor_2() { return &____flavor_2; }
	inline void set__flavor_2(int32_t value)
	{
		____flavor_2 = value;
	}

	inline static int32_t get_offset_of__lockCount_3() { return static_cast<int32_t>(offsetof(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F, ____lockCount_3)); }
	inline int32_t get__lockCount_3() const { return ____lockCount_3; }
	inline int32_t* get_address_of__lockCount_3() { return &____lockCount_3; }
	inline void set__lockCount_3(int32_t value)
	{
		____lockCount_3 = value;
	}

	inline static int32_t get_offset_of__mutex_4() { return static_cast<int32_t>(offsetof(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F, ____mutex_4)); }
	inline Mutex_t439997CEED438973F1CFE782AFD9DDECBB2E1838 * get__mutex_4() const { return ____mutex_4; }
	inline Mutex_t439997CEED438973F1CFE782AFD9DDECBB2E1838 ** get_address_of__mutex_4() { return &____mutex_4; }
	inline void set__mutex_4(Mutex_t439997CEED438973F1CFE782AFD9DDECBB2E1838 * value)
	{
		____mutex_4 = value;
		Il2CppCodeGenWriteBarrier((&____mutex_4), value);
	}

	inline static int32_t get_offset_of__ownerThread_5() { return static_cast<int32_t>(offsetof(SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F, ____ownerThread_5)); }
	inline Thread_t83C301EC970792455F76D89E58140949B003EA50 * get__ownerThread_5() const { return ____ownerThread_5; }
	inline Thread_t83C301EC970792455F76D89E58140949B003EA50 ** get_address_of__ownerThread_5() { return &____ownerThread_5; }
	inline void set__ownerThread_5(Thread_t83C301EC970792455F76D89E58140949B003EA50 * value)
	{
		____ownerThread_5 = value;
		Il2CppCodeGenWriteBarrier((&____ownerThread_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYNCHRONIZATIONATTRIBUTE_T3A33565C21222F3107329890095AA5B7B484BC2F_H
#ifndef LEASESTATE_T27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD_H
#define LEASESTATE_T27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Lifetime.LeaseState
struct  LeaseState_t27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD 
{
public:
	// System.Int32 System.Runtime.Remoting.Lifetime.LeaseState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(LeaseState_t27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEASESTATE_T27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD_H
#ifndef LIFETIMESERVICES_T5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_H
#define LIFETIMESERVICES_T5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Lifetime.LifetimeServices
struct  LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97  : public RuntimeObject
{
public:

public:
};

struct LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields
{
public:
	// System.TimeSpan System.Runtime.Remoting.Lifetime.LifetimeServices::_leaseManagerPollTime
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____leaseManagerPollTime_0;
	// System.TimeSpan System.Runtime.Remoting.Lifetime.LifetimeServices::_leaseTime
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____leaseTime_1;
	// System.TimeSpan System.Runtime.Remoting.Lifetime.LifetimeServices::_renewOnCallTime
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____renewOnCallTime_2;
	// System.TimeSpan System.Runtime.Remoting.Lifetime.LifetimeServices::_sponsorshipTimeout
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____sponsorshipTimeout_3;
	// System.Runtime.Remoting.Lifetime.LeaseManager System.Runtime.Remoting.Lifetime.LifetimeServices::_leaseManager
	LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D * ____leaseManager_4;

public:
	inline static int32_t get_offset_of__leaseManagerPollTime_0() { return static_cast<int32_t>(offsetof(LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields, ____leaseManagerPollTime_0)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__leaseManagerPollTime_0() const { return ____leaseManagerPollTime_0; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__leaseManagerPollTime_0() { return &____leaseManagerPollTime_0; }
	inline void set__leaseManagerPollTime_0(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____leaseManagerPollTime_0 = value;
	}

	inline static int32_t get_offset_of__leaseTime_1() { return static_cast<int32_t>(offsetof(LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields, ____leaseTime_1)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__leaseTime_1() const { return ____leaseTime_1; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__leaseTime_1() { return &____leaseTime_1; }
	inline void set__leaseTime_1(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____leaseTime_1 = value;
	}

	inline static int32_t get_offset_of__renewOnCallTime_2() { return static_cast<int32_t>(offsetof(LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields, ____renewOnCallTime_2)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__renewOnCallTime_2() const { return ____renewOnCallTime_2; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__renewOnCallTime_2() { return &____renewOnCallTime_2; }
	inline void set__renewOnCallTime_2(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____renewOnCallTime_2 = value;
	}

	inline static int32_t get_offset_of__sponsorshipTimeout_3() { return static_cast<int32_t>(offsetof(LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields, ____sponsorshipTimeout_3)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__sponsorshipTimeout_3() const { return ____sponsorshipTimeout_3; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__sponsorshipTimeout_3() { return &____sponsorshipTimeout_3; }
	inline void set__sponsorshipTimeout_3(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____sponsorshipTimeout_3 = value;
	}

	inline static int32_t get_offset_of__leaseManager_4() { return static_cast<int32_t>(offsetof(LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields, ____leaseManager_4)); }
	inline LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D * get__leaseManager_4() const { return ____leaseManager_4; }
	inline LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D ** get_address_of__leaseManager_4() { return &____leaseManager_4; }
	inline void set__leaseManager_4(LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D * value)
	{
		____leaseManager_4 = value;
		Il2CppCodeGenWriteBarrier((&____leaseManager_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIFETIMESERVICES_T5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_H
#ifndef ARGINFOTYPE_T01886B60C76F16FB3370C25BBF27CD055B3D1F61_H
#define ARGINFOTYPE_T01886B60C76F16FB3370C25BBF27CD055B3D1F61_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.ArgInfoType
struct  ArgInfoType_t01886B60C76F16FB3370C25BBF27CD055B3D1F61 
{
public:
	// System.Byte System.Runtime.Remoting.Messaging.ArgInfoType::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ArgInfoType_t01886B60C76F16FB3370C25BBF27CD055B3D1F61, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGINFOTYPE_T01886B60C76F16FB3370C25BBF27CD055B3D1F61_H
#ifndef ASYNCRESULT_TAB8D16F4115F1F6CA976733C37369200FBE06F6F_H
#define ASYNCRESULT_TAB8D16F4115F1F6CA976733C37369200FBE06F6F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.AsyncResult
struct  AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F  : public RuntimeObject
{
public:
	// System.Object System.Runtime.Remoting.Messaging.AsyncResult::async_state
	RuntimeObject * ___async_state_0;
	// System.Threading.WaitHandle System.Runtime.Remoting.Messaging.AsyncResult::handle
	WaitHandle_t4E21379F87C00DE80B2973DCAA928C4A19D1A89E * ___handle_1;
	// System.Object System.Runtime.Remoting.Messaging.AsyncResult::async_delegate
	RuntimeObject * ___async_delegate_2;
	// System.IntPtr System.Runtime.Remoting.Messaging.AsyncResult::data
	intptr_t ___data_3;
	// System.Object System.Runtime.Remoting.Messaging.AsyncResult::object_data
	RuntimeObject * ___object_data_4;
	// System.Boolean System.Runtime.Remoting.Messaging.AsyncResult::sync_completed
	bool ___sync_completed_5;
	// System.Boolean System.Runtime.Remoting.Messaging.AsyncResult::completed
	bool ___completed_6;
	// System.Boolean System.Runtime.Remoting.Messaging.AsyncResult::endinvoke_called
	bool ___endinvoke_called_7;
	// System.Object System.Runtime.Remoting.Messaging.AsyncResult::async_callback
	RuntimeObject * ___async_callback_8;
	// System.Threading.ExecutionContext System.Runtime.Remoting.Messaging.AsyncResult::current
	ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 * ___current_9;
	// System.Threading.ExecutionContext System.Runtime.Remoting.Messaging.AsyncResult::original
	ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 * ___original_10;
	// System.Int32 System.Runtime.Remoting.Messaging.AsyncResult::gchandle
	int32_t ___gchandle_11;
	// System.Runtime.Remoting.Messaging.MonoMethodMessage System.Runtime.Remoting.Messaging.AsyncResult::call_message
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB * ___call_message_12;
	// System.Runtime.Remoting.Messaging.IMessageCtrl System.Runtime.Remoting.Messaging.AsyncResult::message_ctrl
	RuntimeObject* ___message_ctrl_13;
	// System.Runtime.Remoting.Messaging.IMessage System.Runtime.Remoting.Messaging.AsyncResult::reply_message
	RuntimeObject* ___reply_message_14;

public:
	inline static int32_t get_offset_of_async_state_0() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___async_state_0)); }
	inline RuntimeObject * get_async_state_0() const { return ___async_state_0; }
	inline RuntimeObject ** get_address_of_async_state_0() { return &___async_state_0; }
	inline void set_async_state_0(RuntimeObject * value)
	{
		___async_state_0 = value;
		Il2CppCodeGenWriteBarrier((&___async_state_0), value);
	}

	inline static int32_t get_offset_of_handle_1() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___handle_1)); }
	inline WaitHandle_t4E21379F87C00DE80B2973DCAA928C4A19D1A89E * get_handle_1() const { return ___handle_1; }
	inline WaitHandle_t4E21379F87C00DE80B2973DCAA928C4A19D1A89E ** get_address_of_handle_1() { return &___handle_1; }
	inline void set_handle_1(WaitHandle_t4E21379F87C00DE80B2973DCAA928C4A19D1A89E * value)
	{
		___handle_1 = value;
		Il2CppCodeGenWriteBarrier((&___handle_1), value);
	}

	inline static int32_t get_offset_of_async_delegate_2() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___async_delegate_2)); }
	inline RuntimeObject * get_async_delegate_2() const { return ___async_delegate_2; }
	inline RuntimeObject ** get_address_of_async_delegate_2() { return &___async_delegate_2; }
	inline void set_async_delegate_2(RuntimeObject * value)
	{
		___async_delegate_2 = value;
		Il2CppCodeGenWriteBarrier((&___async_delegate_2), value);
	}

	inline static int32_t get_offset_of_data_3() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___data_3)); }
	inline intptr_t get_data_3() const { return ___data_3; }
	inline intptr_t* get_address_of_data_3() { return &___data_3; }
	inline void set_data_3(intptr_t value)
	{
		___data_3 = value;
	}

	inline static int32_t get_offset_of_object_data_4() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___object_data_4)); }
	inline RuntimeObject * get_object_data_4() const { return ___object_data_4; }
	inline RuntimeObject ** get_address_of_object_data_4() { return &___object_data_4; }
	inline void set_object_data_4(RuntimeObject * value)
	{
		___object_data_4 = value;
		Il2CppCodeGenWriteBarrier((&___object_data_4), value);
	}

	inline static int32_t get_offset_of_sync_completed_5() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___sync_completed_5)); }
	inline bool get_sync_completed_5() const { return ___sync_completed_5; }
	inline bool* get_address_of_sync_completed_5() { return &___sync_completed_5; }
	inline void set_sync_completed_5(bool value)
	{
		___sync_completed_5 = value;
	}

	inline static int32_t get_offset_of_completed_6() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___completed_6)); }
	inline bool get_completed_6() const { return ___completed_6; }
	inline bool* get_address_of_completed_6() { return &___completed_6; }
	inline void set_completed_6(bool value)
	{
		___completed_6 = value;
	}

	inline static int32_t get_offset_of_endinvoke_called_7() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___endinvoke_called_7)); }
	inline bool get_endinvoke_called_7() const { return ___endinvoke_called_7; }
	inline bool* get_address_of_endinvoke_called_7() { return &___endinvoke_called_7; }
	inline void set_endinvoke_called_7(bool value)
	{
		___endinvoke_called_7 = value;
	}

	inline static int32_t get_offset_of_async_callback_8() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___async_callback_8)); }
	inline RuntimeObject * get_async_callback_8() const { return ___async_callback_8; }
	inline RuntimeObject ** get_address_of_async_callback_8() { return &___async_callback_8; }
	inline void set_async_callback_8(RuntimeObject * value)
	{
		___async_callback_8 = value;
		Il2CppCodeGenWriteBarrier((&___async_callback_8), value);
	}

	inline static int32_t get_offset_of_current_9() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___current_9)); }
	inline ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 * get_current_9() const { return ___current_9; }
	inline ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 ** get_address_of_current_9() { return &___current_9; }
	inline void set_current_9(ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 * value)
	{
		___current_9 = value;
		Il2CppCodeGenWriteBarrier((&___current_9), value);
	}

	inline static int32_t get_offset_of_original_10() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___original_10)); }
	inline ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 * get_original_10() const { return ___original_10; }
	inline ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 ** get_address_of_original_10() { return &___original_10; }
	inline void set_original_10(ExecutionContext_t2EC6945F5A7E9A0326AF5885457F49F4EEC26CF3 * value)
	{
		___original_10 = value;
		Il2CppCodeGenWriteBarrier((&___original_10), value);
	}

	inline static int32_t get_offset_of_gchandle_11() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___gchandle_11)); }
	inline int32_t get_gchandle_11() const { return ___gchandle_11; }
	inline int32_t* get_address_of_gchandle_11() { return &___gchandle_11; }
	inline void set_gchandle_11(int32_t value)
	{
		___gchandle_11 = value;
	}

	inline static int32_t get_offset_of_call_message_12() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___call_message_12)); }
	inline MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB * get_call_message_12() const { return ___call_message_12; }
	inline MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB ** get_address_of_call_message_12() { return &___call_message_12; }
	inline void set_call_message_12(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB * value)
	{
		___call_message_12 = value;
		Il2CppCodeGenWriteBarrier((&___call_message_12), value);
	}

	inline static int32_t get_offset_of_message_ctrl_13() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___message_ctrl_13)); }
	inline RuntimeObject* get_message_ctrl_13() const { return ___message_ctrl_13; }
	inline RuntimeObject** get_address_of_message_ctrl_13() { return &___message_ctrl_13; }
	inline void set_message_ctrl_13(RuntimeObject* value)
	{
		___message_ctrl_13 = value;
		Il2CppCodeGenWriteBarrier((&___message_ctrl_13), value);
	}

	inline static int32_t get_offset_of_reply_message_14() { return static_cast<int32_t>(offsetof(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F, ___reply_message_14)); }
	inline RuntimeObject* get_reply_message_14() const { return ___reply_message_14; }
	inline RuntimeObject** get_address_of_reply_message_14() { return &___reply_message_14; }
	inline void set_reply_message_14(RuntimeObject* value)
	{
		___reply_message_14 = value;
		Il2CppCodeGenWriteBarrier((&___reply_message_14), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASYNCRESULT_TAB8D16F4115F1F6CA976733C37369200FBE06F6F_H
#ifndef CALLTYPE_T03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2_H
#define CALLTYPE_T03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CallType
struct  CallType_t03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2 
{
public:
	// System.Int32 System.Runtime.Remoting.Messaging.CallType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CallType_t03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLTYPE_T03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2_H
#ifndef SOAPFIELDATTRIBUTE_TFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F_H
#define SOAPFIELDATTRIBUTE_TFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Metadata.SoapFieldAttribute
struct  SoapFieldAttribute_tFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F  : public SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C
{
public:
	// System.String System.Runtime.Remoting.Metadata.SoapFieldAttribute::_elementName
	String_t* ____elementName_3;
	// System.Boolean System.Runtime.Remoting.Metadata.SoapFieldAttribute::_isElement
	bool ____isElement_4;

public:
	inline static int32_t get_offset_of__elementName_3() { return static_cast<int32_t>(offsetof(SoapFieldAttribute_tFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F, ____elementName_3)); }
	inline String_t* get__elementName_3() const { return ____elementName_3; }
	inline String_t** get_address_of__elementName_3() { return &____elementName_3; }
	inline void set__elementName_3(String_t* value)
	{
		____elementName_3 = value;
		Il2CppCodeGenWriteBarrier((&____elementName_3), value);
	}

	inline static int32_t get_offset_of__isElement_4() { return static_cast<int32_t>(offsetof(SoapFieldAttribute_tFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F, ____isElement_4)); }
	inline bool get__isElement_4() const { return ____isElement_4; }
	inline bool* get_address_of__isElement_4() { return &____isElement_4; }
	inline void set__isElement_4(bool value)
	{
		____isElement_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOAPFIELDATTRIBUTE_TFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F_H
#ifndef SOAPMETHODATTRIBUTE_TC2B73B88040E7427B6168F5D77CB028575108518_H
#define SOAPMETHODATTRIBUTE_TC2B73B88040E7427B6168F5D77CB028575108518_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Metadata.SoapMethodAttribute
struct  SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518  : public SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C
{
public:
	// System.String System.Runtime.Remoting.Metadata.SoapMethodAttribute::_responseElement
	String_t* ____responseElement_3;
	// System.String System.Runtime.Remoting.Metadata.SoapMethodAttribute::_responseNamespace
	String_t* ____responseNamespace_4;
	// System.String System.Runtime.Remoting.Metadata.SoapMethodAttribute::_returnElement
	String_t* ____returnElement_5;
	// System.String System.Runtime.Remoting.Metadata.SoapMethodAttribute::_soapAction
	String_t* ____soapAction_6;
	// System.Boolean System.Runtime.Remoting.Metadata.SoapMethodAttribute::_useAttribute
	bool ____useAttribute_7;
	// System.String System.Runtime.Remoting.Metadata.SoapMethodAttribute::_namespace
	String_t* ____namespace_8;

public:
	inline static int32_t get_offset_of__responseElement_3() { return static_cast<int32_t>(offsetof(SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518, ____responseElement_3)); }
	inline String_t* get__responseElement_3() const { return ____responseElement_3; }
	inline String_t** get_address_of__responseElement_3() { return &____responseElement_3; }
	inline void set__responseElement_3(String_t* value)
	{
		____responseElement_3 = value;
		Il2CppCodeGenWriteBarrier((&____responseElement_3), value);
	}

	inline static int32_t get_offset_of__responseNamespace_4() { return static_cast<int32_t>(offsetof(SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518, ____responseNamespace_4)); }
	inline String_t* get__responseNamespace_4() const { return ____responseNamespace_4; }
	inline String_t** get_address_of__responseNamespace_4() { return &____responseNamespace_4; }
	inline void set__responseNamespace_4(String_t* value)
	{
		____responseNamespace_4 = value;
		Il2CppCodeGenWriteBarrier((&____responseNamespace_4), value);
	}

	inline static int32_t get_offset_of__returnElement_5() { return static_cast<int32_t>(offsetof(SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518, ____returnElement_5)); }
	inline String_t* get__returnElement_5() const { return ____returnElement_5; }
	inline String_t** get_address_of__returnElement_5() { return &____returnElement_5; }
	inline void set__returnElement_5(String_t* value)
	{
		____returnElement_5 = value;
		Il2CppCodeGenWriteBarrier((&____returnElement_5), value);
	}

	inline static int32_t get_offset_of__soapAction_6() { return static_cast<int32_t>(offsetof(SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518, ____soapAction_6)); }
	inline String_t* get__soapAction_6() const { return ____soapAction_6; }
	inline String_t** get_address_of__soapAction_6() { return &____soapAction_6; }
	inline void set__soapAction_6(String_t* value)
	{
		____soapAction_6 = value;
		Il2CppCodeGenWriteBarrier((&____soapAction_6), value);
	}

	inline static int32_t get_offset_of__useAttribute_7() { return static_cast<int32_t>(offsetof(SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518, ____useAttribute_7)); }
	inline bool get__useAttribute_7() const { return ____useAttribute_7; }
	inline bool* get_address_of__useAttribute_7() { return &____useAttribute_7; }
	inline void set__useAttribute_7(bool value)
	{
		____useAttribute_7 = value;
	}

	inline static int32_t get_offset_of__namespace_8() { return static_cast<int32_t>(offsetof(SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518, ____namespace_8)); }
	inline String_t* get__namespace_8() const { return ____namespace_8; }
	inline String_t** get_address_of__namespace_8() { return &____namespace_8; }
	inline void set__namespace_8(String_t* value)
	{
		____namespace_8 = value;
		Il2CppCodeGenWriteBarrier((&____namespace_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOAPMETHODATTRIBUTE_TC2B73B88040E7427B6168F5D77CB028575108518_H
#ifndef SOAPPARAMETERATTRIBUTE_T2B1BBF19903BB9170A576A86A73695D4D4E8A5DC_H
#define SOAPPARAMETERATTRIBUTE_T2B1BBF19903BB9170A576A86A73695D4D4E8A5DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Metadata.SoapParameterAttribute
struct  SoapParameterAttribute_t2B1BBF19903BB9170A576A86A73695D4D4E8A5DC  : public SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOAPPARAMETERATTRIBUTE_T2B1BBF19903BB9170A576A86A73695D4D4E8A5DC_H
#ifndef SOAPTYPEATTRIBUTE_T9221AF057EFADA4505E2B585BA5D6A5A75596E53_H
#define SOAPTYPEATTRIBUTE_T9221AF057EFADA4505E2B585BA5D6A5A75596E53_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Metadata.SoapTypeAttribute
struct  SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53  : public SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C
{
public:
	// System.Boolean System.Runtime.Remoting.Metadata.SoapTypeAttribute::_useAttribute
	bool ____useAttribute_3;
	// System.String System.Runtime.Remoting.Metadata.SoapTypeAttribute::_xmlElementName
	String_t* ____xmlElementName_4;
	// System.String System.Runtime.Remoting.Metadata.SoapTypeAttribute::_xmlNamespace
	String_t* ____xmlNamespace_5;
	// System.String System.Runtime.Remoting.Metadata.SoapTypeAttribute::_xmlTypeName
	String_t* ____xmlTypeName_6;
	// System.String System.Runtime.Remoting.Metadata.SoapTypeAttribute::_xmlTypeNamespace
	String_t* ____xmlTypeNamespace_7;
	// System.Boolean System.Runtime.Remoting.Metadata.SoapTypeAttribute::_isType
	bool ____isType_8;
	// System.Boolean System.Runtime.Remoting.Metadata.SoapTypeAttribute::_isElement
	bool ____isElement_9;

public:
	inline static int32_t get_offset_of__useAttribute_3() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____useAttribute_3)); }
	inline bool get__useAttribute_3() const { return ____useAttribute_3; }
	inline bool* get_address_of__useAttribute_3() { return &____useAttribute_3; }
	inline void set__useAttribute_3(bool value)
	{
		____useAttribute_3 = value;
	}

	inline static int32_t get_offset_of__xmlElementName_4() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____xmlElementName_4)); }
	inline String_t* get__xmlElementName_4() const { return ____xmlElementName_4; }
	inline String_t** get_address_of__xmlElementName_4() { return &____xmlElementName_4; }
	inline void set__xmlElementName_4(String_t* value)
	{
		____xmlElementName_4 = value;
		Il2CppCodeGenWriteBarrier((&____xmlElementName_4), value);
	}

	inline static int32_t get_offset_of__xmlNamespace_5() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____xmlNamespace_5)); }
	inline String_t* get__xmlNamespace_5() const { return ____xmlNamespace_5; }
	inline String_t** get_address_of__xmlNamespace_5() { return &____xmlNamespace_5; }
	inline void set__xmlNamespace_5(String_t* value)
	{
		____xmlNamespace_5 = value;
		Il2CppCodeGenWriteBarrier((&____xmlNamespace_5), value);
	}

	inline static int32_t get_offset_of__xmlTypeName_6() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____xmlTypeName_6)); }
	inline String_t* get__xmlTypeName_6() const { return ____xmlTypeName_6; }
	inline String_t** get_address_of__xmlTypeName_6() { return &____xmlTypeName_6; }
	inline void set__xmlTypeName_6(String_t* value)
	{
		____xmlTypeName_6 = value;
		Il2CppCodeGenWriteBarrier((&____xmlTypeName_6), value);
	}

	inline static int32_t get_offset_of__xmlTypeNamespace_7() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____xmlTypeNamespace_7)); }
	inline String_t* get__xmlTypeNamespace_7() const { return ____xmlTypeNamespace_7; }
	inline String_t** get_address_of__xmlTypeNamespace_7() { return &____xmlTypeNamespace_7; }
	inline void set__xmlTypeNamespace_7(String_t* value)
	{
		____xmlTypeNamespace_7 = value;
		Il2CppCodeGenWriteBarrier((&____xmlTypeNamespace_7), value);
	}

	inline static int32_t get_offset_of__isType_8() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____isType_8)); }
	inline bool get__isType_8() const { return ____isType_8; }
	inline bool* get_address_of__isType_8() { return &____isType_8; }
	inline void set__isType_8(bool value)
	{
		____isType_8 = value;
	}

	inline static int32_t get_offset_of__isElement_9() { return static_cast<int32_t>(offsetof(SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53, ____isElement_9)); }
	inline bool get__isElement_9() const { return ____isElement_9; }
	inline bool* get_address_of__isElement_9() { return &____isElement_9; }
	inline void set__isElement_9(bool value)
	{
		____isElement_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOAPTYPEATTRIBUTE_T9221AF057EFADA4505E2B585BA5D6A5A75596E53_H
#ifndef REMOTINGEXCEPTION_T55DCB40754746768483077D4A79F35FBCB3D116D_H
#define REMOTINGEXCEPTION_T55DCB40754746768483077D4A79F35FBCB3D116D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.RemotingException
struct  RemotingException_t55DCB40754746768483077D4A79F35FBCB3D116D  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTINGEXCEPTION_T55DCB40754746768483077D4A79F35FBCB3D116D_H
#ifndef RUNTIMEMETHODHANDLE_TB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C_H
#define RUNTIMEMETHODHANDLE_TB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeMethodHandle
struct  RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C 
{
public:
	// System.IntPtr System.RuntimeMethodHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEMETHODHANDLE_TB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C_H
#ifndef DATETIME_T816BBD9125EA02B42B87CB07643FC5F803391DA2_H
#define DATETIME_T816BBD9125EA02B42B87CB07643FC5F803391DA2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DateTime
struct  DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2 
{
public:
	// System.TimeSpan System.DateTime::ticks
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___ticks_0;
	// System.DateTimeKind System.DateTime::kind
	int32_t ___kind_1;

public:
	inline static int32_t get_offset_of_ticks_0() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2, ___ticks_0)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_ticks_0() const { return ___ticks_0; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_ticks_0() { return &___ticks_0; }
	inline void set_ticks_0(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___ticks_0 = value;
	}

	inline static int32_t get_offset_of_kind_1() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2, ___kind_1)); }
	inline int32_t get_kind_1() const { return ___kind_1; }
	inline int32_t* get_address_of_kind_1() { return &___kind_1; }
	inline void set_kind_1(int32_t value)
	{
		___kind_1 = value;
	}
};

struct DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields
{
public:
	// System.DateTime System.DateTime::MaxValue
	DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  ___MaxValue_2;
	// System.DateTime System.DateTime::MinValue
	DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  ___MinValue_3;
	// System.String[] System.DateTime::ParseTimeFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___ParseTimeFormats_4;
	// System.String[] System.DateTime::ParseYearDayMonthFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___ParseYearDayMonthFormats_5;
	// System.String[] System.DateTime::ParseYearMonthDayFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___ParseYearMonthDayFormats_6;
	// System.String[] System.DateTime::ParseDayMonthYearFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___ParseDayMonthYearFormats_7;
	// System.String[] System.DateTime::ParseMonthDayYearFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___ParseMonthDayYearFormats_8;
	// System.String[] System.DateTime::MonthDayShortFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___MonthDayShortFormats_9;
	// System.String[] System.DateTime::DayMonthShortFormats
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___DayMonthShortFormats_10;
	// System.Int32[] System.DateTime::daysmonth
	Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* ___daysmonth_11;
	// System.Int32[] System.DateTime::daysmonthleap
	Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* ___daysmonthleap_12;
	// System.Object System.DateTime::to_local_time_span_object
	RuntimeObject * ___to_local_time_span_object_13;
	// System.Int64 System.DateTime::last_now
	int64_t ___last_now_14;

public:
	inline static int32_t get_offset_of_MaxValue_2() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___MaxValue_2)); }
	inline DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  get_MaxValue_2() const { return ___MaxValue_2; }
	inline DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2 * get_address_of_MaxValue_2() { return &___MaxValue_2; }
	inline void set_MaxValue_2(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  value)
	{
		___MaxValue_2 = value;
	}

	inline static int32_t get_offset_of_MinValue_3() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___MinValue_3)); }
	inline DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  get_MinValue_3() const { return ___MinValue_3; }
	inline DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2 * get_address_of_MinValue_3() { return &___MinValue_3; }
	inline void set_MinValue_3(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  value)
	{
		___MinValue_3 = value;
	}

	inline static int32_t get_offset_of_ParseTimeFormats_4() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___ParseTimeFormats_4)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_ParseTimeFormats_4() const { return ___ParseTimeFormats_4; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_ParseTimeFormats_4() { return &___ParseTimeFormats_4; }
	inline void set_ParseTimeFormats_4(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___ParseTimeFormats_4 = value;
		Il2CppCodeGenWriteBarrier((&___ParseTimeFormats_4), value);
	}

	inline static int32_t get_offset_of_ParseYearDayMonthFormats_5() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___ParseYearDayMonthFormats_5)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_ParseYearDayMonthFormats_5() const { return ___ParseYearDayMonthFormats_5; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_ParseYearDayMonthFormats_5() { return &___ParseYearDayMonthFormats_5; }
	inline void set_ParseYearDayMonthFormats_5(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___ParseYearDayMonthFormats_5 = value;
		Il2CppCodeGenWriteBarrier((&___ParseYearDayMonthFormats_5), value);
	}

	inline static int32_t get_offset_of_ParseYearMonthDayFormats_6() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___ParseYearMonthDayFormats_6)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_ParseYearMonthDayFormats_6() const { return ___ParseYearMonthDayFormats_6; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_ParseYearMonthDayFormats_6() { return &___ParseYearMonthDayFormats_6; }
	inline void set_ParseYearMonthDayFormats_6(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___ParseYearMonthDayFormats_6 = value;
		Il2CppCodeGenWriteBarrier((&___ParseYearMonthDayFormats_6), value);
	}

	inline static int32_t get_offset_of_ParseDayMonthYearFormats_7() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___ParseDayMonthYearFormats_7)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_ParseDayMonthYearFormats_7() const { return ___ParseDayMonthYearFormats_7; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_ParseDayMonthYearFormats_7() { return &___ParseDayMonthYearFormats_7; }
	inline void set_ParseDayMonthYearFormats_7(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___ParseDayMonthYearFormats_7 = value;
		Il2CppCodeGenWriteBarrier((&___ParseDayMonthYearFormats_7), value);
	}

	inline static int32_t get_offset_of_ParseMonthDayYearFormats_8() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___ParseMonthDayYearFormats_8)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_ParseMonthDayYearFormats_8() const { return ___ParseMonthDayYearFormats_8; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_ParseMonthDayYearFormats_8() { return &___ParseMonthDayYearFormats_8; }
	inline void set_ParseMonthDayYearFormats_8(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___ParseMonthDayYearFormats_8 = value;
		Il2CppCodeGenWriteBarrier((&___ParseMonthDayYearFormats_8), value);
	}

	inline static int32_t get_offset_of_MonthDayShortFormats_9() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___MonthDayShortFormats_9)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_MonthDayShortFormats_9() const { return ___MonthDayShortFormats_9; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_MonthDayShortFormats_9() { return &___MonthDayShortFormats_9; }
	inline void set_MonthDayShortFormats_9(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___MonthDayShortFormats_9 = value;
		Il2CppCodeGenWriteBarrier((&___MonthDayShortFormats_9), value);
	}

	inline static int32_t get_offset_of_DayMonthShortFormats_10() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___DayMonthShortFormats_10)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_DayMonthShortFormats_10() const { return ___DayMonthShortFormats_10; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_DayMonthShortFormats_10() { return &___DayMonthShortFormats_10; }
	inline void set_DayMonthShortFormats_10(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___DayMonthShortFormats_10 = value;
		Il2CppCodeGenWriteBarrier((&___DayMonthShortFormats_10), value);
	}

	inline static int32_t get_offset_of_daysmonth_11() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___daysmonth_11)); }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* get_daysmonth_11() const { return ___daysmonth_11; }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074** get_address_of_daysmonth_11() { return &___daysmonth_11; }
	inline void set_daysmonth_11(Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* value)
	{
		___daysmonth_11 = value;
		Il2CppCodeGenWriteBarrier((&___daysmonth_11), value);
	}

	inline static int32_t get_offset_of_daysmonthleap_12() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___daysmonthleap_12)); }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* get_daysmonthleap_12() const { return ___daysmonthleap_12; }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074** get_address_of_daysmonthleap_12() { return &___daysmonthleap_12; }
	inline void set_daysmonthleap_12(Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* value)
	{
		___daysmonthleap_12 = value;
		Il2CppCodeGenWriteBarrier((&___daysmonthleap_12), value);
	}

	inline static int32_t get_offset_of_to_local_time_span_object_13() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___to_local_time_span_object_13)); }
	inline RuntimeObject * get_to_local_time_span_object_13() const { return ___to_local_time_span_object_13; }
	inline RuntimeObject ** get_address_of_to_local_time_span_object_13() { return &___to_local_time_span_object_13; }
	inline void set_to_local_time_span_object_13(RuntimeObject * value)
	{
		___to_local_time_span_object_13 = value;
		Il2CppCodeGenWriteBarrier((&___to_local_time_span_object_13), value);
	}

	inline static int32_t get_offset_of_last_now_14() { return static_cast<int32_t>(offsetof(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2_StaticFields, ___last_now_14)); }
	inline int64_t get_last_now_14() const { return ___last_now_14; }
	inline int64_t* get_address_of_last_now_14() { return &___last_now_14; }
	inline void set_last_now_14(int64_t value)
	{
		___last_now_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIME_T816BBD9125EA02B42B87CB07643FC5F803391DA2_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.MulticastDelegate System.MulticastDelegate::prev
	MulticastDelegate_t * ___prev_9;
	// System.MulticastDelegate System.MulticastDelegate::kpm_next
	MulticastDelegate_t * ___kpm_next_10;

public:
	inline static int32_t get_offset_of_prev_9() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___prev_9)); }
	inline MulticastDelegate_t * get_prev_9() const { return ___prev_9; }
	inline MulticastDelegate_t ** get_address_of_prev_9() { return &___prev_9; }
	inline void set_prev_9(MulticastDelegate_t * value)
	{
		___prev_9 = value;
		Il2CppCodeGenWriteBarrier((&___prev_9), value);
	}

	inline static int32_t get_offset_of_kpm_next_10() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___kpm_next_10)); }
	inline MulticastDelegate_t * get_kpm_next_10() const { return ___kpm_next_10; }
	inline MulticastDelegate_t ** get_address_of_kpm_next_10() { return &___kpm_next_10; }
	inline void set_kpm_next_10(MulticastDelegate_t * value)
	{
		___kpm_next_10 = value;
		Il2CppCodeGenWriteBarrier((&___kpm_next_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTICASTDELEGATE_T_H
#ifndef CADMETHODCALLMESSAGE_T6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED_H
#define CADMETHODCALLMESSAGE_T6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.CADMethodCallMessage
struct  CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED  : public CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3
{
public:
	// System.String System.Runtime.Remoting.Messaging.CADMethodCallMessage::_uri
	String_t* ____uri_4;
	// System.RuntimeMethodHandle System.Runtime.Remoting.Messaging.CADMethodCallMessage::MethodHandle
	RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C  ___MethodHandle_5;
	// System.String System.Runtime.Remoting.Messaging.CADMethodCallMessage::FullTypeName
	String_t* ___FullTypeName_6;

public:
	inline static int32_t get_offset_of__uri_4() { return static_cast<int32_t>(offsetof(CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED, ____uri_4)); }
	inline String_t* get__uri_4() const { return ____uri_4; }
	inline String_t** get_address_of__uri_4() { return &____uri_4; }
	inline void set__uri_4(String_t* value)
	{
		____uri_4 = value;
		Il2CppCodeGenWriteBarrier((&____uri_4), value);
	}

	inline static int32_t get_offset_of_MethodHandle_5() { return static_cast<int32_t>(offsetof(CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED, ___MethodHandle_5)); }
	inline RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C  get_MethodHandle_5() const { return ___MethodHandle_5; }
	inline RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C * get_address_of_MethodHandle_5() { return &___MethodHandle_5; }
	inline void set_MethodHandle_5(RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C  value)
	{
		___MethodHandle_5 = value;
	}

	inline static int32_t get_offset_of_FullTypeName_6() { return static_cast<int32_t>(offsetof(CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED, ___FullTypeName_6)); }
	inline String_t* get_FullTypeName_6() const { return ___FullTypeName_6; }
	inline String_t** get_address_of_FullTypeName_6() { return &___FullTypeName_6; }
	inline void set_FullTypeName_6(String_t* value)
	{
		___FullTypeName_6 = value;
		Il2CppCodeGenWriteBarrier((&___FullTypeName_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CADMETHODCALLMESSAGE_T6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED_H
#ifndef MONOMETHODMESSAGE_TD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB_H
#define MONOMETHODMESSAGE_TD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.MonoMethodMessage
struct  MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB  : public RuntimeObject
{
public:
	// System.Reflection.MonoMethod System.Runtime.Remoting.Messaging.MonoMethodMessage::method
	MonoMethod_t * ___method_0;
	// System.Object[] System.Runtime.Remoting.Messaging.MonoMethodMessage::args
	ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* ___args_1;
	// System.Byte[] System.Runtime.Remoting.Messaging.MonoMethodMessage::arg_types
	ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8* ___arg_types_2;
	// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.MonoMethodMessage::ctx
	LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * ___ctx_3;
	// System.Object System.Runtime.Remoting.Messaging.MonoMethodMessage::rval
	RuntimeObject * ___rval_4;
	// System.Exception System.Runtime.Remoting.Messaging.MonoMethodMessage::exc
	Exception_t * ___exc_5;
	// System.Runtime.Remoting.Messaging.AsyncResult System.Runtime.Remoting.Messaging.MonoMethodMessage::asyncResult
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F * ___asyncResult_6;
	// System.Runtime.Remoting.Messaging.CallType System.Runtime.Remoting.Messaging.MonoMethodMessage::call_type
	int32_t ___call_type_7;
	// System.String System.Runtime.Remoting.Messaging.MonoMethodMessage::uri
	String_t* ___uri_8;
	// System.Runtime.Remoting.Messaging.MethodCallDictionary System.Runtime.Remoting.Messaging.MonoMethodMessage::properties
	MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955 * ___properties_9;
	// System.Type[] System.Runtime.Remoting.Messaging.MonoMethodMessage::methodSignature
	TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* ___methodSignature_10;
	// System.Runtime.Remoting.Identity System.Runtime.Remoting.Messaging.MonoMethodMessage::identity
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C * ___identity_11;

public:
	inline static int32_t get_offset_of_method_0() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___method_0)); }
	inline MonoMethod_t * get_method_0() const { return ___method_0; }
	inline MonoMethod_t ** get_address_of_method_0() { return &___method_0; }
	inline void set_method_0(MonoMethod_t * value)
	{
		___method_0 = value;
		Il2CppCodeGenWriteBarrier((&___method_0), value);
	}

	inline static int32_t get_offset_of_args_1() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___args_1)); }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* get_args_1() const { return ___args_1; }
	inline ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D** get_address_of_args_1() { return &___args_1; }
	inline void set_args_1(ObjectU5BU5D_t8D571697F3A1B33B696E2F80500C21F1A1748C5D* value)
	{
		___args_1 = value;
		Il2CppCodeGenWriteBarrier((&___args_1), value);
	}

	inline static int32_t get_offset_of_arg_types_2() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___arg_types_2)); }
	inline ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8* get_arg_types_2() const { return ___arg_types_2; }
	inline ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8** get_address_of_arg_types_2() { return &___arg_types_2; }
	inline void set_arg_types_2(ByteU5BU5D_t8E14BD25C7BEB727CB1849CF449DE26B113309E8* value)
	{
		___arg_types_2 = value;
		Il2CppCodeGenWriteBarrier((&___arg_types_2), value);
	}

	inline static int32_t get_offset_of_ctx_3() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___ctx_3)); }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * get_ctx_3() const { return ___ctx_3; }
	inline LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 ** get_address_of_ctx_3() { return &___ctx_3; }
	inline void set_ctx_3(LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394 * value)
	{
		___ctx_3 = value;
		Il2CppCodeGenWriteBarrier((&___ctx_3), value);
	}

	inline static int32_t get_offset_of_rval_4() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___rval_4)); }
	inline RuntimeObject * get_rval_4() const { return ___rval_4; }
	inline RuntimeObject ** get_address_of_rval_4() { return &___rval_4; }
	inline void set_rval_4(RuntimeObject * value)
	{
		___rval_4 = value;
		Il2CppCodeGenWriteBarrier((&___rval_4), value);
	}

	inline static int32_t get_offset_of_exc_5() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___exc_5)); }
	inline Exception_t * get_exc_5() const { return ___exc_5; }
	inline Exception_t ** get_address_of_exc_5() { return &___exc_5; }
	inline void set_exc_5(Exception_t * value)
	{
		___exc_5 = value;
		Il2CppCodeGenWriteBarrier((&___exc_5), value);
	}

	inline static int32_t get_offset_of_asyncResult_6() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___asyncResult_6)); }
	inline AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F * get_asyncResult_6() const { return ___asyncResult_6; }
	inline AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F ** get_address_of_asyncResult_6() { return &___asyncResult_6; }
	inline void set_asyncResult_6(AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F * value)
	{
		___asyncResult_6 = value;
		Il2CppCodeGenWriteBarrier((&___asyncResult_6), value);
	}

	inline static int32_t get_offset_of_call_type_7() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___call_type_7)); }
	inline int32_t get_call_type_7() const { return ___call_type_7; }
	inline int32_t* get_address_of_call_type_7() { return &___call_type_7; }
	inline void set_call_type_7(int32_t value)
	{
		___call_type_7 = value;
	}

	inline static int32_t get_offset_of_uri_8() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___uri_8)); }
	inline String_t* get_uri_8() const { return ___uri_8; }
	inline String_t** get_address_of_uri_8() { return &___uri_8; }
	inline void set_uri_8(String_t* value)
	{
		___uri_8 = value;
		Il2CppCodeGenWriteBarrier((&___uri_8), value);
	}

	inline static int32_t get_offset_of_properties_9() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___properties_9)); }
	inline MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955 * get_properties_9() const { return ___properties_9; }
	inline MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955 ** get_address_of_properties_9() { return &___properties_9; }
	inline void set_properties_9(MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955 * value)
	{
		___properties_9 = value;
		Il2CppCodeGenWriteBarrier((&___properties_9), value);
	}

	inline static int32_t get_offset_of_methodSignature_10() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___methodSignature_10)); }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* get_methodSignature_10() const { return ___methodSignature_10; }
	inline TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532** get_address_of_methodSignature_10() { return &___methodSignature_10; }
	inline void set_methodSignature_10(TypeU5BU5D_tEF927658123F6CD4274B971442504A42AB6DE532* value)
	{
		___methodSignature_10 = value;
		Il2CppCodeGenWriteBarrier((&___methodSignature_10), value);
	}

	inline static int32_t get_offset_of_identity_11() { return static_cast<int32_t>(offsetof(MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB, ___identity_11)); }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C * get_identity_11() const { return ___identity_11; }
	inline Identity_tF0CD49E50E212E64314E0241852939303E414F1C ** get_address_of_identity_11() { return &___identity_11; }
	inline void set_identity_11(Identity_tF0CD49E50E212E64314E0241852939303E414F1C * value)
	{
		___identity_11 = value;
		Il2CppCodeGenWriteBarrier((&___identity_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOMETHODMESSAGE_TD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB_H
#ifndef REMOTINGSERVICES_TCA440C82AFE15218910FB7FDE52A0DC066F28844_H
#define REMOTINGSERVICES_TCA440C82AFE15218910FB7FDE52A0DC066F28844_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.RemotingServices
struct  RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844  : public RuntimeObject
{
public:

public:
};

struct RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields
{
public:
	// System.Collections.Hashtable System.Runtime.Remoting.RemotingServices::uri_hash
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___uri_hash_0;
	// System.Runtime.Serialization.Formatters.Binary.BinaryFormatter System.Runtime.Remoting.RemotingServices::_serializationFormatter
	BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F * ____serializationFormatter_1;
	// System.Runtime.Serialization.Formatters.Binary.BinaryFormatter System.Runtime.Remoting.RemotingServices::_deserializationFormatter
	BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F * ____deserializationFormatter_2;
	// System.String System.Runtime.Remoting.RemotingServices::app_id
	String_t* ___app_id_3;
	// System.Int32 System.Runtime.Remoting.RemotingServices::next_id
	int32_t ___next_id_4;
	// System.Reflection.BindingFlags System.Runtime.Remoting.RemotingServices::methodBindings
	int32_t ___methodBindings_5;
	// System.Reflection.MethodInfo System.Runtime.Remoting.RemotingServices::FieldSetterMethod
	MethodInfo_t * ___FieldSetterMethod_6;
	// System.Reflection.MethodInfo System.Runtime.Remoting.RemotingServices::FieldGetterMethod
	MethodInfo_t * ___FieldGetterMethod_7;

public:
	inline static int32_t get_offset_of_uri_hash_0() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ___uri_hash_0)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_uri_hash_0() const { return ___uri_hash_0; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_uri_hash_0() { return &___uri_hash_0; }
	inline void set_uri_hash_0(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___uri_hash_0 = value;
		Il2CppCodeGenWriteBarrier((&___uri_hash_0), value);
	}

	inline static int32_t get_offset_of__serializationFormatter_1() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ____serializationFormatter_1)); }
	inline BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F * get__serializationFormatter_1() const { return ____serializationFormatter_1; }
	inline BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F ** get_address_of__serializationFormatter_1() { return &____serializationFormatter_1; }
	inline void set__serializationFormatter_1(BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F * value)
	{
		____serializationFormatter_1 = value;
		Il2CppCodeGenWriteBarrier((&____serializationFormatter_1), value);
	}

	inline static int32_t get_offset_of__deserializationFormatter_2() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ____deserializationFormatter_2)); }
	inline BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F * get__deserializationFormatter_2() const { return ____deserializationFormatter_2; }
	inline BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F ** get_address_of__deserializationFormatter_2() { return &____deserializationFormatter_2; }
	inline void set__deserializationFormatter_2(BinaryFormatter_tF35E93D17C1978BB4914FCF1E799A41FA81AFF6F * value)
	{
		____deserializationFormatter_2 = value;
		Il2CppCodeGenWriteBarrier((&____deserializationFormatter_2), value);
	}

	inline static int32_t get_offset_of_app_id_3() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ___app_id_3)); }
	inline String_t* get_app_id_3() const { return ___app_id_3; }
	inline String_t** get_address_of_app_id_3() { return &___app_id_3; }
	inline void set_app_id_3(String_t* value)
	{
		___app_id_3 = value;
		Il2CppCodeGenWriteBarrier((&___app_id_3), value);
	}

	inline static int32_t get_offset_of_next_id_4() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ___next_id_4)); }
	inline int32_t get_next_id_4() const { return ___next_id_4; }
	inline int32_t* get_address_of_next_id_4() { return &___next_id_4; }
	inline void set_next_id_4(int32_t value)
	{
		___next_id_4 = value;
	}

	inline static int32_t get_offset_of_methodBindings_5() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ___methodBindings_5)); }
	inline int32_t get_methodBindings_5() const { return ___methodBindings_5; }
	inline int32_t* get_address_of_methodBindings_5() { return &___methodBindings_5; }
	inline void set_methodBindings_5(int32_t value)
	{
		___methodBindings_5 = value;
	}

	inline static int32_t get_offset_of_FieldSetterMethod_6() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ___FieldSetterMethod_6)); }
	inline MethodInfo_t * get_FieldSetterMethod_6() const { return ___FieldSetterMethod_6; }
	inline MethodInfo_t ** get_address_of_FieldSetterMethod_6() { return &___FieldSetterMethod_6; }
	inline void set_FieldSetterMethod_6(MethodInfo_t * value)
	{
		___FieldSetterMethod_6 = value;
		Il2CppCodeGenWriteBarrier((&___FieldSetterMethod_6), value);
	}

	inline static int32_t get_offset_of_FieldGetterMethod_7() { return static_cast<int32_t>(offsetof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields, ___FieldGetterMethod_7)); }
	inline MethodInfo_t * get_FieldGetterMethod_7() const { return ___FieldGetterMethod_7; }
	inline MethodInfo_t ** get_address_of_FieldGetterMethod_7() { return &___FieldGetterMethod_7; }
	inline void set_FieldGetterMethod_7(MethodInfo_t * value)
	{
		___FieldGetterMethod_7 = value;
		Il2CppCodeGenWriteBarrier((&___FieldGetterMethod_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTINGSERVICES_TCA440C82AFE15218910FB7FDE52A0DC066F28844_H
#ifndef LEASE_T748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA_H
#define LEASE_T748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Lifetime.Lease
struct  Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA  : public MarshalByRefObject_t05F62A8AC86E36BAE3063CA28097945DE9E179C4
{
public:
	// System.DateTime System.Runtime.Remoting.Lifetime.Lease::_leaseExpireTime
	DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  ____leaseExpireTime_1;
	// System.Runtime.Remoting.Lifetime.LeaseState System.Runtime.Remoting.Lifetime.Lease::_currentState
	int32_t ____currentState_2;
	// System.TimeSpan System.Runtime.Remoting.Lifetime.Lease::_initialLeaseTime
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____initialLeaseTime_3;
	// System.TimeSpan System.Runtime.Remoting.Lifetime.Lease::_renewOnCallTime
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____renewOnCallTime_4;
	// System.TimeSpan System.Runtime.Remoting.Lifetime.Lease::_sponsorshipTimeout
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ____sponsorshipTimeout_5;
	// System.Collections.ArrayList System.Runtime.Remoting.Lifetime.Lease::_sponsors
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ____sponsors_6;
	// System.Collections.Queue System.Runtime.Remoting.Lifetime.Lease::_renewingSponsors
	Queue_t2B066F5DA52AD958C3B9532F7C88339BA1427EAD * ____renewingSponsors_7;
	// System.Runtime.Remoting.Lifetime.Lease_RenewalDelegate System.Runtime.Remoting.Lifetime.Lease::_renewalDelegate
	RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD * ____renewalDelegate_8;

public:
	inline static int32_t get_offset_of__leaseExpireTime_1() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____leaseExpireTime_1)); }
	inline DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  get__leaseExpireTime_1() const { return ____leaseExpireTime_1; }
	inline DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2 * get_address_of__leaseExpireTime_1() { return &____leaseExpireTime_1; }
	inline void set__leaseExpireTime_1(DateTime_t816BBD9125EA02B42B87CB07643FC5F803391DA2  value)
	{
		____leaseExpireTime_1 = value;
	}

	inline static int32_t get_offset_of__currentState_2() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____currentState_2)); }
	inline int32_t get__currentState_2() const { return ____currentState_2; }
	inline int32_t* get_address_of__currentState_2() { return &____currentState_2; }
	inline void set__currentState_2(int32_t value)
	{
		____currentState_2 = value;
	}

	inline static int32_t get_offset_of__initialLeaseTime_3() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____initialLeaseTime_3)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__initialLeaseTime_3() const { return ____initialLeaseTime_3; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__initialLeaseTime_3() { return &____initialLeaseTime_3; }
	inline void set__initialLeaseTime_3(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____initialLeaseTime_3 = value;
	}

	inline static int32_t get_offset_of__renewOnCallTime_4() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____renewOnCallTime_4)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__renewOnCallTime_4() const { return ____renewOnCallTime_4; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__renewOnCallTime_4() { return &____renewOnCallTime_4; }
	inline void set__renewOnCallTime_4(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____renewOnCallTime_4 = value;
	}

	inline static int32_t get_offset_of__sponsorshipTimeout_5() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____sponsorshipTimeout_5)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get__sponsorshipTimeout_5() const { return ____sponsorshipTimeout_5; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of__sponsorshipTimeout_5() { return &____sponsorshipTimeout_5; }
	inline void set__sponsorshipTimeout_5(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		____sponsorshipTimeout_5 = value;
	}

	inline static int32_t get_offset_of__sponsors_6() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____sponsors_6)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get__sponsors_6() const { return ____sponsors_6; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of__sponsors_6() { return &____sponsors_6; }
	inline void set__sponsors_6(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		____sponsors_6 = value;
		Il2CppCodeGenWriteBarrier((&____sponsors_6), value);
	}

	inline static int32_t get_offset_of__renewingSponsors_7() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____renewingSponsors_7)); }
	inline Queue_t2B066F5DA52AD958C3B9532F7C88339BA1427EAD * get__renewingSponsors_7() const { return ____renewingSponsors_7; }
	inline Queue_t2B066F5DA52AD958C3B9532F7C88339BA1427EAD ** get_address_of__renewingSponsors_7() { return &____renewingSponsors_7; }
	inline void set__renewingSponsors_7(Queue_t2B066F5DA52AD958C3B9532F7C88339BA1427EAD * value)
	{
		____renewingSponsors_7 = value;
		Il2CppCodeGenWriteBarrier((&____renewingSponsors_7), value);
	}

	inline static int32_t get_offset_of__renewalDelegate_8() { return static_cast<int32_t>(offsetof(Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA, ____renewalDelegate_8)); }
	inline RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD * get__renewalDelegate_8() const { return ____renewalDelegate_8; }
	inline RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD ** get_address_of__renewalDelegate_8() { return &____renewalDelegate_8; }
	inline void set__renewalDelegate_8(RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD * value)
	{
		____renewalDelegate_8 = value;
		Il2CppCodeGenWriteBarrier((&____renewalDelegate_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEASE_T748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA_H
#ifndef RENEWALDELEGATE_TB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD_H
#define RENEWALDELEGATE_TB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Lifetime.Lease_RenewalDelegate
struct  RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENEWALDELEGATE_TB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize500 = { sizeof (DynamicPropertyReg_t235A8D7D81829009D705A9CE5994E9999E9099EF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable500[2] = 
{
	DynamicPropertyReg_t235A8D7D81829009D705A9CE5994E9999E9099EF::get_offset_of_Property_0(),
	DynamicPropertyReg_t235A8D7D81829009D705A9CE5994E9999E9099EF::get_offset_of_Sink_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize501 = { sizeof (ContextCallbackObject_t5FEDC6283CDC9DF160A27AF9728358C628299D0B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize502 = { sizeof (ContextAttribute_t1FF262D37B13FE267B0362600ACCFF5A8CD4603E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable502[1] = 
{
	ContextAttribute_t1FF262D37B13FE267B0362600ACCFF5A8CD4603E::get_offset_of_AttributeName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize503 = { sizeof (CrossContextChannel_t829E9251B05682ACAD9FAEEB35BED50A361EA883), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize504 = { sizeof (ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable504[3] = 
{
	ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F::get_offset_of__next_0(),
	ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F::get_offset_of__context_1(),
	ContextRestoreSink_t3D9E83C836390D19B42CA1056E073E1AB4C00B5F::get_offset_of__call_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize505 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize506 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize507 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize508 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize509 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize510 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize511 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize512 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize513 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize514 = { sizeof (SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable514[5] = 
{
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F::get_offset_of__bReEntrant_1(),
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F::get_offset_of__flavor_2(),
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F::get_offset_of__lockCount_3(),
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F::get_offset_of__mutex_4(),
	SynchronizationAttribute_t3A33565C21222F3107329890095AA5B7B484BC2F::get_offset_of__ownerThread_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize515 = { sizeof (SynchronizedClientContextSink_t5F678409C7E397E3789342AF86487D14D2B7D434), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable515[2] = 
{
	SynchronizedClientContextSink_t5F678409C7E397E3789342AF86487D14D2B7D434::get_offset_of__next_0(),
	SynchronizedClientContextSink_t5F678409C7E397E3789342AF86487D14D2B7D434::get_offset_of__att_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize516 = { sizeof (SynchronizedServerContextSink_tDA1E9099B9197694F96B872E96E9CDD250AFDD80), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable516[2] = 
{
	SynchronizedServerContextSink_tDA1E9099B9197694F96B872E96E9CDD250AFDD80::get_offset_of__next_0(),
	SynchronizedServerContextSink_tDA1E9099B9197694F96B872E96E9CDD250AFDD80::get_offset_of__att_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize517 = { sizeof (SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable517[3] = 
{
	SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB::get_offset_of__next_0(),
	SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB::get_offset_of__newLock_1(),
	SynchronizedContextReplySink_t7DBC565402D49BB7648400D9299BEC0903A0F7EB::get_offset_of__att_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize518 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize519 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize520 = { sizeof (Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable520[8] = 
{
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__leaseExpireTime_1(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__currentState_2(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__initialLeaseTime_3(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__renewOnCallTime_4(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__sponsorshipTimeout_5(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__sponsors_6(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__renewingSponsors_7(),
	Lease_t748F0AC7BB57863FBEE55F6DD4B0615AEBCFF4DA::get_offset_of__renewalDelegate_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize521 = { sizeof (RenewalDelegate_tB64EB739EE8D54F822DEF335BFF81EBC4B59BAAD), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize522 = { sizeof (LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable522[2] = 
{
	LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D::get_offset_of__objects_0(),
	LeaseManager_tE0A31CEC9A976AC72C54B4D87B5FA124B461049D::get_offset_of__timer_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize523 = { sizeof (LeaseSink_t4782A8795E980D5DCFB300E06675F7AD96059114), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable523[1] = 
{
	LeaseSink_t4782A8795E980D5DCFB300E06675F7AD96059114::get_offset_of__nextSink_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize524 = { sizeof (LeaseState_t27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable524[6] = 
{
	LeaseState_t27E5D5C1B201BC9B7C5BB744C8282F0EA38A1BFD::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize525 = { sizeof (LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97), -1, sizeof(LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable525[5] = 
{
	LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields::get_offset_of__leaseManagerPollTime_0(),
	LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields::get_offset_of__leaseTime_1(),
	LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields::get_offset_of__renewOnCallTime_2(),
	LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields::get_offset_of__sponsorshipTimeout_3(),
	LifetimeServices_t5E8AAEA14A28CB357D5F7C17C1661ADBAB4BDD97_StaticFields::get_offset_of__leaseManager_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize526 = { sizeof (ArgInfoType_t01886B60C76F16FB3370C25BBF27CD055B3D1F61)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable526[3] = 
{
	ArgInfoType_t01886B60C76F16FB3370C25BBF27CD055B3D1F61::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize527 = { sizeof (ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable527[3] = 
{
	ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3::get_offset_of__paramMap_0(),
	ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3::get_offset_of__inoutArgCount_1(),
	ArgInfo_tC55D916C7CFDDB6ECA541A413FFD67895BD594A3::get_offset_of__method_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize528 = { sizeof (AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable528[15] = 
{
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_async_state_0(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_handle_1(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_async_delegate_2(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_data_3(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_object_data_4(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_sync_completed_5(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_completed_6(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_endinvoke_called_7(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_async_callback_8(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_current_9(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_original_10(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_gchandle_11(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_call_message_12(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_message_ctrl_13(),
	AsyncResult_tAB8D16F4115F1F6CA976733C37369200FBE06F6F::get_offset_of_reply_message_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize529 = { sizeof (CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable529[1] = 
{
	CADArgHolder_t496415C662E90A308A1160B8487C05033DE4A120::get_offset_of_index_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize530 = { sizeof (CADObjRef_t48D330C04C98DCBB71727B2DE3026035567ADC64), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable530[2] = 
{
	CADObjRef_t48D330C04C98DCBB71727B2DE3026035567ADC64::get_offset_of_objref_0(),
	CADObjRef_t48D330C04C98DCBB71727B2DE3026035567ADC64::get_offset_of_SourceDomain_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize531 = { sizeof (CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable531[4] = 
{
	CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3::get_offset_of__args_0(),
	CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3::get_offset_of__serializedArgs_1(),
	CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3::get_offset_of__propertyCount_2(),
	CADMessageBase_tDDC7ADA64877C910A0AFC09B02477A2D293D46D3::get_offset_of__callContext_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize532 = { sizeof (CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable532[3] = 
{
	CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED::get_offset_of__uri_4(),
	CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED::get_offset_of_MethodHandle_5(),
	CADMethodCallMessage_t6D35114FB2CC5E23D217A85B4FA94A22BDFE84ED::get_offset_of_FullTypeName_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize533 = { sizeof (CADMethodReturnMessage_t37697335001303C9589BF01160C9EF847CCC25F4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable533[2] = 
{
	CADMethodReturnMessage_t37697335001303C9589BF01160C9EF847CCC25F4::get_offset_of__returnValue_4(),
	CADMethodReturnMessage_t37697335001303C9589BF01160C9EF847CCC25F4::get_offset_of__exception_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize534 = { sizeof (CallContext_t0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE), -1, 0, sizeof(CallContext_t0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_ThreadStaticFields) };
extern const int32_t g_FieldOffsetTable534[1] = 
{
	CallContext_t0B5B6B6CFA38C4C16FD6CE49DA8A897B85C5D4CE_ThreadStaticFields::get_offset_of_datastore_0() | THREAD_LOCAL_STATIC_MASK,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize535 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize536 = { sizeof (ClientContextTerminatorSink_tF01CDC694E6619B1959C265E9D41B3A0086828A3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable536[1] = 
{
	ClientContextTerminatorSink_tF01CDC694E6619B1959C265E9D41B3A0086828A3::get_offset_of__context_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize537 = { sizeof (ClientContextReplySink_t199694E57B7E4C90D73CE97E3502366BFF803487), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable537[2] = 
{
	ClientContextReplySink_t199694E57B7E4C90D73CE97E3502366BFF803487::get_offset_of__replySink_0(),
	ClientContextReplySink_t199694E57B7E4C90D73CE97E3502366BFF803487::get_offset_of__context_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize538 = { sizeof (ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82), -1, sizeof(ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable538[8] = 
{
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__activator_12(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__activationAttributes_13(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__contextProperties_14(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__activationType_15(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__activationTypeName_16(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__isContextOk_17(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82::get_offset_of__sourceProxy_18(),
	ConstructionCall_t48FA0FAA9F267E894809FD9F7A883FF5C54BCB82_StaticFields::get_offset_of_U3CU3Ef__switchU24map20_19(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize539 = { sizeof (ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB), -1, sizeof(ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable539[3] = 
{
	ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields::get_offset_of_InternalKeys_6(),
	ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields::get_offset_of_U3CU3Ef__switchU24map23_7(),
	ConstructionCallDictionary_tD8AE20934AD23930822FC405FBB8606AAC2F11BB_StaticFields::get_offset_of_U3CU3Ef__switchU24map24_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize540 = { sizeof (ConstructionResponse_tC25C1658A8BC826BA04B8BD2C2FB8F2CB3A08178), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize541 = { sizeof (EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE), -1, sizeof(EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable541[1] = 
{
	EnvoyTerminatorSink_t429A6D2FEE36B6AFD8D98FED3177BBF4BAC877BE_StaticFields::get_offset_of_Instance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize542 = { sizeof (ErrorMessage_tCD2EB85BCC8F58121C393D677E33836B2F006928), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable542[1] = 
{
	ErrorMessage_tCD2EB85BCC8F58121C393D677E33836B2F006928::get_offset_of__uri_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize543 = { sizeof (Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable543[4] = 
{
	Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C::get_offset_of_HeaderNamespace_0(),
	Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C::get_offset_of_MustUnderstand_1(),
	Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C::get_offset_of_Name_2(),
	Header_t60102AE64AB00EA81BC9A7743769B4C6BCB6466C::get_offset_of_Value_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize544 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize545 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize546 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize547 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize548 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize549 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize550 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize551 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize552 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize553 = { sizeof (LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable553[2] = 
{
	LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394::get_offset_of__data_0(),
	LogicalCallContext_t8D7FEDA33FC061AEAF5328F3384F16EAA9DC0394::get_offset_of__remotingData_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize554 = { sizeof (CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable554[1] = 
{
	CallContextRemotingData_t3609DDA17E5FECC992B01CCEBB0C2FD5424D390A::get_offset_of__logicalCallID_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize555 = { sizeof (MethodCall_t85B750F7999345054735594566D42DDF9C378FD3), -1, sizeof(MethodCall_t85B750F7999345054735594566D42DDF9C378FD3_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable555[12] = 
{
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__uri_0(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__typeName_1(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__methodName_2(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__args_3(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__methodSignature_4(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__methodBase_5(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__callContext_6(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__targetIdentity_7(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of__genericArguments_8(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of_ExternalProperties_9(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3::get_offset_of_InternalProperties_10(),
	MethodCall_t85B750F7999345054735594566D42DDF9C378FD3_StaticFields::get_offset_of_U3CU3Ef__switchU24map1F_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize556 = { sizeof (MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955), -1, sizeof(MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable556[1] = 
{
	MethodCallDictionary_t81152FFCAEB2709A693B1BF9900E3B71BFC83955_StaticFields::get_offset_of_InternalKeys_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize557 = { sizeof (MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D), -1, sizeof(MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable557[6] = 
{
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D::get_offset_of__internalProperties_0(),
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D::get_offset_of__message_1(),
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D::get_offset_of__methodKeys_2(),
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D::get_offset_of__ownProperties_3(),
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D_StaticFields::get_offset_of_U3CU3Ef__switchU24map21_4(),
	MethodDictionary_tA35F7EE01E1D34F2D45912618AB057B0FD411A9D_StaticFields::get_offset_of_U3CU3Ef__switchU24map22_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize558 = { sizeof (DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable558[3] = 
{
	DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4::get_offset_of__methodDictionary_0(),
	DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4::get_offset_of__hashtableEnum_1(),
	DictionaryEnumerator_t3FFF57C0F4470DE43C2E89CE9DB0CCF3F82D41B4::get_offset_of__posMethod_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize559 = { sizeof (MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD), -1, sizeof(MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable559[16] = 
{
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__methodName_0(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__uri_1(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__typeName_2(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__methodBase_3(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__returnValue_4(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__exception_5(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__methodSignature_6(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__inArgInfo_7(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__args_8(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__outArgs_9(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__callMsg_10(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__callContext_11(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of__targetIdentity_12(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of_ExternalProperties_13(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD::get_offset_of_InternalProperties_14(),
	MethodResponse_t381DAAD69EA6A5CAC84E42D0736613009CD43BFD_StaticFields::get_offset_of_U3CU3Ef__switchU24map25_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize560 = { sizeof (MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66), -1, sizeof(MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable560[2] = 
{
	MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66_StaticFields::get_offset_of_InternalReturnKeys_6(),
	MethodReturnDictionary_tF861BE703565E068497C6AEDEC97A98A24C97B66_StaticFields::get_offset_of_InternalExceptionKeys_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize561 = { sizeof (MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable561[12] = 
{
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_method_0(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_args_1(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_arg_types_2(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_ctx_3(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_rval_4(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_exc_5(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_asyncResult_6(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_call_type_7(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_uri_8(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_properties_9(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_methodSignature_10(),
	MonoMethodMessage_tD5E953A5EB1E0FBDC2D9000138DD840B8FBE8ECB::get_offset_of_identity_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize562 = { sizeof (CallType_t03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable562[5] = 
{
	CallType_t03D41FBF01D8C1867614B8E6D86BD13E6EC3B5E2::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize563 = { sizeof (OneWayAttribute_t6F328E7A9D112A58CAACA1DE7899FAD3A7B12C5A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize564 = { sizeof (RemotingSurrogate_tD5197EE223360C43095A27049D0F97F699D13707), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize565 = { sizeof (ObjRefSurrogate_tC4BC6525B31A9362AF31243F87A6E4FCB13A37DA), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize566 = { sizeof (RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2), -1, sizeof(RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable566[4] = 
{
	RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields::get_offset_of_s_cachedTypeObjRef_0(),
	RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields::get_offset_of__objRefSurrogate_1(),
	RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2_StaticFields::get_offset_of__objRemotingSurrogate_2(),
	RemotingSurrogateSelector_t890C8755F1BF0E78F016F78B1009C4DBAEFB3DB2::get_offset_of__next_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize567 = { sizeof (ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable567[14] = 
{
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__outArgs_0(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__args_1(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__outArgsCount_2(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__callCtx_3(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__returnValue_4(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__uri_5(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__exception_6(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__methodBase_7(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__methodName_8(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__methodSignature_9(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__typeName_10(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__properties_11(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__targetIdentity_12(),
	ReturnMessage_t81F6C70C9CF551ACF6EF3582C87ACD0861B41F89::get_offset_of__inArgInfo_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize568 = { sizeof (ServerContextTerminatorSink_tD6DFD5D259D3377EB5E770C520190215895AFA24), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize569 = { sizeof (ServerObjectTerminatorSink_tA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable569[1] = 
{
	ServerObjectTerminatorSink_tA3216B23DDBC31AC38A4FF9E687EAFA65FDE3373::get_offset_of__nextSink_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize570 = { sizeof (ServerObjectReplySink_t97058531C779A237BF58FDA6CFB4263A8A23521B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable570[2] = 
{
	ServerObjectReplySink_t97058531C779A237BF58FDA6CFB4263A8A23521B::get_offset_of__replySink_0(),
	ServerObjectReplySink_t97058531C779A237BF58FDA6CFB4263A8A23521B::get_offset_of__identity_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize571 = { sizeof (StackBuilderSink_t0714062B96AD616BED7912BB6D8B36EEB08743AD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable571[2] = 
{
	StackBuilderSink_t0714062B96AD616BED7912BB6D8B36EEB08743AD::get_offset_of__target_0(),
	StackBuilderSink_t0714062B96AD616BED7912BB6D8B36EEB08743AD::get_offset_of__rp_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize572 = { sizeof (SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable572[3] = 
{
	SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C::get_offset_of__useAttribute_0(),
	SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C::get_offset_of_ProtXmlNamespace_1(),
	SoapAttribute_t34BB5310349A1A042D17B95AAF6E3FE21113213C::get_offset_of_ReflectInfo_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize573 = { sizeof (SoapFieldAttribute_tFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable573[2] = 
{
	SoapFieldAttribute_tFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F::get_offset_of__elementName_3(),
	SoapFieldAttribute_tFDF91B16E0B1CDBF31117AC9E5EEEC59BD425F4F::get_offset_of__isElement_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize574 = { sizeof (SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable574[6] = 
{
	SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518::get_offset_of__responseElement_3(),
	SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518::get_offset_of__responseNamespace_4(),
	SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518::get_offset_of__returnElement_5(),
	SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518::get_offset_of__soapAction_6(),
	SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518::get_offset_of__useAttribute_7(),
	SoapMethodAttribute_tC2B73B88040E7427B6168F5D77CB028575108518::get_offset_of__namespace_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize575 = { sizeof (SoapParameterAttribute_t2B1BBF19903BB9170A576A86A73695D4D4E8A5DC), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize576 = { sizeof (SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable576[7] = 
{
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__useAttribute_3(),
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__xmlElementName_4(),
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__xmlNamespace_5(),
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__xmlTypeName_6(),
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__xmlTypeNamespace_7(),
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__isType_8(),
	SoapTypeAttribute_t9221AF057EFADA4505E2B585BA5D6A5A75596E53::get_offset_of__isElement_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize577 = { sizeof (ProxyAttribute_tB6D3B943A5E0554E3864C06D36FB99E16D8B92D3), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize578 = { sizeof (TransparentProxy_t6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable578[1] = 
{
	TransparentProxy_t6BE4833EB4F3F26D3243547F77E95F0FD7BA8A82::get_offset_of__rp_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize579 = { sizeof (RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable579[8] = 
{
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of_class_to_proxy_0(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__targetContext_1(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__server_2(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__targetDomainId_3(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__targetUri_4(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__objectIdentity_5(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__objTP_6(),
	RealProxy_tC971069F7F85FD850F1C09B18D93E965629C11DC::get_offset_of__stubData_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize580 = { sizeof (RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC), -1, sizeof(RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable580[5] = 
{
	RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_StaticFields::get_offset_of__cache_GetTypeMethod_8(),
	RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC_StaticFields::get_offset_of__cache_GetHashCodeMethod_9(),
	RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC::get_offset_of__sink_10(),
	RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC::get_offset_of__hasEnvoySink_11(),
	RemotingProxy_tAB1BD6F4E8D8DD64A7593CC4383E8346C0B180DC::get_offset_of__ctorCall_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize581 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize582 = { sizeof (TrackingServices_t7A66467D14B401CDC816062629135DA735ACB540), -1, sizeof(TrackingServices_t7A66467D14B401CDC816062629135DA735ACB540_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable582[1] = 
{
	TrackingServices_t7A66467D14B401CDC816062629135DA735ACB540_StaticFields::get_offset_of__handlers_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize583 = { sizeof (ActivatedClientTypeEntry_t51132D05D449780F0436A6E96BE6CBF20DE73A0E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable583[2] = 
{
	ActivatedClientTypeEntry_t51132D05D449780F0436A6E96BE6CBF20DE73A0E::get_offset_of_applicationUrl_2(),
	ActivatedClientTypeEntry_t51132D05D449780F0436A6E96BE6CBF20DE73A0E::get_offset_of_obj_type_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize584 = { sizeof (ActivatedServiceTypeEntry_tFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable584[1] = 
{
	ActivatedServiceTypeEntry_tFF5E7AD9913E2A3B13E5E673E92FBC012A7A3166::get_offset_of_obj_type_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize585 = { sizeof (EnvoyInfo_t79CF15F10598F653E9EB2EAE84843DE26879895F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable585[1] = 
{
	EnvoyInfo_t79CF15F10598F653E9EB2EAE84843DE26879895F::get_offset_of_envoySinks_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize586 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize587 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize588 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize589 = { sizeof (Identity_tF0CD49E50E212E64314E0241852939303E414F1C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable589[7] = 
{
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__objectUri_0(),
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__channelSink_1(),
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__envoySink_2(),
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__clientDynamicProperties_3(),
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__serverDynamicProperties_4(),
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__objRef_5(),
	Identity_tF0CD49E50E212E64314E0241852939303E414F1C::get_offset_of__disposed_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize590 = { sizeof (ClientIdentity_tE7070C34A48491598CA7EA0F84F62CD137DF0ABA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable590[1] = 
{
	ClientIdentity_tE7070C34A48491598CA7EA0F84F62CD137DF0ABA::get_offset_of__proxyReference_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize591 = { sizeof (InternalRemotingServices_t7D245B274133CEAFA377675A79E8A24FD14DC940), -1, sizeof(InternalRemotingServices_t7D245B274133CEAFA377675A79E8A24FD14DC940_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable591[1] = 
{
	InternalRemotingServices_t7D245B274133CEAFA377675A79E8A24FD14DC940_StaticFields::get_offset_of__soapAttributes_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize592 = { sizeof (ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E), -1, sizeof(ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable592[9] = 
{
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E::get_offset_of_channel_info_0(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E::get_offset_of_uri_1(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E::get_offset_of_typeInfo_2(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E::get_offset_of_envoyInfo_3(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E::get_offset_of_flags_4(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E::get_offset_of__serverType_5(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields::get_offset_of_MarshalledObjectRef_6(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields::get_offset_of_WellKnowObjectRef_7(),
	ObjRef_t2E5ABE92709BF374001BFE686A4709CADAFDC43E_StaticFields::get_offset_of_U3CU3Ef__switchU24map26_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize593 = { sizeof (RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE), -1, sizeof(RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable593[13] = 
{
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_applicationID_0(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_applicationName_1(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_processGuid_2(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_defaultConfigRead_3(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_defaultDelayedConfigRead_4(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of__errorMode_5(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_wellKnownClientEntries_6(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_activatedClientEntries_7(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_wellKnownServiceEntries_8(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_activatedServiceEntries_9(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_channelTemplates_10(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_clientProviderTemplates_11(),
	RemotingConfiguration_t8B2467FCAB03DCAD7DEA9FC8C8167102570F20AE_StaticFields::get_offset_of_serverProviderTemplates_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize594 = { sizeof (ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7), -1, sizeof(ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable594[10] = 
{
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_typeEntries_0(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_channelInstances_1(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_currentChannel_2(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_currentProviderData_3(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_currentClientUrl_4(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_appName_5(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_currentXmlPath_6(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7::get_offset_of_onlyDelayedChannels_7(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_StaticFields::get_offset_of_U3CU3Ef__switchU24map27_8(),
	ConfigHandler_tF2AD32F7293E2BBA4E5D1640D5EA641FC27F83B7_StaticFields::get_offset_of_U3CU3Ef__switchU24map28_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize595 = { sizeof (ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable595[7] = 
{
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of_Ref_0(),
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of_Type_1(),
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of_Id_2(),
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of_DelayLoadAsClientChannel_3(),
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of__serverProviders_4(),
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of__clientProviders_5(),
	ChannelData_t997D911D30243EF5FCD251C12F4225C983D7D289::get_offset_of__customProperties_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize596 = { sizeof (ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable596[5] = 
{
	ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB::get_offset_of_Ref_0(),
	ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB::get_offset_of_Type_1(),
	ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB::get_offset_of_Id_2(),
	ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB::get_offset_of_CustomProperties_3(),
	ProviderData_tF2FEAC7659ED3E5E2D79C4A74164DE3B046E82DB::get_offset_of_CustomData_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize597 = { sizeof (FormatterData_t0CA61A6A29D9A253AE45809E1A2F56FE9D323A9D), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize598 = { sizeof (RemotingException_t55DCB40754746768483077D4A79F35FBCB3D116D), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize599 = { sizeof (RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844), -1, sizeof(RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable599[8] = 
{
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of_uri_hash_0(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of__serializationFormatter_1(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of__deserializationFormatter_2(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of_app_id_3(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of_next_id_4(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of_methodBindings_5(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of_FieldSetterMethod_6(),
	RemotingServices_tCA440C82AFE15218910FB7FDE52A0DC066F28844_StaticFields::get_offset_of_FieldGetterMethod_7(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
