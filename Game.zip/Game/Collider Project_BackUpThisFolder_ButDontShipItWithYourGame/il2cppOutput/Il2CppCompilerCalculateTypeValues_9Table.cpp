﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// Mono.Math.BigInteger
struct BigInteger_tF09EFBB3E46B0632E6099DEAB0A4DB7042F48B65;
// System.AssemblyLoadEventArgs
struct AssemblyLoadEventArgs_t3DE284E3661E4FC091FB44B85C30B228B19E58DE;
// System.AsyncCallback
struct AsyncCallback_t74ABD1277F711E7FBDCB00E169A63DEFD39E86A2;
// System.Char[]
struct CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744;
// System.Collections.ArrayList
struct ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F;
// System.Collections.Hashtable
struct Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82;
// System.Collections.IComparer
struct IComparer_t971EE8726C43A8A086B35A11585E2AEFF2F7C2EB;
// System.Collections.IDictionary
struct IDictionary_tD35B9437F08BE98D1E0B295CC73C48E168CAB316;
// System.Collections.IEqualityComparer
struct IEqualityComparer_tFBE0A1A09BAE01058D6DE65DD4FE16C50CB8E781;
// System.Collections.IHashCodeProvider
struct IHashCodeProvider_t2302C769B9686FD002965B00B8A3704D828517D5;
// System.Collections.Specialized.ListDictionary
struct ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA;
// System.Collections.Specialized.ListDictionary/DictionaryNode
struct DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973;
// System.Collections.Specialized.NameObjectCollectionBase
struct NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070;
// System.Collections.Specialized.NameObjectCollectionBase/KeysCollection
struct KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB;
// System.Collections.Specialized.NameObjectCollectionBase/_Item
struct _Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7;
// System.DelegateData
struct DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9;
// System.EventArgs
struct EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17;
// System.Globalization.CompareInfo
struct CompareInfo_t704FFB923C9EF69DFAE63C1950E5B466A94C0F4B;
// System.Globalization.DaylightTime
struct DaylightTime_tB08789D033A1BB446A5246183BD7DD6E067BE226;
// System.IAsyncResult
struct IAsyncResult_tDA33C24465239FB383C4C2CDAAC43B9AD3CB7F05;
// System.IntPtr[]
struct IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659;
// System.Reflection.Assembly
struct Assembly_t;
// System.Reflection.MemberInfo
struct MemberInfo_t;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.ResolveEventArgs
struct ResolveEventArgs_tCC17EDD2766BA9905006344D9053EFC23C39CEC2;
// System.Runtime.Remoting.Messaging.Header[]
struct HeaderU5BU5D_t4679A727BD69B75DF7C4B1CF823FF99DBB5572B8;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t778922F6A5AACC38C8F326D3338A91D6D72B11E2;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B;
// System.Type
struct Type_t;
// System.UnhandledExceptionEventArgs
struct UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2;
// System.Version
struct Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15;
// System.Void
struct Void_tDB81A15FA2AB53E2401A76B745D215397B29F783;




#ifndef U3CMODULEU3E_T3D66A8F35F2157DE9E925FB938396AEDA1FB0CA9_H
#define U3CMODULEU3E_T3D66A8F35F2157DE9E925FB938396AEDA1FB0CA9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t3D66A8F35F2157DE9E925FB938396AEDA1FB0CA9 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T3D66A8F35F2157DE9E925FB938396AEDA1FB0CA9_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef LOCALE_TB294B91FA78F6E22E1CCE2B05E5FC1AC28325202_H
#define LOCALE_TB294B91FA78F6E22E1CCE2B05E5FC1AC28325202_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Locale
struct  Locale_tB294B91FA78F6E22E1CCE2B05E5FC1AC28325202  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCALE_TB294B91FA78F6E22E1CCE2B05E5FC1AC28325202_H
#ifndef ATTRIBUTE_T60F25EB48D5935E4C6C2BAF7F90F57A43528E469_H
#define ATTRIBUTE_T60F25EB48D5935E4C6C2BAF7F90F57A43528E469_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Attribute
struct  Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTE_T60F25EB48D5935E4C6C2BAF7F90F57A43528E469_H
#ifndef HYBRIDDICTIONARY_T5AD529BFF21493C38235716C9AD62F1F7623C747_H
#define HYBRIDDICTIONARY_T5AD529BFF21493C38235716C9AD62F1F7623C747_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.HybridDictionary
struct  HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747  : public RuntimeObject
{
public:
	// System.Boolean System.Collections.Specialized.HybridDictionary::caseInsensitive
	bool ___caseInsensitive_0;
	// System.Collections.Hashtable System.Collections.Specialized.HybridDictionary::hashtable
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___hashtable_1;
	// System.Collections.Specialized.ListDictionary System.Collections.Specialized.HybridDictionary::list
	ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA * ___list_2;

public:
	inline static int32_t get_offset_of_caseInsensitive_0() { return static_cast<int32_t>(offsetof(HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747, ___caseInsensitive_0)); }
	inline bool get_caseInsensitive_0() const { return ___caseInsensitive_0; }
	inline bool* get_address_of_caseInsensitive_0() { return &___caseInsensitive_0; }
	inline void set_caseInsensitive_0(bool value)
	{
		___caseInsensitive_0 = value;
	}

	inline static int32_t get_offset_of_hashtable_1() { return static_cast<int32_t>(offsetof(HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747, ___hashtable_1)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_hashtable_1() const { return ___hashtable_1; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_hashtable_1() { return &___hashtable_1; }
	inline void set_hashtable_1(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___hashtable_1 = value;
		Il2CppCodeGenWriteBarrier((&___hashtable_1), value);
	}

	inline static int32_t get_offset_of_list_2() { return static_cast<int32_t>(offsetof(HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747, ___list_2)); }
	inline ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA * get_list_2() const { return ___list_2; }
	inline ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA ** get_address_of_list_2() { return &___list_2; }
	inline void set_list_2(ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA * value)
	{
		___list_2 = value;
		Il2CppCodeGenWriteBarrier((&___list_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HYBRIDDICTIONARY_T5AD529BFF21493C38235716C9AD62F1F7623C747_H
#ifndef LISTDICTIONARY_TD949561FF8FD1EBEB444214919203DD41A76ECCA_H
#define LISTDICTIONARY_TD949561FF8FD1EBEB444214919203DD41A76ECCA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.ListDictionary
struct  ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA  : public RuntimeObject
{
public:
	// System.Int32 System.Collections.Specialized.ListDictionary::count
	int32_t ___count_0;
	// System.Int32 System.Collections.Specialized.ListDictionary::version
	int32_t ___version_1;
	// System.Collections.Specialized.ListDictionary_DictionaryNode System.Collections.Specialized.ListDictionary::head
	DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * ___head_2;
	// System.Collections.IComparer System.Collections.Specialized.ListDictionary::comparer
	RuntimeObject* ___comparer_3;

public:
	inline static int32_t get_offset_of_count_0() { return static_cast<int32_t>(offsetof(ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA, ___count_0)); }
	inline int32_t get_count_0() const { return ___count_0; }
	inline int32_t* get_address_of_count_0() { return &___count_0; }
	inline void set_count_0(int32_t value)
	{
		___count_0 = value;
	}

	inline static int32_t get_offset_of_version_1() { return static_cast<int32_t>(offsetof(ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA, ___version_1)); }
	inline int32_t get_version_1() const { return ___version_1; }
	inline int32_t* get_address_of_version_1() { return &___version_1; }
	inline void set_version_1(int32_t value)
	{
		___version_1 = value;
	}

	inline static int32_t get_offset_of_head_2() { return static_cast<int32_t>(offsetof(ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA, ___head_2)); }
	inline DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * get_head_2() const { return ___head_2; }
	inline DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 ** get_address_of_head_2() { return &___head_2; }
	inline void set_head_2(DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * value)
	{
		___head_2 = value;
		Il2CppCodeGenWriteBarrier((&___head_2), value);
	}

	inline static int32_t get_offset_of_comparer_3() { return static_cast<int32_t>(offsetof(ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA, ___comparer_3)); }
	inline RuntimeObject* get_comparer_3() const { return ___comparer_3; }
	inline RuntimeObject** get_address_of_comparer_3() { return &___comparer_3; }
	inline void set_comparer_3(RuntimeObject* value)
	{
		___comparer_3 = value;
		Il2CppCodeGenWriteBarrier((&___comparer_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LISTDICTIONARY_TD949561FF8FD1EBEB444214919203DD41A76ECCA_H
#ifndef DICTIONARYNODE_TE865C15924F25A7B21066D345799357693CFE973_H
#define DICTIONARYNODE_TE865C15924F25A7B21066D345799357693CFE973_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.ListDictionary_DictionaryNode
struct  DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973  : public RuntimeObject
{
public:
	// System.Object System.Collections.Specialized.ListDictionary_DictionaryNode::key
	RuntimeObject * ___key_0;
	// System.Object System.Collections.Specialized.ListDictionary_DictionaryNode::value
	RuntimeObject * ___value_1;
	// System.Collections.Specialized.ListDictionary_DictionaryNode System.Collections.Specialized.ListDictionary_DictionaryNode::next
	DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * ___next_2;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}

	inline static int32_t get_offset_of_next_2() { return static_cast<int32_t>(offsetof(DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973, ___next_2)); }
	inline DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * get_next_2() const { return ___next_2; }
	inline DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 ** get_address_of_next_2() { return &___next_2; }
	inline void set_next_2(DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * value)
	{
		___next_2 = value;
		Il2CppCodeGenWriteBarrier((&___next_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARYNODE_TE865C15924F25A7B21066D345799357693CFE973_H
#ifndef DICTIONARYNODEENUMERATOR_TF7AA3F261E0E04587E624470DCC081B4CAB4A601_H
#define DICTIONARYNODEENUMERATOR_TF7AA3F261E0E04587E624470DCC081B4CAB4A601_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.ListDictionary_DictionaryNodeEnumerator
struct  DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601  : public RuntimeObject
{
public:
	// System.Collections.Specialized.ListDictionary System.Collections.Specialized.ListDictionary_DictionaryNodeEnumerator::dict
	ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA * ___dict_0;
	// System.Boolean System.Collections.Specialized.ListDictionary_DictionaryNodeEnumerator::isAtStart
	bool ___isAtStart_1;
	// System.Collections.Specialized.ListDictionary_DictionaryNode System.Collections.Specialized.ListDictionary_DictionaryNodeEnumerator::current
	DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * ___current_2;
	// System.Int32 System.Collections.Specialized.ListDictionary_DictionaryNodeEnumerator::version
	int32_t ___version_3;

public:
	inline static int32_t get_offset_of_dict_0() { return static_cast<int32_t>(offsetof(DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601, ___dict_0)); }
	inline ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA * get_dict_0() const { return ___dict_0; }
	inline ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA ** get_address_of_dict_0() { return &___dict_0; }
	inline void set_dict_0(ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA * value)
	{
		___dict_0 = value;
		Il2CppCodeGenWriteBarrier((&___dict_0), value);
	}

	inline static int32_t get_offset_of_isAtStart_1() { return static_cast<int32_t>(offsetof(DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601, ___isAtStart_1)); }
	inline bool get_isAtStart_1() const { return ___isAtStart_1; }
	inline bool* get_address_of_isAtStart_1() { return &___isAtStart_1; }
	inline void set_isAtStart_1(bool value)
	{
		___isAtStart_1 = value;
	}

	inline static int32_t get_offset_of_current_2() { return static_cast<int32_t>(offsetof(DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601, ___current_2)); }
	inline DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * get_current_2() const { return ___current_2; }
	inline DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 ** get_address_of_current_2() { return &___current_2; }
	inline void set_current_2(DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973 * value)
	{
		___current_2 = value;
		Il2CppCodeGenWriteBarrier((&___current_2), value);
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARYNODEENUMERATOR_TF7AA3F261E0E04587E624470DCC081B4CAB4A601_H
#ifndef NAMEOBJECTCOLLECTIONBASE_TC2EE4FB130214FAE7365D519959A2A34DE56E070_H
#define NAMEOBJECTCOLLECTIONBASE_TC2EE4FB130214FAE7365D519959A2A34DE56E070_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.NameObjectCollectionBase
struct  NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070  : public RuntimeObject
{
public:
	// System.Collections.Hashtable System.Collections.Specialized.NameObjectCollectionBase::m_ItemsContainer
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___m_ItemsContainer_0;
	// System.Collections.Specialized.NameObjectCollectionBase__Item System.Collections.Specialized.NameObjectCollectionBase::m_NullKeyItem
	_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7 * ___m_NullKeyItem_1;
	// System.Collections.ArrayList System.Collections.Specialized.NameObjectCollectionBase::m_ItemsArray
	ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * ___m_ItemsArray_2;
	// System.Collections.IHashCodeProvider System.Collections.Specialized.NameObjectCollectionBase::m_hashprovider
	RuntimeObject* ___m_hashprovider_3;
	// System.Collections.IComparer System.Collections.Specialized.NameObjectCollectionBase::m_comparer
	RuntimeObject* ___m_comparer_4;
	// System.Int32 System.Collections.Specialized.NameObjectCollectionBase::m_defCapacity
	int32_t ___m_defCapacity_5;
	// System.Boolean System.Collections.Specialized.NameObjectCollectionBase::m_readonly
	bool ___m_readonly_6;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Specialized.NameObjectCollectionBase::infoCopy
	SerializationInfo_t778922F6A5AACC38C8F326D3338A91D6D72B11E2 * ___infoCopy_7;
	// System.Collections.Specialized.NameObjectCollectionBase_KeysCollection System.Collections.Specialized.NameObjectCollectionBase::keyscoll
	KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB * ___keyscoll_8;
	// System.Collections.IEqualityComparer System.Collections.Specialized.NameObjectCollectionBase::equality_comparer
	RuntimeObject* ___equality_comparer_9;

public:
	inline static int32_t get_offset_of_m_ItemsContainer_0() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_ItemsContainer_0)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_m_ItemsContainer_0() const { return ___m_ItemsContainer_0; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_m_ItemsContainer_0() { return &___m_ItemsContainer_0; }
	inline void set_m_ItemsContainer_0(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___m_ItemsContainer_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_ItemsContainer_0), value);
	}

	inline static int32_t get_offset_of_m_NullKeyItem_1() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_NullKeyItem_1)); }
	inline _Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7 * get_m_NullKeyItem_1() const { return ___m_NullKeyItem_1; }
	inline _Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7 ** get_address_of_m_NullKeyItem_1() { return &___m_NullKeyItem_1; }
	inline void set_m_NullKeyItem_1(_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7 * value)
	{
		___m_NullKeyItem_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_NullKeyItem_1), value);
	}

	inline static int32_t get_offset_of_m_ItemsArray_2() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_ItemsArray_2)); }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * get_m_ItemsArray_2() const { return ___m_ItemsArray_2; }
	inline ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F ** get_address_of_m_ItemsArray_2() { return &___m_ItemsArray_2; }
	inline void set_m_ItemsArray_2(ArrayList_t438A4032A4FBAF49F565FAD10C546E26CFBD847F * value)
	{
		___m_ItemsArray_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_ItemsArray_2), value);
	}

	inline static int32_t get_offset_of_m_hashprovider_3() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_hashprovider_3)); }
	inline RuntimeObject* get_m_hashprovider_3() const { return ___m_hashprovider_3; }
	inline RuntimeObject** get_address_of_m_hashprovider_3() { return &___m_hashprovider_3; }
	inline void set_m_hashprovider_3(RuntimeObject* value)
	{
		___m_hashprovider_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_hashprovider_3), value);
	}

	inline static int32_t get_offset_of_m_comparer_4() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_comparer_4)); }
	inline RuntimeObject* get_m_comparer_4() const { return ___m_comparer_4; }
	inline RuntimeObject** get_address_of_m_comparer_4() { return &___m_comparer_4; }
	inline void set_m_comparer_4(RuntimeObject* value)
	{
		___m_comparer_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_comparer_4), value);
	}

	inline static int32_t get_offset_of_m_defCapacity_5() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_defCapacity_5)); }
	inline int32_t get_m_defCapacity_5() const { return ___m_defCapacity_5; }
	inline int32_t* get_address_of_m_defCapacity_5() { return &___m_defCapacity_5; }
	inline void set_m_defCapacity_5(int32_t value)
	{
		___m_defCapacity_5 = value;
	}

	inline static int32_t get_offset_of_m_readonly_6() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___m_readonly_6)); }
	inline bool get_m_readonly_6() const { return ___m_readonly_6; }
	inline bool* get_address_of_m_readonly_6() { return &___m_readonly_6; }
	inline void set_m_readonly_6(bool value)
	{
		___m_readonly_6 = value;
	}

	inline static int32_t get_offset_of_infoCopy_7() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___infoCopy_7)); }
	inline SerializationInfo_t778922F6A5AACC38C8F326D3338A91D6D72B11E2 * get_infoCopy_7() const { return ___infoCopy_7; }
	inline SerializationInfo_t778922F6A5AACC38C8F326D3338A91D6D72B11E2 ** get_address_of_infoCopy_7() { return &___infoCopy_7; }
	inline void set_infoCopy_7(SerializationInfo_t778922F6A5AACC38C8F326D3338A91D6D72B11E2 * value)
	{
		___infoCopy_7 = value;
		Il2CppCodeGenWriteBarrier((&___infoCopy_7), value);
	}

	inline static int32_t get_offset_of_keyscoll_8() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___keyscoll_8)); }
	inline KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB * get_keyscoll_8() const { return ___keyscoll_8; }
	inline KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB ** get_address_of_keyscoll_8() { return &___keyscoll_8; }
	inline void set_keyscoll_8(KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB * value)
	{
		___keyscoll_8 = value;
		Il2CppCodeGenWriteBarrier((&___keyscoll_8), value);
	}

	inline static int32_t get_offset_of_equality_comparer_9() { return static_cast<int32_t>(offsetof(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070, ___equality_comparer_9)); }
	inline RuntimeObject* get_equality_comparer_9() const { return ___equality_comparer_9; }
	inline RuntimeObject** get_address_of_equality_comparer_9() { return &___equality_comparer_9; }
	inline void set_equality_comparer_9(RuntimeObject* value)
	{
		___equality_comparer_9 = value;
		Il2CppCodeGenWriteBarrier((&___equality_comparer_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NAMEOBJECTCOLLECTIONBASE_TC2EE4FB130214FAE7365D519959A2A34DE56E070_H
#ifndef KEYSCOLLECTION_T3A1987CE62992069C60E21F2F157579EFBB7FDDB_H
#define KEYSCOLLECTION_T3A1987CE62992069C60E21F2F157579EFBB7FDDB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.NameObjectCollectionBase_KeysCollection
struct  KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB  : public RuntimeObject
{
public:
	// System.Collections.Specialized.NameObjectCollectionBase System.Collections.Specialized.NameObjectCollectionBase_KeysCollection::m_collection
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 * ___m_collection_0;

public:
	inline static int32_t get_offset_of_m_collection_0() { return static_cast<int32_t>(offsetof(KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB, ___m_collection_0)); }
	inline NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 * get_m_collection_0() const { return ___m_collection_0; }
	inline NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 ** get_address_of_m_collection_0() { return &___m_collection_0; }
	inline void set_m_collection_0(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 * value)
	{
		___m_collection_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_collection_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYSCOLLECTION_T3A1987CE62992069C60E21F2F157579EFBB7FDDB_H
#ifndef _ITEM_TFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7_H
#define _ITEM_TFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.NameObjectCollectionBase__Item
struct  _Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7  : public RuntimeObject
{
public:
	// System.String System.Collections.Specialized.NameObjectCollectionBase__Item::key
	String_t* ___key_0;
	// System.Object System.Collections.Specialized.NameObjectCollectionBase__Item::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7, ___key_0)); }
	inline String_t* get_key_0() const { return ___key_0; }
	inline String_t** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(String_t* value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // _ITEM_TFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7_H
#ifndef _KEYSENUMERATOR_T831ED8844B7FCA44E39D0121A1EC06B3AE76941E_H
#define _KEYSENUMERATOR_T831ED8844B7FCA44E39D0121A1EC06B3AE76941E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.NameObjectCollectionBase__KeysEnumerator
struct  _KeysEnumerator_t831ED8844B7FCA44E39D0121A1EC06B3AE76941E  : public RuntimeObject
{
public:
	// System.Collections.Specialized.NameObjectCollectionBase System.Collections.Specialized.NameObjectCollectionBase__KeysEnumerator::m_collection
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 * ___m_collection_0;
	// System.Int32 System.Collections.Specialized.NameObjectCollectionBase__KeysEnumerator::m_position
	int32_t ___m_position_1;

public:
	inline static int32_t get_offset_of_m_collection_0() { return static_cast<int32_t>(offsetof(_KeysEnumerator_t831ED8844B7FCA44E39D0121A1EC06B3AE76941E, ___m_collection_0)); }
	inline NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 * get_m_collection_0() const { return ___m_collection_0; }
	inline NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 ** get_address_of_m_collection_0() { return &___m_collection_0; }
	inline void set_m_collection_0(NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070 * value)
	{
		___m_collection_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_collection_0), value);
	}

	inline static int32_t get_offset_of_m_position_1() { return static_cast<int32_t>(offsetof(_KeysEnumerator_t831ED8844B7FCA44E39D0121A1EC06B3AE76941E, ___m_position_1)); }
	inline int32_t get_m_position_1() const { return ___m_position_1; }
	inline int32_t* get_address_of_m_position_1() { return &___m_position_1; }
	inline void set_m_position_1(int32_t value)
	{
		___m_position_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // _KEYSENUMERATOR_T831ED8844B7FCA44E39D0121A1EC06B3AE76941E_H
#ifndef TYPECONVERTER_T5801C9F7100E1D849000ED0914E01E4CB2541B71_H
#define TYPECONVERTER_T5801C9F7100E1D849000ED0914E01E4CB2541B71_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.TypeConverter
struct  TypeConverter_t5801C9F7100E1D849000ED0914E01E4CB2541B71  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPECONVERTER_T5801C9F7100E1D849000ED0914E01E4CB2541B71_H
#ifndef EVENTARGS_TA4C15C1D2AB4B139169B1942C1477933E00DCA17_H
#define EVENTARGS_TA4C15C1D2AB4B139169B1942C1477933E00DCA17_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.EventArgs
struct  EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17  : public RuntimeObject
{
public:

public:
};

struct EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17_StaticFields
{
public:
	// System.EventArgs System.EventArgs::Empty
	EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17 * ___Empty_0;

public:
	inline static int32_t get_offset_of_Empty_0() { return static_cast<int32_t>(offsetof(EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17_StaticFields, ___Empty_0)); }
	inline EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17 * get_Empty_0() const { return ___Empty_0; }
	inline EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17 ** get_address_of_Empty_0() { return &___Empty_0; }
	inline void set_Empty_0(EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17 * value)
	{
		___Empty_0 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EVENTARGS_TA4C15C1D2AB4B139169B1942C1477933E00DCA17_H
#ifndef EXCEPTION_T_H
#define EXCEPTION_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.IntPtr[] System.Exception::trace_ips
	IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659* ___trace_ips_0;
	// System.Exception System.Exception::inner_exception
	Exception_t * ___inner_exception_1;
	// System.String System.Exception::message
	String_t* ___message_2;
	// System.String System.Exception::help_link
	String_t* ___help_link_3;
	// System.String System.Exception::class_name
	String_t* ___class_name_4;
	// System.String System.Exception::stack_trace
	String_t* ___stack_trace_5;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_6;
	// System.Int32 System.Exception::remote_stack_index
	int32_t ___remote_stack_index_7;
	// System.Int32 System.Exception::hresult
	int32_t ___hresult_8;
	// System.String System.Exception::source
	String_t* ___source_9;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_10;

public:
	inline static int32_t get_offset_of_trace_ips_0() { return static_cast<int32_t>(offsetof(Exception_t, ___trace_ips_0)); }
	inline IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659* get_trace_ips_0() const { return ___trace_ips_0; }
	inline IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659** get_address_of_trace_ips_0() { return &___trace_ips_0; }
	inline void set_trace_ips_0(IntPtrU5BU5D_tB866BA24C91559CF299618E230043451CC7CF659* value)
	{
		___trace_ips_0 = value;
		Il2CppCodeGenWriteBarrier((&___trace_ips_0), value);
	}

	inline static int32_t get_offset_of_inner_exception_1() { return static_cast<int32_t>(offsetof(Exception_t, ___inner_exception_1)); }
	inline Exception_t * get_inner_exception_1() const { return ___inner_exception_1; }
	inline Exception_t ** get_address_of_inner_exception_1() { return &___inner_exception_1; }
	inline void set_inner_exception_1(Exception_t * value)
	{
		___inner_exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___inner_exception_1), value);
	}

	inline static int32_t get_offset_of_message_2() { return static_cast<int32_t>(offsetof(Exception_t, ___message_2)); }
	inline String_t* get_message_2() const { return ___message_2; }
	inline String_t** get_address_of_message_2() { return &___message_2; }
	inline void set_message_2(String_t* value)
	{
		___message_2 = value;
		Il2CppCodeGenWriteBarrier((&___message_2), value);
	}

	inline static int32_t get_offset_of_help_link_3() { return static_cast<int32_t>(offsetof(Exception_t, ___help_link_3)); }
	inline String_t* get_help_link_3() const { return ___help_link_3; }
	inline String_t** get_address_of_help_link_3() { return &___help_link_3; }
	inline void set_help_link_3(String_t* value)
	{
		___help_link_3 = value;
		Il2CppCodeGenWriteBarrier((&___help_link_3), value);
	}

	inline static int32_t get_offset_of_class_name_4() { return static_cast<int32_t>(offsetof(Exception_t, ___class_name_4)); }
	inline String_t* get_class_name_4() const { return ___class_name_4; }
	inline String_t** get_address_of_class_name_4() { return &___class_name_4; }
	inline void set_class_name_4(String_t* value)
	{
		___class_name_4 = value;
		Il2CppCodeGenWriteBarrier((&___class_name_4), value);
	}

	inline static int32_t get_offset_of_stack_trace_5() { return static_cast<int32_t>(offsetof(Exception_t, ___stack_trace_5)); }
	inline String_t* get_stack_trace_5() const { return ___stack_trace_5; }
	inline String_t** get_address_of_stack_trace_5() { return &___stack_trace_5; }
	inline void set_stack_trace_5(String_t* value)
	{
		___stack_trace_5 = value;
		Il2CppCodeGenWriteBarrier((&___stack_trace_5), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_6() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_6)); }
	inline String_t* get__remoteStackTraceString_6() const { return ____remoteStackTraceString_6; }
	inline String_t** get_address_of__remoteStackTraceString_6() { return &____remoteStackTraceString_6; }
	inline void set__remoteStackTraceString_6(String_t* value)
	{
		____remoteStackTraceString_6 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_6), value);
	}

	inline static int32_t get_offset_of_remote_stack_index_7() { return static_cast<int32_t>(offsetof(Exception_t, ___remote_stack_index_7)); }
	inline int32_t get_remote_stack_index_7() const { return ___remote_stack_index_7; }
	inline int32_t* get_address_of_remote_stack_index_7() { return &___remote_stack_index_7; }
	inline void set_remote_stack_index_7(int32_t value)
	{
		___remote_stack_index_7 = value;
	}

	inline static int32_t get_offset_of_hresult_8() { return static_cast<int32_t>(offsetof(Exception_t, ___hresult_8)); }
	inline int32_t get_hresult_8() const { return ___hresult_8; }
	inline int32_t* get_address_of_hresult_8() { return &___hresult_8; }
	inline void set_hresult_8(int32_t value)
	{
		___hresult_8 = value;
	}

	inline static int32_t get_offset_of_source_9() { return static_cast<int32_t>(offsetof(Exception_t, ___source_9)); }
	inline String_t* get_source_9() const { return ___source_9; }
	inline String_t** get_address_of_source_9() { return &___source_9; }
	inline void set_source_9(String_t* value)
	{
		___source_9 = value;
		Il2CppCodeGenWriteBarrier((&___source_9), value);
	}

	inline static int32_t get_offset_of__data_10() { return static_cast<int32_t>(offsetof(Exception_t, ____data_10)); }
	inline RuntimeObject* get__data_10() const { return ____data_10; }
	inline RuntimeObject** get_address_of__data_10() { return &____data_10; }
	inline void set__data_10(RuntimeObject* value)
	{
		____data_10 = value;
		Il2CppCodeGenWriteBarrier((&____data_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTION_T_H
#ifndef LINGEROPTION_T62B714AFE2251DFCF0B64F164C08A8A533EE1267_H
#define LINGEROPTION_T62B714AFE2251DFCF0B64F164C08A8A533EE1267_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.Sockets.LingerOption
struct  LingerOption_t62B714AFE2251DFCF0B64F164C08A8A533EE1267  : public RuntimeObject
{
public:
	// System.Boolean System.Net.Sockets.LingerOption::enabled
	bool ___enabled_0;
	// System.Int32 System.Net.Sockets.LingerOption::seconds
	int32_t ___seconds_1;

public:
	inline static int32_t get_offset_of_enabled_0() { return static_cast<int32_t>(offsetof(LingerOption_t62B714AFE2251DFCF0B64F164C08A8A533EE1267, ___enabled_0)); }
	inline bool get_enabled_0() const { return ___enabled_0; }
	inline bool* get_address_of_enabled_0() { return &___enabled_0; }
	inline void set_enabled_0(bool value)
	{
		___enabled_0 = value;
	}

	inline static int32_t get_offset_of_seconds_1() { return static_cast<int32_t>(offsetof(LingerOption_t62B714AFE2251DFCF0B64F164C08A8A533EE1267, ___seconds_1)); }
	inline int32_t get_seconds_1() const { return ___seconds_1; }
	inline int32_t* get_address_of_seconds_1() { return &___seconds_1; }
	inline void set_seconds_1(int32_t value)
	{
		___seconds_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LINGEROPTION_T62B714AFE2251DFCF0B64F164C08A8A533EE1267_H
#ifndef STRINGCOMPARER_T2BD4D768665C1290582CAD7439D03599B59ACCCF_H
#define STRINGCOMPARER_T2BD4D768665C1290582CAD7439D03599B59ACCCF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.StringComparer
struct  StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF  : public RuntimeObject
{
public:

public:
};

struct StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields
{
public:
	// System.StringComparer System.StringComparer::invariantCultureIgnoreCase
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * ___invariantCultureIgnoreCase_0;
	// System.StringComparer System.StringComparer::invariantCulture
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * ___invariantCulture_1;
	// System.StringComparer System.StringComparer::ordinalIgnoreCase
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * ___ordinalIgnoreCase_2;
	// System.StringComparer System.StringComparer::ordinal
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * ___ordinal_3;

public:
	inline static int32_t get_offset_of_invariantCultureIgnoreCase_0() { return static_cast<int32_t>(offsetof(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields, ___invariantCultureIgnoreCase_0)); }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * get_invariantCultureIgnoreCase_0() const { return ___invariantCultureIgnoreCase_0; }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF ** get_address_of_invariantCultureIgnoreCase_0() { return &___invariantCultureIgnoreCase_0; }
	inline void set_invariantCultureIgnoreCase_0(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * value)
	{
		___invariantCultureIgnoreCase_0 = value;
		Il2CppCodeGenWriteBarrier((&___invariantCultureIgnoreCase_0), value);
	}

	inline static int32_t get_offset_of_invariantCulture_1() { return static_cast<int32_t>(offsetof(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields, ___invariantCulture_1)); }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * get_invariantCulture_1() const { return ___invariantCulture_1; }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF ** get_address_of_invariantCulture_1() { return &___invariantCulture_1; }
	inline void set_invariantCulture_1(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * value)
	{
		___invariantCulture_1 = value;
		Il2CppCodeGenWriteBarrier((&___invariantCulture_1), value);
	}

	inline static int32_t get_offset_of_ordinalIgnoreCase_2() { return static_cast<int32_t>(offsetof(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields, ___ordinalIgnoreCase_2)); }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * get_ordinalIgnoreCase_2() const { return ___ordinalIgnoreCase_2; }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF ** get_address_of_ordinalIgnoreCase_2() { return &___ordinalIgnoreCase_2; }
	inline void set_ordinalIgnoreCase_2(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * value)
	{
		___ordinalIgnoreCase_2 = value;
		Il2CppCodeGenWriteBarrier((&___ordinalIgnoreCase_2), value);
	}

	inline static int32_t get_offset_of_ordinal_3() { return static_cast<int32_t>(offsetof(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields, ___ordinal_3)); }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * get_ordinal_3() const { return ___ordinal_3; }
	inline StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF ** get_address_of_ordinal_3() { return &___ordinal_3; }
	inline void set_ordinal_3(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF * value)
	{
		___ordinal_3 = value;
		Il2CppCodeGenWriteBarrier((&___ordinal_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGCOMPARER_T2BD4D768665C1290582CAD7439D03599B59ACCCF_H
#ifndef TIMEZONE_TFC833FAA087479460CA3A3EC12FD9EE729BC32EB_H
#define TIMEZONE_TFC833FAA087479460CA3A3EC12FD9EE729BC32EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TimeZone
struct  TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB  : public RuntimeObject
{
public:

public:
};

struct TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields
{
public:
	// System.TimeZone System.TimeZone::currentTimeZone
	TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB * ___currentTimeZone_0;
	// System.Object System.TimeZone::tz_lock
	RuntimeObject * ___tz_lock_1;
	// System.Int64 System.TimeZone::timezone_check
	int64_t ___timezone_check_2;

public:
	inline static int32_t get_offset_of_currentTimeZone_0() { return static_cast<int32_t>(offsetof(TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields, ___currentTimeZone_0)); }
	inline TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB * get_currentTimeZone_0() const { return ___currentTimeZone_0; }
	inline TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB ** get_address_of_currentTimeZone_0() { return &___currentTimeZone_0; }
	inline void set_currentTimeZone_0(TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB * value)
	{
		___currentTimeZone_0 = value;
		Il2CppCodeGenWriteBarrier((&___currentTimeZone_0), value);
	}

	inline static int32_t get_offset_of_tz_lock_1() { return static_cast<int32_t>(offsetof(TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields, ___tz_lock_1)); }
	inline RuntimeObject * get_tz_lock_1() const { return ___tz_lock_1; }
	inline RuntimeObject ** get_address_of_tz_lock_1() { return &___tz_lock_1; }
	inline void set_tz_lock_1(RuntimeObject * value)
	{
		___tz_lock_1 = value;
		Il2CppCodeGenWriteBarrier((&___tz_lock_1), value);
	}

	inline static int32_t get_offset_of_timezone_check_2() { return static_cast<int32_t>(offsetof(TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields, ___timezone_check_2)); }
	inline int64_t get_timezone_check_2() const { return ___timezone_check_2; }
	inline int64_t* get_address_of_timezone_check_2() { return &___timezone_check_2; }
	inline void set_timezone_check_2(int64_t value)
	{
		___timezone_check_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TIMEZONE_TFC833FAA087479460CA3A3EC12FD9EE729BC32EB_H
#ifndef VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#define VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_marshaled_com
{
};
#endif // VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#ifndef VERSION_TD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15_H
#define VERSION_TD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Version
struct  Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15  : public RuntimeObject
{
public:
	// System.Int32 System.Version::_Major
	int32_t ____Major_1;
	// System.Int32 System.Version::_Minor
	int32_t ____Minor_2;
	// System.Int32 System.Version::_Build
	int32_t ____Build_3;
	// System.Int32 System.Version::_Revision
	int32_t ____Revision_4;

public:
	inline static int32_t get_offset_of__Major_1() { return static_cast<int32_t>(offsetof(Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15, ____Major_1)); }
	inline int32_t get__Major_1() const { return ____Major_1; }
	inline int32_t* get_address_of__Major_1() { return &____Major_1; }
	inline void set__Major_1(int32_t value)
	{
		____Major_1 = value;
	}

	inline static int32_t get_offset_of__Minor_2() { return static_cast<int32_t>(offsetof(Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15, ____Minor_2)); }
	inline int32_t get__Minor_2() const { return ____Minor_2; }
	inline int32_t* get_address_of__Minor_2() { return &____Minor_2; }
	inline void set__Minor_2(int32_t value)
	{
		____Minor_2 = value;
	}

	inline static int32_t get_offset_of__Build_3() { return static_cast<int32_t>(offsetof(Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15, ____Build_3)); }
	inline int32_t get__Build_3() const { return ____Build_3; }
	inline int32_t* get_address_of__Build_3() { return &____Build_3; }
	inline void set__Build_3(int32_t value)
	{
		____Build_3 = value;
	}

	inline static int32_t get_offset_of__Revision_4() { return static_cast<int32_t>(offsetof(Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15, ____Revision_4)); }
	inline int32_t get__Revision_4() const { return ____Revision_4; }
	inline int32_t* get_address_of__Revision_4() { return &____Revision_4; }
	inline void set__Revision_4(int32_t value)
	{
		____Revision_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERSION_TD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15_H
#ifndef IL2CPPCOMOBJECT_H
#define IL2CPPCOMOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.__Il2CppComObject

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // IL2CPPCOMOBJECT_H
#ifndef U24ARRAYTYPEU241024_T2C0067E321F7E11E00C35CBAD93710B937D40964_H
#define U24ARRAYTYPEU241024_T2C0067E321F7E11E00C35CBAD93710B937D40964_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU241024
struct  U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964__padding[1024];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU241024_T2C0067E321F7E11E00C35CBAD93710B937D40964_H
#ifndef U24ARRAYTYPEU2412_T1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1_H
#define U24ARRAYTYPEU2412_T1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2412
struct  U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1__padding[12];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2412_T1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1_H
#ifndef U24ARRAYTYPEU24120_T923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA_H
#define U24ARRAYTYPEU24120_T923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU24120
struct  U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA__padding[120];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU24120_T923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA_H
#ifndef U24ARRAYTYPEU24124_TDF0350FDC99772DAA8899A60F2353B8347DA3F1F_H
#define U24ARRAYTYPEU24124_TDF0350FDC99772DAA8899A60F2353B8347DA3F1F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU24124
struct  U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F__padding[124];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU24124_TDF0350FDC99772DAA8899A60F2353B8347DA3F1F_H
#ifndef U24ARRAYTYPEU24128_T8122526FCB3BDC373AE21FD499BBA063D029117F_H
#define U24ARRAYTYPEU24128_T8122526FCB3BDC373AE21FD499BBA063D029117F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU24128
struct  U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F__padding[128];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU24128_T8122526FCB3BDC373AE21FD499BBA063D029117F_H
#ifndef U24ARRAYTYPEU24136_T880E5ED037F37EC6E537FC3DAD6261C39866B7B2_H
#define U24ARRAYTYPEU24136_T880E5ED037F37EC6E537FC3DAD6261C39866B7B2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU24136
struct  U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2__padding[136];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU24136_T880E5ED037F37EC6E537FC3DAD6261C39866B7B2_H
#ifndef U24ARRAYTYPEU2416_T1C56629E747218F497E07A57F1222259FB2A71A6_H
#define U24ARRAYTYPEU2416_T1C56629E747218F497E07A57F1222259FB2A71A6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2416
struct  U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6__padding[16];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2416_T1C56629E747218F497E07A57F1222259FB2A71A6_H
#ifndef U24ARRAYTYPEU2420_TF8EBD299D93DB13D787345587B4111D2AB3C6F84_H
#define U24ARRAYTYPEU2420_TF8EBD299D93DB13D787345587B4111D2AB3C6F84_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2420
struct  U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84__padding[20];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2420_TF8EBD299D93DB13D787345587B4111D2AB3C6F84_H
#ifndef U24ARRAYTYPEU242048_T756B027702A13511CEB867FF431C06E4739A97D8_H
#define U24ARRAYTYPEU242048_T756B027702A13511CEB867FF431C06E4739A97D8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU242048
struct  U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8__padding[2048];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU242048_T756B027702A13511CEB867FF431C06E4739A97D8_H
#ifndef U24ARRAYTYPEU2424_TA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796_H
#define U24ARRAYTYPEU2424_TA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2424
struct  U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796__padding[24];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2424_TA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796_H
#ifndef U24ARRAYTYPEU24256_T6DE186CA371FDB3704030BA2B0B08B33014FC6AF_H
#define U24ARRAYTYPEU24256_T6DE186CA371FDB3704030BA2B0B08B33014FC6AF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU24256
struct  U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF__padding[256];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU24256_T6DE186CA371FDB3704030BA2B0B08B33014FC6AF_H
#ifndef U24ARRAYTYPEU243132_T5594D874D0815FE7B5383A88C55EFE4DEAB98330_H
#define U24ARRAYTYPEU243132_T5594D874D0815FE7B5383A88C55EFE4DEAB98330_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU243132
struct  U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330__padding[3132];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU243132_T5594D874D0815FE7B5383A88C55EFE4DEAB98330_H
#ifndef U24ARRAYTYPEU2432_T10B942E8F73A7895B7944063CCC7F7C7E7D28B6E_H
#define U24ARRAYTYPEU2432_T10B942E8F73A7895B7944063CCC7F7C7E7D28B6E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2432
struct  U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E__padding[32];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2432_T10B942E8F73A7895B7944063CCC7F7C7E7D28B6E_H
#ifndef U24ARRAYTYPEU2448_TBC8308884E55B8A3BB11364B84C57853C56760E6_H
#define U24ARRAYTYPEU2448_TBC8308884E55B8A3BB11364B84C57853C56760E6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2448
struct  U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6__padding[48];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2448_TBC8308884E55B8A3BB11364B84C57853C56760E6_H
#ifndef U24ARRAYTYPEU2452_T00AE7364DBCF9E6394820DC15A8131CA5F550952_H
#define U24ARRAYTYPEU2452_T00AE7364DBCF9E6394820DC15A8131CA5F550952_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2452
struct  U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952__padding[52];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2452_T00AE7364DBCF9E6394820DC15A8131CA5F550952_H
#ifndef U24ARRAYTYPEU2456_T4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4_H
#define U24ARRAYTYPEU2456_T4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2456
struct  U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4__padding[56];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2456_T4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4_H
#ifndef U24ARRAYTYPEU2464_T8CEBCE84BC90D43EE00405E69D3903D1B1061D3E_H
#define U24ARRAYTYPEU2464_T8CEBCE84BC90D43EE00405E69D3903D1B1061D3E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2464
struct  U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E__padding[64];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2464_T8CEBCE84BC90D43EE00405E69D3903D1B1061D3E_H
#ifndef U24ARRAYTYPEU24640_TD01046A970F55A095E7AD3DB850BE3751511ECDC_H
#define U24ARRAYTYPEU24640_TD01046A970F55A095E7AD3DB850BE3751511ECDC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU24640
struct  U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC__padding[640];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU24640_TD01046A970F55A095E7AD3DB850BE3751511ECDC_H
#ifndef U24ARRAYTYPEU2472_TB19D67EA47643E3F71021C798A6371C372425517_H
#define U24ARRAYTYPEU2472_TB19D67EA47643E3F71021C798A6371C372425517_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2472
struct  U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517__padding[72];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2472_TB19D67EA47643E3F71021C798A6371C372425517_H
#ifndef U24ARRAYTYPEU248_TFA5531B592841F79CB392E5705A7AFDA148DF967_H
#define U24ARRAYTYPEU248_TFA5531B592841F79CB392E5705A7AFDA148DF967_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU248
struct  U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967__padding[8];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU248_TFA5531B592841F79CB392E5705A7AFDA148DF967_H
#ifndef U24ARRAYTYPEU2496_TF8E7F4B88A264A2D404C41040DA74510A55EE2D2_H
#define U24ARRAYTYPEU2496_TF8E7F4B88A264A2D404C41040DA74510A55EE2D2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU2496
struct  U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2__padding[96];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU2496_TF8E7F4B88A264A2D404C41040DA74510A55EE2D2_H
#ifndef BOOLEAN_T92E4792324DA9B716F339A3B965A14965E99A4EF_H
#define BOOLEAN_T92E4792324DA9B716F339A3B965A14965E99A4EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_t92E4792324DA9B716F339A3B965A14965E99A4EF 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Boolean_t92E4792324DA9B716F339A3B965A14965E99A4EF, ___m_value_2)); }
	inline bool get_m_value_2() const { return ___m_value_2; }
	inline bool* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(bool value)
	{
		___m_value_2 = value;
	}
};

struct Boolean_t92E4792324DA9B716F339A3B965A14965E99A4EF_StaticFields
{
public:
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_0;
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_1;

public:
	inline static int32_t get_offset_of_FalseString_0() { return static_cast<int32_t>(offsetof(Boolean_t92E4792324DA9B716F339A3B965A14965E99A4EF_StaticFields, ___FalseString_0)); }
	inline String_t* get_FalseString_0() const { return ___FalseString_0; }
	inline String_t** get_address_of_FalseString_0() { return &___FalseString_0; }
	inline void set_FalseString_0(String_t* value)
	{
		___FalseString_0 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_0), value);
	}

	inline static int32_t get_offset_of_TrueString_1() { return static_cast<int32_t>(offsetof(Boolean_t92E4792324DA9B716F339A3B965A14965E99A4EF_StaticFields, ___TrueString_1)); }
	inline String_t* get_TrueString_1() const { return ___TrueString_1; }
	inline String_t** get_address_of_TrueString_1() { return &___TrueString_1; }
	inline void set_TrueString_1(String_t* value)
	{
		___TrueString_1 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_T92E4792324DA9B716F339A3B965A14965E99A4EF_H
#ifndef NAMEVALUECOLLECTION_TB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF_H
#define NAMEVALUECOLLECTION_TB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.NameValueCollection
struct  NameValueCollection_tB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF  : public NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070
{
public:
	// System.String[] System.Collections.Specialized.NameValueCollection::cachedAllKeys
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___cachedAllKeys_10;
	// System.String[] System.Collections.Specialized.NameValueCollection::cachedAll
	StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* ___cachedAll_11;

public:
	inline static int32_t get_offset_of_cachedAllKeys_10() { return static_cast<int32_t>(offsetof(NameValueCollection_tB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF, ___cachedAllKeys_10)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_cachedAllKeys_10() const { return ___cachedAllKeys_10; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_cachedAllKeys_10() { return &___cachedAllKeys_10; }
	inline void set_cachedAllKeys_10(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___cachedAllKeys_10 = value;
		Il2CppCodeGenWriteBarrier((&___cachedAllKeys_10), value);
	}

	inline static int32_t get_offset_of_cachedAll_11() { return static_cast<int32_t>(offsetof(NameValueCollection_tB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF, ___cachedAll_11)); }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* get_cachedAll_11() const { return ___cachedAll_11; }
	inline StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B** get_address_of_cachedAll_11() { return &___cachedAll_11; }
	inline void set_cachedAll_11(StringU5BU5D_t632E9CB8D244841312F333CBF60404AFA46E0B3B* value)
	{
		___cachedAll_11 = value;
		Il2CppCodeGenWriteBarrier((&___cachedAll_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NAMEVALUECOLLECTION_TB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF_H
#ifndef TYPECONVERTERATTRIBUTE_TC7B95DB483CF95DC3E325F90964995E1939B4E27_H
#define TYPECONVERTERATTRIBUTE_TC7B95DB483CF95DC3E325F90964995E1939B4E27_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.TypeConverterAttribute
struct  TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:
	// System.String System.ComponentModel.TypeConverterAttribute::converter_type
	String_t* ___converter_type_1;

public:
	inline static int32_t get_offset_of_converter_type_1() { return static_cast<int32_t>(offsetof(TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27, ___converter_type_1)); }
	inline String_t* get_converter_type_1() const { return ___converter_type_1; }
	inline String_t** get_address_of_converter_type_1() { return &___converter_type_1; }
	inline void set_converter_type_1(String_t* value)
	{
		___converter_type_1 = value;
		Il2CppCodeGenWriteBarrier((&___converter_type_1), value);
	}
};

struct TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27_StaticFields
{
public:
	// System.ComponentModel.TypeConverterAttribute System.ComponentModel.TypeConverterAttribute::Default
	TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27 * ___Default_0;

public:
	inline static int32_t get_offset_of_Default_0() { return static_cast<int32_t>(offsetof(TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27_StaticFields, ___Default_0)); }
	inline TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27 * get_Default_0() const { return ___Default_0; }
	inline TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27 ** get_address_of_Default_0() { return &___Default_0; }
	inline void set_Default_0(TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27 * value)
	{
		___Default_0 = value;
		Il2CppCodeGenWriteBarrier((&___Default_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPECONVERTERATTRIBUTE_TC7B95DB483CF95DC3E325F90964995E1939B4E27_H
#ifndef CULTUREAWARECOMPARER_T4FE6CD320A5607CB513A721A468899BAB220844F_H
#define CULTUREAWARECOMPARER_T4FE6CD320A5607CB513A721A468899BAB220844F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.CultureAwareComparer
struct  CultureAwareComparer_t4FE6CD320A5607CB513A721A468899BAB220844F  : public StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF
{
public:
	// System.Boolean System.CultureAwareComparer::_ignoreCase
	bool ____ignoreCase_4;
	// System.Globalization.CompareInfo System.CultureAwareComparer::_compareInfo
	CompareInfo_t704FFB923C9EF69DFAE63C1950E5B466A94C0F4B * ____compareInfo_5;

public:
	inline static int32_t get_offset_of__ignoreCase_4() { return static_cast<int32_t>(offsetof(CultureAwareComparer_t4FE6CD320A5607CB513A721A468899BAB220844F, ____ignoreCase_4)); }
	inline bool get__ignoreCase_4() const { return ____ignoreCase_4; }
	inline bool* get_address_of__ignoreCase_4() { return &____ignoreCase_4; }
	inline void set__ignoreCase_4(bool value)
	{
		____ignoreCase_4 = value;
	}

	inline static int32_t get_offset_of__compareInfo_5() { return static_cast<int32_t>(offsetof(CultureAwareComparer_t4FE6CD320A5607CB513A721A468899BAB220844F, ____compareInfo_5)); }
	inline CompareInfo_t704FFB923C9EF69DFAE63C1950E5B466A94C0F4B * get__compareInfo_5() const { return ____compareInfo_5; }
	inline CompareInfo_t704FFB923C9EF69DFAE63C1950E5B466A94C0F4B ** get_address_of__compareInfo_5() { return &____compareInfo_5; }
	inline void set__compareInfo_5(CompareInfo_t704FFB923C9EF69DFAE63C1950E5B466A94C0F4B * value)
	{
		____compareInfo_5 = value;
		Il2CppCodeGenWriteBarrier((&____compareInfo_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CULTUREAWARECOMPARER_T4FE6CD320A5607CB513A721A468899BAB220844F_H
#ifndef ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#define ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF  : public ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C
{
public:

public:
};

struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_marshaled_com
{
};
#endif // ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef MONOTODOATTRIBUTE_T9D89F1E822F284972E35E1E9E94CFA0817EFB2CB_H
#define MONOTODOATTRIBUTE_T9D89F1E822F284972E35E1E9E94CFA0817EFB2CB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MonoTODOAttribute
struct  MonoTODOAttribute_t9D89F1E822F284972E35E1E9E94CFA0817EFB2CB  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:
	// System.String System.MonoTODOAttribute::comment
	String_t* ___comment_0;

public:
	inline static int32_t get_offset_of_comment_0() { return static_cast<int32_t>(offsetof(MonoTODOAttribute_t9D89F1E822F284972E35E1E9E94CFA0817EFB2CB, ___comment_0)); }
	inline String_t* get_comment_0() const { return ___comment_0; }
	inline String_t** get_address_of_comment_0() { return &___comment_0; }
	inline void set_comment_0(String_t* value)
	{
		___comment_0 = value;
		Il2CppCodeGenWriteBarrier((&___comment_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOTODOATTRIBUTE_T9D89F1E822F284972E35E1E9E94CFA0817EFB2CB_H
#ifndef ORDINALCOMPARER_T137CD954871758A587130A2D08F0DFCC98D9623D_H
#define ORDINALCOMPARER_T137CD954871758A587130A2D08F0DFCC98D9623D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.OrdinalComparer
struct  OrdinalComparer_t137CD954871758A587130A2D08F0DFCC98D9623D  : public StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF
{
public:
	// System.Boolean System.OrdinalComparer::_ignoreCase
	bool ____ignoreCase_4;

public:
	inline static int32_t get_offset_of__ignoreCase_4() { return static_cast<int32_t>(offsetof(OrdinalComparer_t137CD954871758A587130A2D08F0DFCC98D9623D, ____ignoreCase_4)); }
	inline bool get__ignoreCase_4() const { return ____ignoreCase_4; }
	inline bool* get_address_of__ignoreCase_4() { return &____ignoreCase_4; }
	inline void set__ignoreCase_4(bool value)
	{
		____ignoreCase_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ORDINALCOMPARER_T137CD954871758A587130A2D08F0DFCC98D9623D_H
#ifndef RESOLVEEVENTARGS_TCC17EDD2766BA9905006344D9053EFC23C39CEC2_H
#define RESOLVEEVENTARGS_TCC17EDD2766BA9905006344D9053EFC23C39CEC2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ResolveEventArgs
struct  ResolveEventArgs_tCC17EDD2766BA9905006344D9053EFC23C39CEC2  : public EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17
{
public:
	// System.String System.ResolveEventArgs::m_Name
	String_t* ___m_Name_1;

public:
	inline static int32_t get_offset_of_m_Name_1() { return static_cast<int32_t>(offsetof(ResolveEventArgs_tCC17EDD2766BA9905006344D9053EFC23C39CEC2, ___m_Name_1)); }
	inline String_t* get_m_Name_1() const { return ___m_Name_1; }
	inline String_t** get_address_of_m_Name_1() { return &___m_Name_1; }
	inline void set_m_Name_1(String_t* value)
	{
		___m_Name_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Name_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RESOLVEEVENTARGS_TCC17EDD2766BA9905006344D9053EFC23C39CEC2_H
#ifndef GCHANDLE_TE002D24915851AD73ACC0F503601C384273C3060_H
#define GCHANDLE_TE002D24915851AD73ACC0F503601C384273C3060_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.GCHandle
struct  GCHandle_tE002D24915851AD73ACC0F503601C384273C3060 
{
public:
	// System.Int32 System.Runtime.InteropServices.GCHandle::handle
	int32_t ___handle_0;

public:
	inline static int32_t get_offset_of_handle_0() { return static_cast<int32_t>(offsetof(GCHandle_tE002D24915851AD73ACC0F503601C384273C3060, ___handle_0)); }
	inline int32_t get_handle_0() const { return ___handle_0; }
	inline int32_t* get_address_of_handle_0() { return &___handle_0; }
	inline void set_handle_0(int32_t value)
	{
		___handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GCHANDLE_TE002D24915851AD73ACC0F503601C384273C3060_H
#ifndef SYSTEMEXCEPTION_T81A06ADD519539D252788D75E44AFFBE6580E301_H
#define SYSTEMEXCEPTION_T81A06ADD519539D252788D75E44AFFBE6580E301_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301  : public Exception_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T81A06ADD519539D252788D75E44AFFBE6580E301_H
#ifndef THREADSTATICATTRIBUTE_T6D7313EF8DF7B5CC3EFBDA457233386BFCBDBBC8_H
#define THREADSTATICATTRIBUTE_T6D7313EF8DF7B5CC3EFBDA457233386BFCBDBBC8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ThreadStaticAttribute
struct  ThreadStaticAttribute_t6D7313EF8DF7B5CC3EFBDA457233386BFCBDBBC8  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // THREADSTATICATTRIBUTE_T6D7313EF8DF7B5CC3EFBDA457233386BFCBDBBC8_H
#ifndef TIMESPAN_T26DE4373EA745C072A5FBDEAD8373348955FC374_H
#define TIMESPAN_T26DE4373EA745C072A5FBDEAD8373348955FC374_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TimeSpan
struct  TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 
{
public:
	// System.Int64 System.TimeSpan::_ticks
	int64_t ____ticks_3;

public:
	inline static int32_t get_offset_of__ticks_3() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374, ____ticks_3)); }
	inline int64_t get__ticks_3() const { return ____ticks_3; }
	inline int64_t* get_address_of__ticks_3() { return &____ticks_3; }
	inline void set__ticks_3(int64_t value)
	{
		____ticks_3 = value;
	}
};

struct TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields
{
public:
	// System.TimeSpan System.TimeSpan::MaxValue
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___MaxValue_0;
	// System.TimeSpan System.TimeSpan::MinValue
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___MinValue_1;
	// System.TimeSpan System.TimeSpan::Zero
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___Zero_2;

public:
	inline static int32_t get_offset_of_MaxValue_0() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields, ___MaxValue_0)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_MaxValue_0() const { return ___MaxValue_0; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_MaxValue_0() { return &___MaxValue_0; }
	inline void set_MaxValue_0(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___MaxValue_0 = value;
	}

	inline static int32_t get_offset_of_MinValue_1() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields, ___MinValue_1)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_MinValue_1() const { return ___MinValue_1; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_MinValue_1() { return &___MinValue_1; }
	inline void set_MinValue_1(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___MinValue_1 = value;
	}

	inline static int32_t get_offset_of_Zero_2() { return static_cast<int32_t>(offsetof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields, ___Zero_2)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_Zero_2() const { return ___Zero_2; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_Zero_2() { return &___Zero_2; }
	inline void set_Zero_2(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___Zero_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TIMESPAN_T26DE4373EA745C072A5FBDEAD8373348955FC374_H
#ifndef UNHANDLEDEXCEPTIONEVENTARGS_T2B19479B2BC866C465A8E07BEA9C6027CB168BA2_H
#define UNHANDLEDEXCEPTIONEVENTARGS_T2B19479B2BC866C465A8E07BEA9C6027CB168BA2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UnhandledExceptionEventArgs
struct  UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2  : public EventArgs_tA4C15C1D2AB4B139169B1942C1477933E00DCA17
{
public:
	// System.Object System.UnhandledExceptionEventArgs::exception
	RuntimeObject * ___exception_1;
	// System.Boolean System.UnhandledExceptionEventArgs::m_isTerminating
	bool ___m_isTerminating_2;

public:
	inline static int32_t get_offset_of_exception_1() { return static_cast<int32_t>(offsetof(UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2, ___exception_1)); }
	inline RuntimeObject * get_exception_1() const { return ___exception_1; }
	inline RuntimeObject ** get_address_of_exception_1() { return &___exception_1; }
	inline void set_exception_1(RuntimeObject * value)
	{
		___exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___exception_1), value);
	}

	inline static int32_t get_offset_of_m_isTerminating_2() { return static_cast<int32_t>(offsetof(UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2, ___m_isTerminating_2)); }
	inline bool get_m_isTerminating_2() const { return ___m_isTerminating_2; }
	inline bool* get_address_of_m_isTerminating_2() { return &___m_isTerminating_2; }
	inline void set_m_isTerminating_2(bool value)
	{
		___m_isTerminating_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNHANDLEDEXCEPTIONEVENTARGS_T2B19479B2BC866C465A8E07BEA9C6027CB168BA2_H
#ifndef VOID_TDB81A15FA2AB53E2401A76B745D215397B29F783_H
#define VOID_TDB81A15FA2AB53E2401A76B745D215397B29F783_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_tDB81A15FA2AB53E2401A76B745D215397B29F783 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_TDB81A15FA2AB53E2401A76B745D215397B29F783_H
#ifndef __IL2CPPCOMDELEGATE_T67B66A584C55DA33A97319518FAD9D61A503C4EE_H
#define __IL2CPPCOMDELEGATE_T67B66A584C55DA33A97319518FAD9D61A503C4EE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.__Il2CppComDelegate
struct  __Il2CppComDelegate_t67B66A584C55DA33A97319518FAD9D61A503C4EE  : public Il2CppComObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // __IL2CPPCOMDELEGATE_T67B66A584C55DA33A97319518FAD9D61A503C4EE_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>
struct  U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields
{
public:
	// <PrivateImplementationDetails>_U24ArrayTypeU2456 <PrivateImplementationDetails>::U24U24fieldU2D0
	U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4  ___U24U24fieldU2D0_0;
	// <PrivateImplementationDetails>_U24ArrayTypeU2424 <PrivateImplementationDetails>::U24U24fieldU2D1
	U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  ___U24U24fieldU2D1_1;
	// <PrivateImplementationDetails>_U24ArrayTypeU2424 <PrivateImplementationDetails>::U24U24fieldU2D2
	U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  ___U24U24fieldU2D2_2;
	// <PrivateImplementationDetails>_U24ArrayTypeU2424 <PrivateImplementationDetails>::U24U24fieldU2D3
	U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  ___U24U24fieldU2D3_3;
	// <PrivateImplementationDetails>_U24ArrayTypeU2424 <PrivateImplementationDetails>::U24U24fieldU2D4
	U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  ___U24U24fieldU2D4_4;
	// <PrivateImplementationDetails>_U24ArrayTypeU2416 <PrivateImplementationDetails>::U24U24fieldU2D5
	U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  ___U24U24fieldU2D5_5;
	// <PrivateImplementationDetails>_U24ArrayTypeU2416 <PrivateImplementationDetails>::U24U24fieldU2D6
	U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  ___U24U24fieldU2D6_6;
	// <PrivateImplementationDetails>_U24ArrayTypeU243132 <PrivateImplementationDetails>::U24U24fieldU2D15
	U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330  ___U24U24fieldU2D15_7;
	// <PrivateImplementationDetails>_U24ArrayTypeU2420 <PrivateImplementationDetails>::U24U24fieldU2D16
	U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84  ___U24U24fieldU2D16_8;
	// <PrivateImplementationDetails>_U24ArrayTypeU2432 <PrivateImplementationDetails>::U24U24fieldU2D17
	U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E  ___U24U24fieldU2D17_9;
	// <PrivateImplementationDetails>_U24ArrayTypeU2448 <PrivateImplementationDetails>::U24U24fieldU2D18
	U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6  ___U24U24fieldU2D18_10;
	// <PrivateImplementationDetails>_U24ArrayTypeU2464 <PrivateImplementationDetails>::U24U24fieldU2D19
	U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  ___U24U24fieldU2D19_11;
	// <PrivateImplementationDetails>_U24ArrayTypeU2464 <PrivateImplementationDetails>::U24U24fieldU2D20
	U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  ___U24U24fieldU2D20_12;
	// <PrivateImplementationDetails>_U24ArrayTypeU2464 <PrivateImplementationDetails>::U24U24fieldU2D21
	U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  ___U24U24fieldU2D21_13;
	// <PrivateImplementationDetails>_U24ArrayTypeU2464 <PrivateImplementationDetails>::U24U24fieldU2D22
	U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  ___U24U24fieldU2D22_14;
	// <PrivateImplementationDetails>_U24ArrayTypeU2412 <PrivateImplementationDetails>::U24U24fieldU2D23
	U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  ___U24U24fieldU2D23_15;
	// <PrivateImplementationDetails>_U24ArrayTypeU2412 <PrivateImplementationDetails>::U24U24fieldU2D24
	U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  ___U24U24fieldU2D24_16;
	// <PrivateImplementationDetails>_U24ArrayTypeU2412 <PrivateImplementationDetails>::U24U24fieldU2D25
	U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  ___U24U24fieldU2D25_17;
	// <PrivateImplementationDetails>_U24ArrayTypeU2416 <PrivateImplementationDetails>::U24U24fieldU2D26
	U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  ___U24U24fieldU2D26_18;
	// <PrivateImplementationDetails>_U24ArrayTypeU24136 <PrivateImplementationDetails>::U24U24fieldU2D27
	U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2  ___U24U24fieldU2D27_19;
	// <PrivateImplementationDetails>_U24ArrayTypeU2472 <PrivateImplementationDetails>::U24U24fieldU2D30
	U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517  ___U24U24fieldU2D30_20;
	// <PrivateImplementationDetails>_U24ArrayTypeU248 <PrivateImplementationDetails>::U24U24fieldU2D31
	U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967  ___U24U24fieldU2D31_21;
	// <PrivateImplementationDetails>_U24ArrayTypeU2420 <PrivateImplementationDetails>::U24U24fieldU2D32
	U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84  ___U24U24fieldU2D32_22;
	// <PrivateImplementationDetails>_U24ArrayTypeU2464 <PrivateImplementationDetails>::U24U24fieldU2D33
	U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  ___U24U24fieldU2D33_23;
	// <PrivateImplementationDetails>_U24ArrayTypeU24124 <PrivateImplementationDetails>::U24U24fieldU2D34
	U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F  ___U24U24fieldU2D34_24;
	// <PrivateImplementationDetails>_U24ArrayTypeU2432 <PrivateImplementationDetails>::U24U24fieldU2D35
	U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E  ___U24U24fieldU2D35_25;
	// <PrivateImplementationDetails>_U24ArrayTypeU2496 <PrivateImplementationDetails>::U24U24fieldU2D36
	U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2  ___U24U24fieldU2D36_26;
	// <PrivateImplementationDetails>_U24ArrayTypeU242048 <PrivateImplementationDetails>::U24U24fieldU2D37
	U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  ___U24U24fieldU2D37_27;
	// <PrivateImplementationDetails>_U24ArrayTypeU2456 <PrivateImplementationDetails>::U24U24fieldU2D38
	U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4  ___U24U24fieldU2D38_28;
	// <PrivateImplementationDetails>_U24ArrayTypeU2416 <PrivateImplementationDetails>::U24U24fieldU2D39
	U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  ___U24U24fieldU2D39_29;
	// <PrivateImplementationDetails>_U24ArrayTypeU2448 <PrivateImplementationDetails>::U24U24fieldU2D40
	U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6  ___U24U24fieldU2D40_30;
	// <PrivateImplementationDetails>_U24ArrayTypeU242048 <PrivateImplementationDetails>::U24U24fieldU2D41
	U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  ___U24U24fieldU2D41_31;
	// <PrivateImplementationDetails>_U24ArrayTypeU242048 <PrivateImplementationDetails>::U24U24fieldU2D42
	U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  ___U24U24fieldU2D42_32;
	// <PrivateImplementationDetails>_U24ArrayTypeU24256 <PrivateImplementationDetails>::U24U24fieldU2D43
	U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  ___U24U24fieldU2D43_33;
	// <PrivateImplementationDetails>_U24ArrayTypeU24256 <PrivateImplementationDetails>::U24U24fieldU2D44
	U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  ___U24U24fieldU2D44_34;
	// <PrivateImplementationDetails>_U24ArrayTypeU24120 <PrivateImplementationDetails>::U24U24fieldU2D45
	U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA  ___U24U24fieldU2D45_35;
	// <PrivateImplementationDetails>_U24ArrayTypeU24256 <PrivateImplementationDetails>::U24U24fieldU2D46
	U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  ___U24U24fieldU2D46_36;
	// <PrivateImplementationDetails>_U24ArrayTypeU24256 <PrivateImplementationDetails>::U24U24fieldU2D47
	U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  ___U24U24fieldU2D47_37;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D48
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D48_38;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D49
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D49_39;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D50
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D50_40;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D51
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D51_41;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D52
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D52_42;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D53
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D53_43;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D54
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D54_44;
	// <PrivateImplementationDetails>_U24ArrayTypeU241024 <PrivateImplementationDetails>::U24U24fieldU2D55
	U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  ___U24U24fieldU2D55_45;
	// <PrivateImplementationDetails>_U24ArrayTypeU24256 <PrivateImplementationDetails>::U24U24fieldU2D56
	U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  ___U24U24fieldU2D56_46;
	// <PrivateImplementationDetails>_U24ArrayTypeU24640 <PrivateImplementationDetails>::U24U24fieldU2D57
	U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC  ___U24U24fieldU2D57_47;
	// <PrivateImplementationDetails>_U24ArrayTypeU2412 <PrivateImplementationDetails>::U24U24fieldU2D60
	U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  ___U24U24fieldU2D60_48;
	// <PrivateImplementationDetails>_U24ArrayTypeU24128 <PrivateImplementationDetails>::U24U24fieldU2D62
	U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F  ___U24U24fieldU2D62_49;
	// <PrivateImplementationDetails>_U24ArrayTypeU24256 <PrivateImplementationDetails>::U24U24fieldU2D63
	U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  ___U24U24fieldU2D63_50;
	// <PrivateImplementationDetails>_U24ArrayTypeU2452 <PrivateImplementationDetails>::U24U24fieldU2D64
	U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952  ___U24U24fieldU2D64_51;
	// <PrivateImplementationDetails>_U24ArrayTypeU2452 <PrivateImplementationDetails>::U24U24fieldU2D65
	U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952  ___U24U24fieldU2D65_52;

public:
	inline static int32_t get_offset_of_U24U24fieldU2D0_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D0_0)); }
	inline U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4  get_U24U24fieldU2D0_0() const { return ___U24U24fieldU2D0_0; }
	inline U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4 * get_address_of_U24U24fieldU2D0_0() { return &___U24U24fieldU2D0_0; }
	inline void set_U24U24fieldU2D0_0(U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4  value)
	{
		___U24U24fieldU2D0_0 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D1_1() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D1_1)); }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  get_U24U24fieldU2D1_1() const { return ___U24U24fieldU2D1_1; }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796 * get_address_of_U24U24fieldU2D1_1() { return &___U24U24fieldU2D1_1; }
	inline void set_U24U24fieldU2D1_1(U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  value)
	{
		___U24U24fieldU2D1_1 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D2_2() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D2_2)); }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  get_U24U24fieldU2D2_2() const { return ___U24U24fieldU2D2_2; }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796 * get_address_of_U24U24fieldU2D2_2() { return &___U24U24fieldU2D2_2; }
	inline void set_U24U24fieldU2D2_2(U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  value)
	{
		___U24U24fieldU2D2_2 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D3_3() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D3_3)); }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  get_U24U24fieldU2D3_3() const { return ___U24U24fieldU2D3_3; }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796 * get_address_of_U24U24fieldU2D3_3() { return &___U24U24fieldU2D3_3; }
	inline void set_U24U24fieldU2D3_3(U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  value)
	{
		___U24U24fieldU2D3_3 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D4_4() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D4_4)); }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  get_U24U24fieldU2D4_4() const { return ___U24U24fieldU2D4_4; }
	inline U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796 * get_address_of_U24U24fieldU2D4_4() { return &___U24U24fieldU2D4_4; }
	inline void set_U24U24fieldU2D4_4(U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796  value)
	{
		___U24U24fieldU2D4_4 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D5_5() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D5_5)); }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  get_U24U24fieldU2D5_5() const { return ___U24U24fieldU2D5_5; }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6 * get_address_of_U24U24fieldU2D5_5() { return &___U24U24fieldU2D5_5; }
	inline void set_U24U24fieldU2D5_5(U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  value)
	{
		___U24U24fieldU2D5_5 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D6_6() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D6_6)); }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  get_U24U24fieldU2D6_6() const { return ___U24U24fieldU2D6_6; }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6 * get_address_of_U24U24fieldU2D6_6() { return &___U24U24fieldU2D6_6; }
	inline void set_U24U24fieldU2D6_6(U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  value)
	{
		___U24U24fieldU2D6_6 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D15_7() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D15_7)); }
	inline U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330  get_U24U24fieldU2D15_7() const { return ___U24U24fieldU2D15_7; }
	inline U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330 * get_address_of_U24U24fieldU2D15_7() { return &___U24U24fieldU2D15_7; }
	inline void set_U24U24fieldU2D15_7(U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330  value)
	{
		___U24U24fieldU2D15_7 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D16_8() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D16_8)); }
	inline U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84  get_U24U24fieldU2D16_8() const { return ___U24U24fieldU2D16_8; }
	inline U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84 * get_address_of_U24U24fieldU2D16_8() { return &___U24U24fieldU2D16_8; }
	inline void set_U24U24fieldU2D16_8(U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84  value)
	{
		___U24U24fieldU2D16_8 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D17_9() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D17_9)); }
	inline U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E  get_U24U24fieldU2D17_9() const { return ___U24U24fieldU2D17_9; }
	inline U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E * get_address_of_U24U24fieldU2D17_9() { return &___U24U24fieldU2D17_9; }
	inline void set_U24U24fieldU2D17_9(U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E  value)
	{
		___U24U24fieldU2D17_9 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D18_10() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D18_10)); }
	inline U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6  get_U24U24fieldU2D18_10() const { return ___U24U24fieldU2D18_10; }
	inline U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6 * get_address_of_U24U24fieldU2D18_10() { return &___U24U24fieldU2D18_10; }
	inline void set_U24U24fieldU2D18_10(U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6  value)
	{
		___U24U24fieldU2D18_10 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D19_11() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D19_11)); }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  get_U24U24fieldU2D19_11() const { return ___U24U24fieldU2D19_11; }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E * get_address_of_U24U24fieldU2D19_11() { return &___U24U24fieldU2D19_11; }
	inline void set_U24U24fieldU2D19_11(U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  value)
	{
		___U24U24fieldU2D19_11 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D20_12() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D20_12)); }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  get_U24U24fieldU2D20_12() const { return ___U24U24fieldU2D20_12; }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E * get_address_of_U24U24fieldU2D20_12() { return &___U24U24fieldU2D20_12; }
	inline void set_U24U24fieldU2D20_12(U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  value)
	{
		___U24U24fieldU2D20_12 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D21_13() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D21_13)); }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  get_U24U24fieldU2D21_13() const { return ___U24U24fieldU2D21_13; }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E * get_address_of_U24U24fieldU2D21_13() { return &___U24U24fieldU2D21_13; }
	inline void set_U24U24fieldU2D21_13(U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  value)
	{
		___U24U24fieldU2D21_13 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D22_14() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D22_14)); }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  get_U24U24fieldU2D22_14() const { return ___U24U24fieldU2D22_14; }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E * get_address_of_U24U24fieldU2D22_14() { return &___U24U24fieldU2D22_14; }
	inline void set_U24U24fieldU2D22_14(U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  value)
	{
		___U24U24fieldU2D22_14 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D23_15() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D23_15)); }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  get_U24U24fieldU2D23_15() const { return ___U24U24fieldU2D23_15; }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1 * get_address_of_U24U24fieldU2D23_15() { return &___U24U24fieldU2D23_15; }
	inline void set_U24U24fieldU2D23_15(U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  value)
	{
		___U24U24fieldU2D23_15 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D24_16() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D24_16)); }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  get_U24U24fieldU2D24_16() const { return ___U24U24fieldU2D24_16; }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1 * get_address_of_U24U24fieldU2D24_16() { return &___U24U24fieldU2D24_16; }
	inline void set_U24U24fieldU2D24_16(U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  value)
	{
		___U24U24fieldU2D24_16 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D25_17() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D25_17)); }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  get_U24U24fieldU2D25_17() const { return ___U24U24fieldU2D25_17; }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1 * get_address_of_U24U24fieldU2D25_17() { return &___U24U24fieldU2D25_17; }
	inline void set_U24U24fieldU2D25_17(U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  value)
	{
		___U24U24fieldU2D25_17 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D26_18() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D26_18)); }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  get_U24U24fieldU2D26_18() const { return ___U24U24fieldU2D26_18; }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6 * get_address_of_U24U24fieldU2D26_18() { return &___U24U24fieldU2D26_18; }
	inline void set_U24U24fieldU2D26_18(U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  value)
	{
		___U24U24fieldU2D26_18 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D27_19() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D27_19)); }
	inline U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2  get_U24U24fieldU2D27_19() const { return ___U24U24fieldU2D27_19; }
	inline U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2 * get_address_of_U24U24fieldU2D27_19() { return &___U24U24fieldU2D27_19; }
	inline void set_U24U24fieldU2D27_19(U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2  value)
	{
		___U24U24fieldU2D27_19 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D30_20() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D30_20)); }
	inline U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517  get_U24U24fieldU2D30_20() const { return ___U24U24fieldU2D30_20; }
	inline U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517 * get_address_of_U24U24fieldU2D30_20() { return &___U24U24fieldU2D30_20; }
	inline void set_U24U24fieldU2D30_20(U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517  value)
	{
		___U24U24fieldU2D30_20 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D31_21() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D31_21)); }
	inline U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967  get_U24U24fieldU2D31_21() const { return ___U24U24fieldU2D31_21; }
	inline U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967 * get_address_of_U24U24fieldU2D31_21() { return &___U24U24fieldU2D31_21; }
	inline void set_U24U24fieldU2D31_21(U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967  value)
	{
		___U24U24fieldU2D31_21 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D32_22() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D32_22)); }
	inline U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84  get_U24U24fieldU2D32_22() const { return ___U24U24fieldU2D32_22; }
	inline U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84 * get_address_of_U24U24fieldU2D32_22() { return &___U24U24fieldU2D32_22; }
	inline void set_U24U24fieldU2D32_22(U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84  value)
	{
		___U24U24fieldU2D32_22 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D33_23() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D33_23)); }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  get_U24U24fieldU2D33_23() const { return ___U24U24fieldU2D33_23; }
	inline U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E * get_address_of_U24U24fieldU2D33_23() { return &___U24U24fieldU2D33_23; }
	inline void set_U24U24fieldU2D33_23(U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E  value)
	{
		___U24U24fieldU2D33_23 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D34_24() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D34_24)); }
	inline U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F  get_U24U24fieldU2D34_24() const { return ___U24U24fieldU2D34_24; }
	inline U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F * get_address_of_U24U24fieldU2D34_24() { return &___U24U24fieldU2D34_24; }
	inline void set_U24U24fieldU2D34_24(U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F  value)
	{
		___U24U24fieldU2D34_24 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D35_25() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D35_25)); }
	inline U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E  get_U24U24fieldU2D35_25() const { return ___U24U24fieldU2D35_25; }
	inline U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E * get_address_of_U24U24fieldU2D35_25() { return &___U24U24fieldU2D35_25; }
	inline void set_U24U24fieldU2D35_25(U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E  value)
	{
		___U24U24fieldU2D35_25 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D36_26() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D36_26)); }
	inline U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2  get_U24U24fieldU2D36_26() const { return ___U24U24fieldU2D36_26; }
	inline U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2 * get_address_of_U24U24fieldU2D36_26() { return &___U24U24fieldU2D36_26; }
	inline void set_U24U24fieldU2D36_26(U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2  value)
	{
		___U24U24fieldU2D36_26 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D37_27() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D37_27)); }
	inline U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  get_U24U24fieldU2D37_27() const { return ___U24U24fieldU2D37_27; }
	inline U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8 * get_address_of_U24U24fieldU2D37_27() { return &___U24U24fieldU2D37_27; }
	inline void set_U24U24fieldU2D37_27(U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  value)
	{
		___U24U24fieldU2D37_27 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D38_28() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D38_28)); }
	inline U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4  get_U24U24fieldU2D38_28() const { return ___U24U24fieldU2D38_28; }
	inline U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4 * get_address_of_U24U24fieldU2D38_28() { return &___U24U24fieldU2D38_28; }
	inline void set_U24U24fieldU2D38_28(U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4  value)
	{
		___U24U24fieldU2D38_28 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D39_29() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D39_29)); }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  get_U24U24fieldU2D39_29() const { return ___U24U24fieldU2D39_29; }
	inline U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6 * get_address_of_U24U24fieldU2D39_29() { return &___U24U24fieldU2D39_29; }
	inline void set_U24U24fieldU2D39_29(U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6  value)
	{
		___U24U24fieldU2D39_29 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D40_30() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D40_30)); }
	inline U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6  get_U24U24fieldU2D40_30() const { return ___U24U24fieldU2D40_30; }
	inline U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6 * get_address_of_U24U24fieldU2D40_30() { return &___U24U24fieldU2D40_30; }
	inline void set_U24U24fieldU2D40_30(U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6  value)
	{
		___U24U24fieldU2D40_30 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D41_31() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D41_31)); }
	inline U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  get_U24U24fieldU2D41_31() const { return ___U24U24fieldU2D41_31; }
	inline U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8 * get_address_of_U24U24fieldU2D41_31() { return &___U24U24fieldU2D41_31; }
	inline void set_U24U24fieldU2D41_31(U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  value)
	{
		___U24U24fieldU2D41_31 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D42_32() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D42_32)); }
	inline U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  get_U24U24fieldU2D42_32() const { return ___U24U24fieldU2D42_32; }
	inline U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8 * get_address_of_U24U24fieldU2D42_32() { return &___U24U24fieldU2D42_32; }
	inline void set_U24U24fieldU2D42_32(U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8  value)
	{
		___U24U24fieldU2D42_32 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D43_33() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D43_33)); }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  get_U24U24fieldU2D43_33() const { return ___U24U24fieldU2D43_33; }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF * get_address_of_U24U24fieldU2D43_33() { return &___U24U24fieldU2D43_33; }
	inline void set_U24U24fieldU2D43_33(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  value)
	{
		___U24U24fieldU2D43_33 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D44_34() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D44_34)); }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  get_U24U24fieldU2D44_34() const { return ___U24U24fieldU2D44_34; }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF * get_address_of_U24U24fieldU2D44_34() { return &___U24U24fieldU2D44_34; }
	inline void set_U24U24fieldU2D44_34(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  value)
	{
		___U24U24fieldU2D44_34 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D45_35() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D45_35)); }
	inline U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA  get_U24U24fieldU2D45_35() const { return ___U24U24fieldU2D45_35; }
	inline U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA * get_address_of_U24U24fieldU2D45_35() { return &___U24U24fieldU2D45_35; }
	inline void set_U24U24fieldU2D45_35(U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA  value)
	{
		___U24U24fieldU2D45_35 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D46_36() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D46_36)); }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  get_U24U24fieldU2D46_36() const { return ___U24U24fieldU2D46_36; }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF * get_address_of_U24U24fieldU2D46_36() { return &___U24U24fieldU2D46_36; }
	inline void set_U24U24fieldU2D46_36(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  value)
	{
		___U24U24fieldU2D46_36 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D47_37() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D47_37)); }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  get_U24U24fieldU2D47_37() const { return ___U24U24fieldU2D47_37; }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF * get_address_of_U24U24fieldU2D47_37() { return &___U24U24fieldU2D47_37; }
	inline void set_U24U24fieldU2D47_37(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  value)
	{
		___U24U24fieldU2D47_37 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D48_38() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D48_38)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D48_38() const { return ___U24U24fieldU2D48_38; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D48_38() { return &___U24U24fieldU2D48_38; }
	inline void set_U24U24fieldU2D48_38(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D48_38 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D49_39() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D49_39)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D49_39() const { return ___U24U24fieldU2D49_39; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D49_39() { return &___U24U24fieldU2D49_39; }
	inline void set_U24U24fieldU2D49_39(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D49_39 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D50_40() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D50_40)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D50_40() const { return ___U24U24fieldU2D50_40; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D50_40() { return &___U24U24fieldU2D50_40; }
	inline void set_U24U24fieldU2D50_40(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D50_40 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D51_41() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D51_41)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D51_41() const { return ___U24U24fieldU2D51_41; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D51_41() { return &___U24U24fieldU2D51_41; }
	inline void set_U24U24fieldU2D51_41(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D51_41 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D52_42() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D52_42)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D52_42() const { return ___U24U24fieldU2D52_42; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D52_42() { return &___U24U24fieldU2D52_42; }
	inline void set_U24U24fieldU2D52_42(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D52_42 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D53_43() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D53_43)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D53_43() const { return ___U24U24fieldU2D53_43; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D53_43() { return &___U24U24fieldU2D53_43; }
	inline void set_U24U24fieldU2D53_43(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D53_43 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D54_44() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D54_44)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D54_44() const { return ___U24U24fieldU2D54_44; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D54_44() { return &___U24U24fieldU2D54_44; }
	inline void set_U24U24fieldU2D54_44(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D54_44 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D55_45() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D55_45)); }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  get_U24U24fieldU2D55_45() const { return ___U24U24fieldU2D55_45; }
	inline U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 * get_address_of_U24U24fieldU2D55_45() { return &___U24U24fieldU2D55_45; }
	inline void set_U24U24fieldU2D55_45(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964  value)
	{
		___U24U24fieldU2D55_45 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D56_46() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D56_46)); }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  get_U24U24fieldU2D56_46() const { return ___U24U24fieldU2D56_46; }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF * get_address_of_U24U24fieldU2D56_46() { return &___U24U24fieldU2D56_46; }
	inline void set_U24U24fieldU2D56_46(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  value)
	{
		___U24U24fieldU2D56_46 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D57_47() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D57_47)); }
	inline U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC  get_U24U24fieldU2D57_47() const { return ___U24U24fieldU2D57_47; }
	inline U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC * get_address_of_U24U24fieldU2D57_47() { return &___U24U24fieldU2D57_47; }
	inline void set_U24U24fieldU2D57_47(U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC  value)
	{
		___U24U24fieldU2D57_47 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D60_48() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D60_48)); }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  get_U24U24fieldU2D60_48() const { return ___U24U24fieldU2D60_48; }
	inline U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1 * get_address_of_U24U24fieldU2D60_48() { return &___U24U24fieldU2D60_48; }
	inline void set_U24U24fieldU2D60_48(U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1  value)
	{
		___U24U24fieldU2D60_48 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D62_49() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D62_49)); }
	inline U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F  get_U24U24fieldU2D62_49() const { return ___U24U24fieldU2D62_49; }
	inline U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F * get_address_of_U24U24fieldU2D62_49() { return &___U24U24fieldU2D62_49; }
	inline void set_U24U24fieldU2D62_49(U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F  value)
	{
		___U24U24fieldU2D62_49 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D63_50() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D63_50)); }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  get_U24U24fieldU2D63_50() const { return ___U24U24fieldU2D63_50; }
	inline U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF * get_address_of_U24U24fieldU2D63_50() { return &___U24U24fieldU2D63_50; }
	inline void set_U24U24fieldU2D63_50(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF  value)
	{
		___U24U24fieldU2D63_50 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D64_51() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D64_51)); }
	inline U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952  get_U24U24fieldU2D64_51() const { return ___U24U24fieldU2D64_51; }
	inline U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952 * get_address_of_U24U24fieldU2D64_51() { return &___U24U24fieldU2D64_51; }
	inline void set_U24U24fieldU2D64_51(U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952  value)
	{
		___U24U24fieldU2D64_51 = value;
	}

	inline static int32_t get_offset_of_U24U24fieldU2D65_52() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields, ___U24U24fieldU2D65_52)); }
	inline U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952  get_U24U24fieldU2D65_52() const { return ___U24U24fieldU2D65_52; }
	inline U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952 * get_address_of_U24U24fieldU2D65_52() { return &___U24U24fieldU2D65_52; }
	inline void set_U24U24fieldU2D65_52(U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952  value)
	{
		___U24U24fieldU2D65_52 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_H
#ifndef CONFIDENCEFACTOR_T71A0B96E30FFB0AF44AE40D3FA6CE640CB17301E_H
#define CONFIDENCEFACTOR_T71A0B96E30FFB0AF44AE40D3FA6CE640CB17301E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Math.Prime.ConfidenceFactor
struct  ConfidenceFactor_t71A0B96E30FFB0AF44AE40D3FA6CE640CB17301E 
{
public:
	// System.Int32 Mono.Math.Prime.ConfidenceFactor::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ConfidenceFactor_t71A0B96E30FFB0AF44AE40D3FA6CE640CB17301E, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFIDENCEFACTOR_T71A0B96E30FFB0AF44AE40D3FA6CE640CB17301E_H
#ifndef ARITHMETICEXCEPTION_T1A90923A99EA9AF25291E93082E853313F29DDCD_H
#define ARITHMETICEXCEPTION_T1A90923A99EA9AF25291E93082E853313F29DDCD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArithmeticException
struct  ArithmeticException_t1A90923A99EA9AF25291E93082E853313F29DDCD  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARITHMETICEXCEPTION_T1A90923A99EA9AF25291E93082E853313F29DDCD_H
#ifndef EDITORBROWSABLESTATE_T29045763CB3BEAC19254BB89EEF28ECA6A824E22_H
#define EDITORBROWSABLESTATE_T29045763CB3BEAC19254BB89EEF28ECA6A824E22_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.EditorBrowsableState
struct  EditorBrowsableState_t29045763CB3BEAC19254BB89EEF28ECA6A824E22 
{
public:
	// System.Int32 System.ComponentModel.EditorBrowsableState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(EditorBrowsableState_t29045763CB3BEAC19254BB89EEF28ECA6A824E22, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EDITORBROWSABLESTATE_T29045763CB3BEAC19254BB89EEF28ECA6A824E22_H
#ifndef CURRENTSYSTEMTIMEZONE_TD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_H
#define CURRENTSYSTEMTIMEZONE_TD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.CurrentSystemTimeZone
struct  CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C  : public TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB
{
public:
	// System.String System.CurrentSystemTimeZone::m_standardName
	String_t* ___m_standardName_3;
	// System.String System.CurrentSystemTimeZone::m_daylightName
	String_t* ___m_daylightName_4;
	// System.Collections.Hashtable System.CurrentSystemTimeZone::m_CachedDaylightChanges
	Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * ___m_CachedDaylightChanges_5;
	// System.Int64 System.CurrentSystemTimeZone::m_ticksOffset
	int64_t ___m_ticksOffset_6;
	// System.TimeSpan System.CurrentSystemTimeZone::utcOffsetWithOutDLS
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___utcOffsetWithOutDLS_7;
	// System.TimeSpan System.CurrentSystemTimeZone::utcOffsetWithDLS
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  ___utcOffsetWithDLS_8;

public:
	inline static int32_t get_offset_of_m_standardName_3() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C, ___m_standardName_3)); }
	inline String_t* get_m_standardName_3() const { return ___m_standardName_3; }
	inline String_t** get_address_of_m_standardName_3() { return &___m_standardName_3; }
	inline void set_m_standardName_3(String_t* value)
	{
		___m_standardName_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_standardName_3), value);
	}

	inline static int32_t get_offset_of_m_daylightName_4() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C, ___m_daylightName_4)); }
	inline String_t* get_m_daylightName_4() const { return ___m_daylightName_4; }
	inline String_t** get_address_of_m_daylightName_4() { return &___m_daylightName_4; }
	inline void set_m_daylightName_4(String_t* value)
	{
		___m_daylightName_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_daylightName_4), value);
	}

	inline static int32_t get_offset_of_m_CachedDaylightChanges_5() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C, ___m_CachedDaylightChanges_5)); }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * get_m_CachedDaylightChanges_5() const { return ___m_CachedDaylightChanges_5; }
	inline Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 ** get_address_of_m_CachedDaylightChanges_5() { return &___m_CachedDaylightChanges_5; }
	inline void set_m_CachedDaylightChanges_5(Hashtable_tA746260C9064A8C1FC071FF85C11C8EBAEB51B82 * value)
	{
		___m_CachedDaylightChanges_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_CachedDaylightChanges_5), value);
	}

	inline static int32_t get_offset_of_m_ticksOffset_6() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C, ___m_ticksOffset_6)); }
	inline int64_t get_m_ticksOffset_6() const { return ___m_ticksOffset_6; }
	inline int64_t* get_address_of_m_ticksOffset_6() { return &___m_ticksOffset_6; }
	inline void set_m_ticksOffset_6(int64_t value)
	{
		___m_ticksOffset_6 = value;
	}

	inline static int32_t get_offset_of_utcOffsetWithOutDLS_7() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C, ___utcOffsetWithOutDLS_7)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_utcOffsetWithOutDLS_7() const { return ___utcOffsetWithOutDLS_7; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_utcOffsetWithOutDLS_7() { return &___utcOffsetWithOutDLS_7; }
	inline void set_utcOffsetWithOutDLS_7(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___utcOffsetWithOutDLS_7 = value;
	}

	inline static int32_t get_offset_of_utcOffsetWithDLS_8() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C, ___utcOffsetWithDLS_8)); }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  get_utcOffsetWithDLS_8() const { return ___utcOffsetWithDLS_8; }
	inline TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 * get_address_of_utcOffsetWithDLS_8() { return &___utcOffsetWithDLS_8; }
	inline void set_utcOffsetWithDLS_8(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374  value)
	{
		___utcOffsetWithDLS_8 = value;
	}
};

struct CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_StaticFields
{
public:
	// System.Int32 System.CurrentSystemTimeZone::this_year
	int32_t ___this_year_9;
	// System.Globalization.DaylightTime System.CurrentSystemTimeZone::this_year_dlt
	DaylightTime_tB08789D033A1BB446A5246183BD7DD6E067BE226 * ___this_year_dlt_10;

public:
	inline static int32_t get_offset_of_this_year_9() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_StaticFields, ___this_year_9)); }
	inline int32_t get_this_year_9() const { return ___this_year_9; }
	inline int32_t* get_address_of_this_year_9() { return &___this_year_9; }
	inline void set_this_year_9(int32_t value)
	{
		___this_year_9 = value;
	}

	inline static int32_t get_offset_of_this_year_dlt_10() { return static_cast<int32_t>(offsetof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_StaticFields, ___this_year_dlt_10)); }
	inline DaylightTime_tB08789D033A1BB446A5246183BD7DD6E067BE226 * get_this_year_dlt_10() const { return ___this_year_dlt_10; }
	inline DaylightTime_tB08789D033A1BB446A5246183BD7DD6E067BE226 ** get_address_of_this_year_dlt_10() { return &___this_year_dlt_10; }
	inline void set_this_year_dlt_10(DaylightTime_tB08789D033A1BB446A5246183BD7DD6E067BE226 * value)
	{
		___this_year_dlt_10 = value;
		Il2CppCodeGenWriteBarrier((&___this_year_dlt_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CURRENTSYSTEMTIMEZONE_TD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_5;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_6;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_7;
	// System.DelegateData System.Delegate::data
	DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 * ___data_8;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_method_code_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_5)); }
	inline intptr_t get_method_code_5() const { return ___method_code_5; }
	inline intptr_t* get_address_of_method_code_5() { return &___method_code_5; }
	inline void set_method_code_5(intptr_t value)
	{
		___method_code_5 = value;
	}

	inline static int32_t get_offset_of_method_info_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_6)); }
	inline MethodInfo_t * get_method_info_6() const { return ___method_info_6; }
	inline MethodInfo_t ** get_address_of_method_info_6() { return &___method_info_6; }
	inline void set_method_info_6(MethodInfo_t * value)
	{
		___method_info_6 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_6), value);
	}

	inline static int32_t get_offset_of_original_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_7)); }
	inline MethodInfo_t * get_original_method_info_7() const { return ___original_method_info_7; }
	inline MethodInfo_t ** get_address_of_original_method_info_7() { return &___original_method_info_7; }
	inline void set_original_method_info_7(MethodInfo_t * value)
	{
		___original_method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_7), value);
	}

	inline static int32_t get_offset_of_data_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_8)); }
	inline DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 * get_data_8() const { return ___data_8; }
	inline DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 ** get_address_of_data_8() { return &___data_8; }
	inline void set_data_8(DelegateData_tF588FE8D395F9A38FC7D222940F9B218441D21A9 * value)
	{
		___data_8 = value;
		Il2CppCodeGenWriteBarrier((&___data_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DELEGATE_T_H
#ifndef INVALIDOPERATIONEXCEPTION_TCE0CC6C0C8EE2E780C0736B79AA673751C79CC07_H
#define INVALIDOPERATIONEXCEPTION_TCE0CC6C0C8EE2E780C0736B79AA673751C79CC07_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.InvalidOperationException
struct  InvalidOperationException_tCE0CC6C0C8EE2E780C0736B79AA673751C79CC07  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INVALIDOPERATIONEXCEPTION_TCE0CC6C0C8EE2E780C0736B79AA673751C79CC07_H
#ifndef AUTHENTICATIONLEVEL_TDD7C55ABAF179BD6273AA3DC6AC59A265B006E17_H
#define AUTHENTICATIONLEVEL_TDD7C55ABAF179BD6273AA3DC6AC59A265B006E17_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.Security.AuthenticationLevel
struct  AuthenticationLevel_tDD7C55ABAF179BD6273AA3DC6AC59A265B006E17 
{
public:
	// System.Int32 System.Net.Security.AuthenticationLevel::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AuthenticationLevel_tDD7C55ABAF179BD6273AA3DC6AC59A265B006E17, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUTHENTICATIONLEVEL_TDD7C55ABAF179BD6273AA3DC6AC59A265B006E17_H
#ifndef SSLPOLICYERRORS_T821E0247A29EDB8CD8327153A81349E907DBE6E9_H
#define SSLPOLICYERRORS_T821E0247A29EDB8CD8327153A81349E907DBE6E9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.Security.SslPolicyErrors
struct  SslPolicyErrors_t821E0247A29EDB8CD8327153A81349E907DBE6E9 
{
public:
	// System.Int32 System.Net.Security.SslPolicyErrors::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SslPolicyErrors_t821E0247A29EDB8CD8327153A81349E907DBE6E9, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SSLPOLICYERRORS_T821E0247A29EDB8CD8327153A81349E907DBE6E9_H
#ifndef ADDRESSFAMILY_T56E41B784F73C1D53BE91A309AB9E5A35F947876_H
#define ADDRESSFAMILY_T56E41B784F73C1D53BE91A309AB9E5A35F947876_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.Sockets.AddressFamily
struct  AddressFamily_t56E41B784F73C1D53BE91A309AB9E5A35F947876 
{
public:
	// System.Int32 System.Net.Sockets.AddressFamily::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AddressFamily_t56E41B784F73C1D53BE91A309AB9E5A35F947876, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ADDRESSFAMILY_T56E41B784F73C1D53BE91A309AB9E5A35F947876_H
#ifndef NOTSUPPORTEDEXCEPTION_T8C86714BF66E55D3F33E200FA7C385BC13C7E3B6_H
#define NOTSUPPORTEDEXCEPTION_T8C86714BF66E55D3F33E200FA7C385BC13C7E3B6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.NotSupportedException
struct  NotSupportedException_t8C86714BF66E55D3F33E200FA7C385BC13C7E3B6  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NOTSUPPORTEDEXCEPTION_T8C86714BF66E55D3F33E200FA7C385BC13C7E3B6_H
#ifndef OUTOFMEMORYEXCEPTION_TE2918256672960D75F6CB0F244BC1E4F5F77AC5F_H
#define OUTOFMEMORYEXCEPTION_TE2918256672960D75F6CB0F244BC1E4F5F77AC5F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.OutOfMemoryException
struct  OutOfMemoryException_tE2918256672960D75F6CB0F244BC1E4F5F77AC5F  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OUTOFMEMORYEXCEPTION_TE2918256672960D75F6CB0F244BC1E4F5F77AC5F_H
#ifndef PLATFORMID_T9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2_H
#define PLATFORMID_T9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.PlatformID
struct  PlatformID_t9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2 
{
public:
	// System.Int32 System.PlatformID::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PlatformID_t9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLATFORMID_T9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2_H
#ifndef RANKEXCEPTION_T02C0FFDDC74AF1EFF7843762CF08142217246395_H
#define RANKEXCEPTION_T02C0FFDDC74AF1EFF7843762CF08142217246395_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RankException
struct  RankException_t02C0FFDDC74AF1EFF7843762CF08142217246395  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RANKEXCEPTION_T02C0FFDDC74AF1EFF7843762CF08142217246395_H
#ifndef EXTERNALEXCEPTION_TF3125876B625B17B9682FFEA1AF1B405736E67C7_H
#define EXTERNALEXCEPTION_TF3125876B625B17B9682FFEA1AF1B405736E67C7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.ExternalException
struct  ExternalException_tF3125876B625B17B9682FFEA1AF1B405736E67C7  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXTERNALEXCEPTION_TF3125876B625B17B9682FFEA1AF1B405736E67C7_H
#ifndef RUNTIMEMETHODHANDLE_TB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C_H
#define RUNTIMEMETHODHANDLE_TB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeMethodHandle
struct  RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C 
{
public:
	// System.IntPtr System.RuntimeMethodHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEMETHODHANDLE_TB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C_H
#ifndef STACKOVERFLOWEXCEPTION_T9C66C8F3706481EB823824AC68C392A671E3237F_H
#define STACKOVERFLOWEXCEPTION_T9C66C8F3706481EB823824AC68C392A671E3237F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.StackOverflowException
struct  StackOverflowException_t9C66C8F3706481EB823824AC68C392A671E3237F  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STACKOVERFLOWEXCEPTION_T9C66C8F3706481EB823824AC68C392A671E3237F_H
#ifndef STRINGCOMPARISON_TC242038597DEA220578AA433DD72ECB38D63B7A7_H
#define STRINGCOMPARISON_TC242038597DEA220578AA433DD72ECB38D63B7A7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.StringComparison
struct  StringComparison_tC242038597DEA220578AA433DD72ECB38D63B7A7 
{
public:
	// System.Int32 System.StringComparison::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(StringComparison_tC242038597DEA220578AA433DD72ECB38D63B7A7, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGCOMPARISON_TC242038597DEA220578AA433DD72ECB38D63B7A7_H
#ifndef STRINGSPLITOPTIONS_TCDE8699831D72BF0FBF1E7A23E733187AA169061_H
#define STRINGSPLITOPTIONS_TCDE8699831D72BF0FBF1E7A23E733187AA169061_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.StringSplitOptions
struct  StringSplitOptions_tCDE8699831D72BF0FBF1E7A23E733187AA169061 
{
public:
	// System.Int32 System.StringSplitOptions::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(StringSplitOptions_tCDE8699831D72BF0FBF1E7A23E733187AA169061, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGSPLITOPTIONS_TCDE8699831D72BF0FBF1E7A23E733187AA169061_H
#ifndef TYPECODE_T9946B39DBCEE5FCE73B6C46FB38B432C29904F50_H
#define TYPECODE_T9946B39DBCEE5FCE73B6C46FB38B432C29904F50_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TypeCode
struct  TypeCode_t9946B39DBCEE5FCE73B6C46FB38B432C29904F50 
{
public:
	// System.Int32 System.TypeCode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TypeCode_t9946B39DBCEE5FCE73B6C46FB38B432C29904F50, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPECODE_T9946B39DBCEE5FCE73B6C46FB38B432C29904F50_H
#ifndef TYPEINITIALIZATIONEXCEPTION_TB11D339EF952E54C89496249B4B02C1E2535F9F6_H
#define TYPEINITIALIZATIONEXCEPTION_TB11D339EF952E54C89496249B4B02C1E2535F9F6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TypeInitializationException
struct  TypeInitializationException_tB11D339EF952E54C89496249B4B02C1E2535F9F6  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:
	// System.String System.TypeInitializationException::type_name
	String_t* ___type_name_11;

public:
	inline static int32_t get_offset_of_type_name_11() { return static_cast<int32_t>(offsetof(TypeInitializationException_tB11D339EF952E54C89496249B4B02C1E2535F9F6, ___type_name_11)); }
	inline String_t* get_type_name_11() const { return ___type_name_11; }
	inline String_t** get_address_of_type_name_11() { return &___type_name_11; }
	inline void set_type_name_11(String_t* value)
	{
		___type_name_11 = value;
		Il2CppCodeGenWriteBarrier((&___type_name_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEINITIALIZATIONEXCEPTION_TB11D339EF952E54C89496249B4B02C1E2535F9F6_H
#ifndef TYPELOADEXCEPTION_T11569EED462C1306FB091F7210A9142451786932_H
#define TYPELOADEXCEPTION_T11569EED462C1306FB091F7210A9142451786932_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TypeLoadException
struct  TypeLoadException_t11569EED462C1306FB091F7210A9142451786932  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:
	// System.String System.TypeLoadException::className
	String_t* ___className_12;
	// System.String System.TypeLoadException::assemblyName
	String_t* ___assemblyName_13;

public:
	inline static int32_t get_offset_of_className_12() { return static_cast<int32_t>(offsetof(TypeLoadException_t11569EED462C1306FB091F7210A9142451786932, ___className_12)); }
	inline String_t* get_className_12() const { return ___className_12; }
	inline String_t** get_address_of_className_12() { return &___className_12; }
	inline void set_className_12(String_t* value)
	{
		___className_12 = value;
		Il2CppCodeGenWriteBarrier((&___className_12), value);
	}

	inline static int32_t get_offset_of_assemblyName_13() { return static_cast<int32_t>(offsetof(TypeLoadException_t11569EED462C1306FB091F7210A9142451786932, ___assemblyName_13)); }
	inline String_t* get_assemblyName_13() const { return ___assemblyName_13; }
	inline String_t** get_address_of_assemblyName_13() { return &___assemblyName_13; }
	inline void set_assemblyName_13(String_t* value)
	{
		___assemblyName_13 = value;
		Il2CppCodeGenWriteBarrier((&___assemblyName_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPELOADEXCEPTION_T11569EED462C1306FB091F7210A9142451786932_H
#ifndef UNAUTHORIZEDACCESSEXCEPTION_T593701C7ADFE096EC0340554C2E030FFCEEC369B_H
#define UNAUTHORIZEDACCESSEXCEPTION_T593701C7ADFE096EC0340554C2E030FFCEEC369B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UnauthorizedAccessException
struct  UnauthorizedAccessException_t593701C7ADFE096EC0340554C2E030FFCEEC369B  : public SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNAUTHORIZEDACCESSEXCEPTION_T593701C7ADFE096EC0340554C2E030FFCEEC369B_H
#ifndef UNITYTYPE_T2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E_H
#define UNITYTYPE_T2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UnitySerializationHolder_UnityType
struct  UnityType_t2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E 
{
public:
	// System.Byte System.UnitySerializationHolder_UnityType::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(UnityType_t2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYTYPE_T2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E_H
#ifndef WEAKREFERENCE_T748C76A5CAD65471521659008DBC57191528AA9C_H
#define WEAKREFERENCE_T748C76A5CAD65471521659008DBC57191528AA9C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.WeakReference
struct  WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C  : public RuntimeObject
{
public:
	// System.Boolean System.WeakReference::isLongReference
	bool ___isLongReference_0;
	// System.Runtime.InteropServices.GCHandle System.WeakReference::gcHandle
	GCHandle_tE002D24915851AD73ACC0F503601C384273C3060  ___gcHandle_1;

public:
	inline static int32_t get_offset_of_isLongReference_0() { return static_cast<int32_t>(offsetof(WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C, ___isLongReference_0)); }
	inline bool get_isLongReference_0() const { return ___isLongReference_0; }
	inline bool* get_address_of_isLongReference_0() { return &___isLongReference_0; }
	inline void set_isLongReference_0(bool value)
	{
		___isLongReference_0 = value;
	}

	inline static int32_t get_offset_of_gcHandle_1() { return static_cast<int32_t>(offsetof(WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C, ___gcHandle_1)); }
	inline GCHandle_tE002D24915851AD73ACC0F503601C384273C3060  get_gcHandle_1() const { return ___gcHandle_1; }
	inline GCHandle_tE002D24915851AD73ACC0F503601C384273C3060 * get_address_of_gcHandle_1() { return &___gcHandle_1; }
	inline void set_gcHandle_1(GCHandle_tE002D24915851AD73ACC0F503601C384273C3060  value)
	{
		___gcHandle_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEAKREFERENCE_T748C76A5CAD65471521659008DBC57191528AA9C_H
#ifndef EDITORBROWSABLEATTRIBUTE_T89B76DD408DEC1C18C8B0F2A40836D5728A827DD_H
#define EDITORBROWSABLEATTRIBUTE_T89B76DD408DEC1C18C8B0F2A40836D5728A827DD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.EditorBrowsableAttribute
struct  EditorBrowsableAttribute_t89B76DD408DEC1C18C8B0F2A40836D5728A827DD  : public Attribute_t60F25EB48D5935E4C6C2BAF7F90F57A43528E469
{
public:
	// System.ComponentModel.EditorBrowsableState System.ComponentModel.EditorBrowsableAttribute::state
	int32_t ___state_0;

public:
	inline static int32_t get_offset_of_state_0() { return static_cast<int32_t>(offsetof(EditorBrowsableAttribute_t89B76DD408DEC1C18C8B0F2A40836D5728A827DD, ___state_0)); }
	inline int32_t get_state_0() const { return ___state_0; }
	inline int32_t* get_address_of_state_0() { return &___state_0; }
	inline void set_state_0(int32_t value)
	{
		___state_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EDITORBROWSABLEATTRIBUTE_T89B76DD408DEC1C18C8B0F2A40836D5728A827DD_H
#ifndef WIN32EXCEPTION_T49FE19329E4B4698A554BED1E8C37D0F1A4CC873_H
#define WIN32EXCEPTION_T49FE19329E4B4698A554BED1E8C37D0F1A4CC873_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.Win32Exception
struct  Win32Exception_t49FE19329E4B4698A554BED1E8C37D0F1A4CC873  : public ExternalException_tF3125876B625B17B9682FFEA1AF1B405736E67C7
{
public:
	// System.Int32 System.ComponentModel.Win32Exception::native_error_code
	int32_t ___native_error_code_11;

public:
	inline static int32_t get_offset_of_native_error_code_11() { return static_cast<int32_t>(offsetof(Win32Exception_t49FE19329E4B4698A554BED1E8C37D0F1A4CC873, ___native_error_code_11)); }
	inline int32_t get_native_error_code_11() const { return ___native_error_code_11; }
	inline int32_t* get_address_of_native_error_code_11() { return &___native_error_code_11; }
	inline void set_native_error_code_11(int32_t value)
	{
		___native_error_code_11 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WIN32EXCEPTION_T49FE19329E4B4698A554BED1E8C37D0F1A4CC873_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.MulticastDelegate System.MulticastDelegate::prev
	MulticastDelegate_t * ___prev_9;
	// System.MulticastDelegate System.MulticastDelegate::kpm_next
	MulticastDelegate_t * ___kpm_next_10;

public:
	inline static int32_t get_offset_of_prev_9() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___prev_9)); }
	inline MulticastDelegate_t * get_prev_9() const { return ___prev_9; }
	inline MulticastDelegate_t ** get_address_of_prev_9() { return &___prev_9; }
	inline void set_prev_9(MulticastDelegate_t * value)
	{
		___prev_9 = value;
		Il2CppCodeGenWriteBarrier((&___prev_9), value);
	}

	inline static int32_t get_offset_of_kpm_next_10() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___kpm_next_10)); }
	inline MulticastDelegate_t * get_kpm_next_10() const { return ___kpm_next_10; }
	inline MulticastDelegate_t ** get_address_of_kpm_next_10() { return &___kpm_next_10; }
	inline void set_kpm_next_10(MulticastDelegate_t * value)
	{
		___kpm_next_10 = value;
		Il2CppCodeGenWriteBarrier((&___kpm_next_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTICASTDELEGATE_T_H
#ifndef OBJECTDISPOSEDEXCEPTION_T489A7CB000DC42455F4D79E04F365CD76F298096_H
#define OBJECTDISPOSEDEXCEPTION_T489A7CB000DC42455F4D79E04F365CD76F298096_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ObjectDisposedException
struct  ObjectDisposedException_t489A7CB000DC42455F4D79E04F365CD76F298096  : public InvalidOperationException_tCE0CC6C0C8EE2E780C0736B79AA673751C79CC07
{
public:
	// System.String System.ObjectDisposedException::obj_name
	String_t* ___obj_name_12;
	// System.String System.ObjectDisposedException::msg
	String_t* ___msg_13;

public:
	inline static int32_t get_offset_of_obj_name_12() { return static_cast<int32_t>(offsetof(ObjectDisposedException_t489A7CB000DC42455F4D79E04F365CD76F298096, ___obj_name_12)); }
	inline String_t* get_obj_name_12() const { return ___obj_name_12; }
	inline String_t** get_address_of_obj_name_12() { return &___obj_name_12; }
	inline void set_obj_name_12(String_t* value)
	{
		___obj_name_12 = value;
		Il2CppCodeGenWriteBarrier((&___obj_name_12), value);
	}

	inline static int32_t get_offset_of_msg_13() { return static_cast<int32_t>(offsetof(ObjectDisposedException_t489A7CB000DC42455F4D79E04F365CD76F298096, ___msg_13)); }
	inline String_t* get_msg_13() const { return ___msg_13; }
	inline String_t** get_address_of_msg_13() { return &___msg_13; }
	inline void set_msg_13(String_t* value)
	{
		___msg_13 = value;
		Il2CppCodeGenWriteBarrier((&___msg_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJECTDISPOSEDEXCEPTION_T489A7CB000DC42455F4D79E04F365CD76F298096_H
#ifndef OPERATINGSYSTEM_T4B9C55DF9048A554470600E094D8673A6D10BAAF_H
#define OPERATINGSYSTEM_T4B9C55DF9048A554470600E094D8673A6D10BAAF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.OperatingSystem
struct  OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF  : public RuntimeObject
{
public:
	// System.PlatformID System.OperatingSystem::_platform
	int32_t ____platform_0;
	// System.Version System.OperatingSystem::_version
	Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15 * ____version_1;
	// System.String System.OperatingSystem::_servicePack
	String_t* ____servicePack_2;

public:
	inline static int32_t get_offset_of__platform_0() { return static_cast<int32_t>(offsetof(OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF, ____platform_0)); }
	inline int32_t get__platform_0() const { return ____platform_0; }
	inline int32_t* get_address_of__platform_0() { return &____platform_0; }
	inline void set__platform_0(int32_t value)
	{
		____platform_0 = value;
	}

	inline static int32_t get_offset_of__version_1() { return static_cast<int32_t>(offsetof(OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF, ____version_1)); }
	inline Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15 * get__version_1() const { return ____version_1; }
	inline Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15 ** get_address_of__version_1() { return &____version_1; }
	inline void set__version_1(Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15 * value)
	{
		____version_1 = value;
		Il2CppCodeGenWriteBarrier((&____version_1), value);
	}

	inline static int32_t get_offset_of__servicePack_2() { return static_cast<int32_t>(offsetof(OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF, ____servicePack_2)); }
	inline String_t* get__servicePack_2() const { return ____servicePack_2; }
	inline String_t** get_address_of__servicePack_2() { return &____servicePack_2; }
	inline void set__servicePack_2(String_t* value)
	{
		____servicePack_2 = value;
		Il2CppCodeGenWriteBarrier((&____servicePack_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OPERATINGSYSTEM_T4B9C55DF9048A554470600E094D8673A6D10BAAF_H
#ifndef OVERFLOWEXCEPTION_T0B5FFF1555598D499585564196861996A44507C5_H
#define OVERFLOWEXCEPTION_T0B5FFF1555598D499585564196861996A44507C5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.OverflowException
struct  OverflowException_t0B5FFF1555598D499585564196861996A44507C5  : public ArithmeticException_t1A90923A99EA9AF25291E93082E853313F29DDCD
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OVERFLOWEXCEPTION_T0B5FFF1555598D499585564196861996A44507C5_H
#ifndef PLATFORMNOTSUPPORTEDEXCEPTION_T475195E245D98DFC9B35D12018C6D1287C6E5FC9_H
#define PLATFORMNOTSUPPORTEDEXCEPTION_T475195E245D98DFC9B35D12018C6D1287C6E5FC9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.PlatformNotSupportedException
struct  PlatformNotSupportedException_t475195E245D98DFC9B35D12018C6D1287C6E5FC9  : public NotSupportedException_t8C86714BF66E55D3F33E200FA7C385BC13C7E3B6
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLATFORMNOTSUPPORTEDEXCEPTION_T475195E245D98DFC9B35D12018C6D1287C6E5FC9_H
#ifndef UNITYSERIALIZATIONHOLDER_T1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307_H
#define UNITYSERIALIZATIONHOLDER_T1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UnitySerializationHolder
struct  UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307  : public RuntimeObject
{
public:
	// System.String System.UnitySerializationHolder::_data
	String_t* ____data_0;
	// System.UnitySerializationHolder_UnityType System.UnitySerializationHolder::_unityType
	uint8_t ____unityType_1;
	// System.String System.UnitySerializationHolder::_assemblyName
	String_t* ____assemblyName_2;

public:
	inline static int32_t get_offset_of__data_0() { return static_cast<int32_t>(offsetof(UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307, ____data_0)); }
	inline String_t* get__data_0() const { return ____data_0; }
	inline String_t** get_address_of__data_0() { return &____data_0; }
	inline void set__data_0(String_t* value)
	{
		____data_0 = value;
		Il2CppCodeGenWriteBarrier((&____data_0), value);
	}

	inline static int32_t get_offset_of__unityType_1() { return static_cast<int32_t>(offsetof(UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307, ____unityType_1)); }
	inline uint8_t get__unityType_1() const { return ____unityType_1; }
	inline uint8_t* get_address_of__unityType_1() { return &____unityType_1; }
	inline void set__unityType_1(uint8_t value)
	{
		____unityType_1 = value;
	}

	inline static int32_t get_offset_of__assemblyName_2() { return static_cast<int32_t>(offsetof(UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307, ____assemblyName_2)); }
	inline String_t* get__assemblyName_2() const { return ____assemblyName_2; }
	inline String_t** get_address_of__assemblyName_2() { return &____assemblyName_2; }
	inline void set__assemblyName_2(String_t* value)
	{
		____assemblyName_2 = value;
		Il2CppCodeGenWriteBarrier((&____assemblyName_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYSERIALIZATIONHOLDER_T1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307_H
#ifndef PRIMALITYTEST_TC7A45D00133484065515FE2EFAE8EA3E883E2181_H
#define PRIMALITYTEST_TC7A45D00133484065515FE2EFAE8EA3E883E2181_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Math.Prime.PrimalityTest
struct  PrimalityTest_tC7A45D00133484065515FE2EFAE8EA3E883E2181  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PRIMALITYTEST_TC7A45D00133484065515FE2EFAE8EA3E883E2181_H
#ifndef APPDOMAININITIALIZER_T85B86A5A14418E38A92BC676DC64643FC6DC7180_H
#define APPDOMAININITIALIZER_T85B86A5A14418E38A92BC676DC64643FC6DC7180_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.AppDomainInitializer
struct  AppDomainInitializer_t85B86A5A14418E38A92BC676DC64643FC6DC7180  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // APPDOMAININITIALIZER_T85B86A5A14418E38A92BC676DC64643FC6DC7180_H
#ifndef ASSEMBLYLOADEVENTHANDLER_T4721CB6BD0FB33BE7A898A70CFF1984033AC81F0_H
#define ASSEMBLYLOADEVENTHANDLER_T4721CB6BD0FB33BE7A898A70CFF1984033AC81F0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.AssemblyLoadEventHandler
struct  AssemblyLoadEventHandler_t4721CB6BD0FB33BE7A898A70CFF1984033AC81F0  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYLOADEVENTHANDLER_T4721CB6BD0FB33BE7A898A70CFF1984033AC81F0_H
#ifndef EVENTHANDLER_T743A59DD95D50590C5CC9EBBCAA45C7B753C897D_H
#define EVENTHANDLER_T743A59DD95D50590C5CC9EBBCAA45C7B753C897D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.EventHandler
struct  EventHandler_t743A59DD95D50590C5CC9EBBCAA45C7B753C897D  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EVENTHANDLER_T743A59DD95D50590C5CC9EBBCAA45C7B753C897D_H
#ifndef MEMBERFILTER_T0471813A7FF5255D21A8EA144C5CCF3325274CDE_H
#define MEMBERFILTER_T0471813A7FF5255D21A8EA144C5CCF3325274CDE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MemberFilter
struct  MemberFilter_t0471813A7FF5255D21A8EA144C5CCF3325274CDE  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEMBERFILTER_T0471813A7FF5255D21A8EA144C5CCF3325274CDE_H
#ifndef TYPEFILTER_T302222D6EE873CCA463EAC9F0D6BC173DC63E4DB_H
#define TYPEFILTER_T302222D6EE873CCA463EAC9F0D6BC173DC63E4DB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.TypeFilter
struct  TypeFilter_t302222D6EE873CCA463EAC9F0D6BC173DC63E4DB  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEFILTER_T302222D6EE873CCA463EAC9F0D6BC173DC63E4DB_H
#ifndef RESOLVEEVENTHANDLER_T2D10D8E46E5E5CE30AC98EA4972D9AFA65875E32_H
#define RESOLVEEVENTHANDLER_T2D10D8E46E5E5CE30AC98EA4972D9AFA65875E32_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ResolveEventHandler
struct  ResolveEventHandler_t2D10D8E46E5E5CE30AC98EA4972D9AFA65875E32  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RESOLVEEVENTHANDLER_T2D10D8E46E5E5CE30AC98EA4972D9AFA65875E32_H
#ifndef CROSSCONTEXTDELEGATE_T988967376838550FCB2BE3C60A1FFD10F874E9F2_H
#define CROSSCONTEXTDELEGATE_T988967376838550FCB2BE3C60A1FFD10F874E9F2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Contexts.CrossContextDelegate
struct  CrossContextDelegate_t988967376838550FCB2BE3C60A1FFD10F874E9F2  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CROSSCONTEXTDELEGATE_T988967376838550FCB2BE3C60A1FFD10F874E9F2_H
#ifndef HEADERHANDLER_T332EFCE89BE4BC4530E0DB90678359E55A53825D_H
#define HEADERHANDLER_T332EFCE89BE4BC4530E0DB90678359E55A53825D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.HeaderHandler
struct  HeaderHandler_t332EFCE89BE4BC4530E0DB90678359E55A53825D  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HEADERHANDLER_T332EFCE89BE4BC4530E0DB90678359E55A53825D_H
#ifndef SENDORPOSTCALLBACK_TC8FEC592F9003F412CCA6C59C36E9EDF1F37EDB4_H
#define SENDORPOSTCALLBACK_TC8FEC592F9003F412CCA6C59C36E9EDF1F37EDB4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Threading.SendOrPostCallback
struct  SendOrPostCallback_tC8FEC592F9003F412CCA6C59C36E9EDF1F37EDB4  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SENDORPOSTCALLBACK_TC8FEC592F9003F412CCA6C59C36E9EDF1F37EDB4_H
#ifndef THREADSTART_T76016A96179DE74CE9952BFEEBD38FEA078CC948_H
#define THREADSTART_T76016A96179DE74CE9952BFEEBD38FEA078CC948_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Threading.ThreadStart
struct  ThreadStart_t76016A96179DE74CE9952BFEEBD38FEA078CC948  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // THREADSTART_T76016A96179DE74CE9952BFEEBD38FEA078CC948_H
#ifndef TIMERCALLBACK_T48C36A9BEE6D91BD3FD413A8A648A206A6443115_H
#define TIMERCALLBACK_T48C36A9BEE6D91BD3FD413A8A648A206A6443115_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Threading.TimerCallback
struct  TimerCallback_t48C36A9BEE6D91BD3FD413A8A648A206A6443115  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TIMERCALLBACK_T48C36A9BEE6D91BD3FD413A8A648A206A6443115_H
#ifndef WAITCALLBACK_T55F4591597BB1B3F1CC6CEB6C34E712FDF46FD2B_H
#define WAITCALLBACK_T55F4591597BB1B3F1CC6CEB6C34E712FDF46FD2B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Threading.WaitCallback
struct  WaitCallback_t55F4591597BB1B3F1CC6CEB6C34E712FDF46FD2B  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WAITCALLBACK_T55F4591597BB1B3F1CC6CEB6C34E712FDF46FD2B_H
#ifndef WAITORTIMERCALLBACK_TF703C58E8FE2C7FC5D512223AB86BA0E6FF37298_H
#define WAITORTIMERCALLBACK_TF703C58E8FE2C7FC5D512223AB86BA0E6FF37298_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Threading.WaitOrTimerCallback
struct  WaitOrTimerCallback_tF703C58E8FE2C7FC5D512223AB86BA0E6FF37298  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WAITORTIMERCALLBACK_TF703C58E8FE2C7FC5D512223AB86BA0E6FF37298_H
#ifndef UNHANDLEDEXCEPTIONEVENTHANDLER_TB7988286F96CF5350E4037A92C900D84BB7FB650_H
#define UNHANDLEDEXCEPTIONEVENTHANDLER_TB7988286F96CF5350E4037A92C900D84BB7FB650_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UnhandledExceptionEventHandler
struct  UnhandledExceptionEventHandler_tB7988286F96CF5350E4037A92C900D84BB7FB650  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNHANDLEDEXCEPTIONEVENTHANDLER_TB7988286F96CF5350E4037A92C900D84BB7FB650_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize900 = { sizeof (ObjectDisposedException_t489A7CB000DC42455F4D79E04F365CD76F298096), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable900[2] = 
{
	ObjectDisposedException_t489A7CB000DC42455F4D79E04F365CD76F298096::get_offset_of_obj_name_12(),
	ObjectDisposedException_t489A7CB000DC42455F4D79E04F365CD76F298096::get_offset_of_msg_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize901 = { sizeof (OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable901[3] = 
{
	OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF::get_offset_of__platform_0(),
	OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF::get_offset_of__version_1(),
	OperatingSystem_t4B9C55DF9048A554470600E094D8673A6D10BAAF::get_offset_of__servicePack_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize902 = { sizeof (OutOfMemoryException_tE2918256672960D75F6CB0F244BC1E4F5F77AC5F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable902[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize903 = { sizeof (OverflowException_t0B5FFF1555598D499585564196861996A44507C5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable903[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize904 = { sizeof (PlatformID_t9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable904[8] = 
{
	PlatformID_t9AD50E7F4676B38CD801F98BF8ED948FB23EE7C2::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize905 = { sizeof (PlatformNotSupportedException_t475195E245D98DFC9B35D12018C6D1287C6E5FC9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable905[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize906 = { sizeof (RankException_t02C0FFDDC74AF1EFF7843762CF08142217246395), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize907 = { sizeof (ResolveEventArgs_tCC17EDD2766BA9905006344D9053EFC23C39CEC2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable907[1] = 
{
	ResolveEventArgs_tCC17EDD2766BA9905006344D9053EFC23C39CEC2::get_offset_of_m_Name_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize908 = { sizeof (RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C)+ sizeof (RuntimeObject), sizeof(RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C ), 0, 0 };
extern const int32_t g_FieldOffsetTable908[1] = 
{
	RuntimeMethodHandle_tB74C678BC86CECAD0C2323CA4EDE87FF0FC7660C::get_offset_of_value_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize909 = { sizeof (StackOverflowException_t9C66C8F3706481EB823824AC68C392A671E3237F), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize910 = { sizeof (StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF), -1, sizeof(StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable910[4] = 
{
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields::get_offset_of_invariantCultureIgnoreCase_0(),
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields::get_offset_of_invariantCulture_1(),
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields::get_offset_of_ordinalIgnoreCase_2(),
	StringComparer_t2BD4D768665C1290582CAD7439D03599B59ACCCF_StaticFields::get_offset_of_ordinal_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize911 = { sizeof (CultureAwareComparer_t4FE6CD320A5607CB513A721A468899BAB220844F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable911[2] = 
{
	CultureAwareComparer_t4FE6CD320A5607CB513A721A468899BAB220844F::get_offset_of__ignoreCase_4(),
	CultureAwareComparer_t4FE6CD320A5607CB513A721A468899BAB220844F::get_offset_of__compareInfo_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize912 = { sizeof (OrdinalComparer_t137CD954871758A587130A2D08F0DFCC98D9623D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable912[1] = 
{
	OrdinalComparer_t137CD954871758A587130A2D08F0DFCC98D9623D::get_offset_of__ignoreCase_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize913 = { sizeof (StringComparison_tC242038597DEA220578AA433DD72ECB38D63B7A7)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable913[7] = 
{
	StringComparison_tC242038597DEA220578AA433DD72ECB38D63B7A7::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize914 = { sizeof (StringSplitOptions_tCDE8699831D72BF0FBF1E7A23E733187AA169061)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable914[3] = 
{
	StringSplitOptions_tCDE8699831D72BF0FBF1E7A23E733187AA169061::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize915 = { sizeof (SystemException_t81A06ADD519539D252788D75E44AFFBE6580E301), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize916 = { sizeof (ThreadStaticAttribute_t6D7313EF8DF7B5CC3EFBDA457233386BFCBDBBC8), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize917 = { sizeof (TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374)+ sizeof (RuntimeObject), sizeof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374 ), sizeof(TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable917[4] = 
{
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields::get_offset_of_MaxValue_0(),
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields::get_offset_of_MinValue_1(),
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374_StaticFields::get_offset_of_Zero_2(),
	TimeSpan_t26DE4373EA745C072A5FBDEAD8373348955FC374::get_offset_of__ticks_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize918 = { sizeof (TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB), -1, sizeof(TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable918[3] = 
{
	TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields::get_offset_of_currentTimeZone_0(),
	TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields::get_offset_of_tz_lock_1(),
	TimeZone_tFC833FAA087479460CA3A3EC12FD9EE729BC32EB_StaticFields::get_offset_of_timezone_check_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize919 = { sizeof (CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C), -1, sizeof(CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable919[8] = 
{
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C::get_offset_of_m_standardName_3(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C::get_offset_of_m_daylightName_4(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C::get_offset_of_m_CachedDaylightChanges_5(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C::get_offset_of_m_ticksOffset_6(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C::get_offset_of_utcOffsetWithOutDLS_7(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C::get_offset_of_utcOffsetWithDLS_8(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_StaticFields::get_offset_of_this_year_9(),
	CurrentSystemTimeZone_tD87E60E9158EFBEADF8AF7B9708EC3C13934C09C_StaticFields::get_offset_of_this_year_dlt_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize920 = { sizeof (TypeCode_t9946B39DBCEE5FCE73B6C46FB38B432C29904F50)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable920[19] = 
{
	TypeCode_t9946B39DBCEE5FCE73B6C46FB38B432C29904F50::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize921 = { sizeof (TypeInitializationException_tB11D339EF952E54C89496249B4B02C1E2535F9F6), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable921[1] = 
{
	TypeInitializationException_tB11D339EF952E54C89496249B4B02C1E2535F9F6::get_offset_of_type_name_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize922 = { sizeof (TypeLoadException_t11569EED462C1306FB091F7210A9142451786932), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable922[3] = 
{
	0,
	TypeLoadException_t11569EED462C1306FB091F7210A9142451786932::get_offset_of_className_12(),
	TypeLoadException_t11569EED462C1306FB091F7210A9142451786932::get_offset_of_assemblyName_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize923 = { sizeof (UnauthorizedAccessException_t593701C7ADFE096EC0340554C2E030FFCEEC369B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize924 = { sizeof (UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable924[2] = 
{
	UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2::get_offset_of_exception_1(),
	UnhandledExceptionEventArgs_t2B19479B2BC866C465A8E07BEA9C6027CB168BA2::get_offset_of_m_isTerminating_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize925 = { sizeof (UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable925[3] = 
{
	UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307::get_offset_of__data_0(),
	UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307::get_offset_of__unityType_1(),
	UnitySerializationHolder_t1F3CD67778C9EC0C6F3A05CC6F44A4CC047B7307::get_offset_of__assemblyName_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize926 = { sizeof (UnityType_t2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable926[5] = 
{
	UnityType_t2B30A6EA527F7C6B2CB4B0D8F6D455F828A36E0E::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize927 = { sizeof (Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable927[5] = 
{
	0,
	Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15::get_offset_of__Major_1(),
	Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15::get_offset_of__Minor_2(),
	Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15::get_offset_of__Build_3(),
	Version_tD7D21D8F6BE9CC6473050418AB3D72BA2DB68D15::get_offset_of__Revision_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize928 = { sizeof (WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable928[2] = 
{
	WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C::get_offset_of_isLongReference_0(),
	WeakReference_t748C76A5CAD65471521659008DBC57191528AA9C::get_offset_of_gcHandle_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize929 = { sizeof (PrimalityTest_tC7A45D00133484065515FE2EFAE8EA3E883E2181), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize930 = { sizeof (MemberFilter_t0471813A7FF5255D21A8EA144C5CCF3325274CDE), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize931 = { sizeof (TypeFilter_t302222D6EE873CCA463EAC9F0D6BC173DC63E4DB), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize932 = { sizeof (CrossContextDelegate_t988967376838550FCB2BE3C60A1FFD10F874E9F2), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize933 = { sizeof (HeaderHandler_t332EFCE89BE4BC4530E0DB90678359E55A53825D), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize934 = { sizeof (SendOrPostCallback_tC8FEC592F9003F412CCA6C59C36E9EDF1F37EDB4), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize935 = { sizeof (ThreadStart_t76016A96179DE74CE9952BFEEBD38FEA078CC948), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize936 = { sizeof (TimerCallback_t48C36A9BEE6D91BD3FD413A8A648A206A6443115), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize937 = { sizeof (WaitCallback_t55F4591597BB1B3F1CC6CEB6C34E712FDF46FD2B), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize938 = { sizeof (WaitOrTimerCallback_tF703C58E8FE2C7FC5D512223AB86BA0E6FF37298), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize939 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize940 = { sizeof (AppDomainInitializer_t85B86A5A14418E38A92BC676DC64643FC6DC7180), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize941 = { sizeof (AssemblyLoadEventHandler_t4721CB6BD0FB33BE7A898A70CFF1984033AC81F0), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize942 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize943 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize944 = { sizeof (EventHandler_t743A59DD95D50590C5CC9EBBCAA45C7B753C897D), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize945 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize946 = { sizeof (ResolveEventHandler_t2D10D8E46E5E5CE30AC98EA4972D9AFA65875E32), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize947 = { sizeof (UnhandledExceptionEventHandler_tB7988286F96CF5350E4037A92C900D84BB7FB650), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize948 = { sizeof (U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5), -1, sizeof(U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable948[53] = 
{
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D0_0(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D1_1(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D2_2(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D3_3(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D4_4(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D5_5(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D6_6(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D15_7(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D16_8(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D17_9(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D18_10(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D19_11(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D20_12(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D21_13(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D22_14(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D23_15(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D24_16(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D25_17(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D26_18(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D27_19(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D30_20(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D31_21(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D32_22(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D33_23(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D34_24(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D35_25(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D36_26(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D37_27(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D38_28(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D39_29(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D40_30(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D41_31(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D42_32(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D43_33(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D44_34(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D45_35(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D46_36(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D47_37(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D48_38(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D49_39(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D50_40(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D51_41(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D52_42(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D53_43(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D54_44(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D55_45(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D56_46(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D57_47(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D60_48(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D62_49(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D63_50(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D64_51(),
	U3CPrivateImplementationDetailsU3E_tA4ED71B4CD0039C3F14F9FB6DD26FC4E14C068E5_StaticFields::get_offset_of_U24U24fieldU2D65_52(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize949 = { sizeof (U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2456_t4D07BF30C5C7BEC42BDA1DCA04E13DC715ED4DD4 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize950 = { sizeof (U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2424_tA2F3A0ACEE4D86664B74B589E14D65E7C6DDA796 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize951 = { sizeof (U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2416_t1C56629E747218F497E07A57F1222259FB2A71A6 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize952 = { sizeof (U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU24120_t923D74BAE3631D8AAFEF5370020A7ECBAE2F50AA ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize953 = { sizeof (U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU243132_t5594D874D0815FE7B5383A88C55EFE4DEAB98330 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize954 = { sizeof (U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2420_tF8EBD299D93DB13D787345587B4111D2AB3C6F84 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize955 = { sizeof (U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2432_t10B942E8F73A7895B7944063CCC7F7C7E7D28B6E ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize956 = { sizeof (U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2448_tBC8308884E55B8A3BB11364B84C57853C56760E6 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize957 = { sizeof (U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2464_t8CEBCE84BC90D43EE00405E69D3903D1B1061D3E ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize958 = { sizeof (U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2412_t1947D28EC8E6EA90F7F8187168DBB9CF99F2E1E1 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize959 = { sizeof (U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU24136_t880E5ED037F37EC6E537FC3DAD6261C39866B7B2 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize960 = { sizeof (U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU248_tFA5531B592841F79CB392E5705A7AFDA148DF967 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize961 = { sizeof (U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2472_tB19D67EA47643E3F71021C798A6371C372425517 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize962 = { sizeof (U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU24124_tDF0350FDC99772DAA8899A60F2353B8347DA3F1F ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize963 = { sizeof (U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2496_tF8E7F4B88A264A2D404C41040DA74510A55EE2D2 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize964 = { sizeof (U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU242048_t756B027702A13511CEB867FF431C06E4739A97D8 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize965 = { sizeof (U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU24256_t6DE186CA371FDB3704030BA2B0B08B33014FC6AF ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize966 = { sizeof (U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU241024_t2C0067E321F7E11E00C35CBAD93710B937D40964 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize967 = { sizeof (U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU24640_tD01046A970F55A095E7AD3DB850BE3751511ECDC ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize968 = { sizeof (U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU24128_t8122526FCB3BDC373AE21FD499BBA063D029117F ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize969 = { sizeof (U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU2452_t00AE7364DBCF9E6394820DC15A8131CA5F550952 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize970 = { sizeof (Il2CppComObject), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize971 = { sizeof (__Il2CppComDelegate_t67B66A584C55DA33A97319518FAD9D61A503C4EE), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize972 = { sizeof (U3CModuleU3E_t3D66A8F35F2157DE9E925FB938396AEDA1FB0CA9), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize973 = { sizeof (Locale_tB294B91FA78F6E22E1CCE2B05E5FC1AC28325202), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize974 = { sizeof (MonoTODOAttribute_t9D89F1E822F284972E35E1E9E94CFA0817EFB2CB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable974[1] = 
{
	MonoTODOAttribute_t9D89F1E822F284972E35E1E9E94CFA0817EFB2CB::get_offset_of_comment_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize975 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable975[5] = 
{
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize976 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable976[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize977 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable977[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize978 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable978[5] = 
{
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize979 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable979[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize980 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable980[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize981 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable981[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize982 = { sizeof (HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable982[3] = 
{
	HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747::get_offset_of_caseInsensitive_0(),
	HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747::get_offset_of_hashtable_1(),
	HybridDictionary_t5AD529BFF21493C38235716C9AD62F1F7623C747::get_offset_of_list_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize983 = { sizeof (ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable983[4] = 
{
	ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA::get_offset_of_count_0(),
	ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA::get_offset_of_version_1(),
	ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA::get_offset_of_head_2(),
	ListDictionary_tD949561FF8FD1EBEB444214919203DD41A76ECCA::get_offset_of_comparer_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize984 = { sizeof (DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable984[3] = 
{
	DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973::get_offset_of_key_0(),
	DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973::get_offset_of_value_1(),
	DictionaryNode_tE865C15924F25A7B21066D345799357693CFE973::get_offset_of_next_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize985 = { sizeof (DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable985[4] = 
{
	DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601::get_offset_of_dict_0(),
	DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601::get_offset_of_isAtStart_1(),
	DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601::get_offset_of_current_2(),
	DictionaryNodeEnumerator_tF7AA3F261E0E04587E624470DCC081B4CAB4A601::get_offset_of_version_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize986 = { sizeof (NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable986[10] = 
{
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_ItemsContainer_0(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_NullKeyItem_1(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_ItemsArray_2(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_hashprovider_3(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_comparer_4(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_defCapacity_5(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_m_readonly_6(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_infoCopy_7(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_keyscoll_8(),
	NameObjectCollectionBase_tC2EE4FB130214FAE7365D519959A2A34DE56E070::get_offset_of_equality_comparer_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize987 = { sizeof (_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable987[2] = 
{
	_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7::get_offset_of_key_0(),
	_Item_tFD4BAC90D8E7FF5A3713C2052052BAC018E7CEF7::get_offset_of_value_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize988 = { sizeof (_KeysEnumerator_t831ED8844B7FCA44E39D0121A1EC06B3AE76941E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable988[2] = 
{
	_KeysEnumerator_t831ED8844B7FCA44E39D0121A1EC06B3AE76941E::get_offset_of_m_collection_0(),
	_KeysEnumerator_t831ED8844B7FCA44E39D0121A1EC06B3AE76941E::get_offset_of_m_position_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize989 = { sizeof (KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable989[1] = 
{
	KeysCollection_t3A1987CE62992069C60E21F2F157579EFBB7FDDB::get_offset_of_m_collection_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize990 = { sizeof (NameValueCollection_tB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable990[2] = 
{
	NameValueCollection_tB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF::get_offset_of_cachedAllKeys_10(),
	NameValueCollection_tB87E7DD2A8341E8E48EEC4D39322C1CE72E103EF::get_offset_of_cachedAll_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize991 = { sizeof (EditorBrowsableAttribute_t89B76DD408DEC1C18C8B0F2A40836D5728A827DD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable991[1] = 
{
	EditorBrowsableAttribute_t89B76DD408DEC1C18C8B0F2A40836D5728A827DD::get_offset_of_state_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize992 = { sizeof (EditorBrowsableState_t29045763CB3BEAC19254BB89EEF28ECA6A824E22)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable992[4] = 
{
	EditorBrowsableState_t29045763CB3BEAC19254BB89EEF28ECA6A824E22::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize993 = { sizeof (TypeConverter_t5801C9F7100E1D849000ED0914E01E4CB2541B71), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize994 = { sizeof (TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27), -1, sizeof(TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable994[2] = 
{
	TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27_StaticFields::get_offset_of_Default_0(),
	TypeConverterAttribute_tC7B95DB483CF95DC3E325F90964995E1939B4E27::get_offset_of_converter_type_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize995 = { sizeof (Win32Exception_t49FE19329E4B4698A554BED1E8C37D0F1A4CC873), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable995[1] = 
{
	Win32Exception_t49FE19329E4B4698A554BED1E8C37D0F1A4CC873::get_offset_of_native_error_code_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize996 = { sizeof (AuthenticationLevel_tDD7C55ABAF179BD6273AA3DC6AC59A265B006E17)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable996[4] = 
{
	AuthenticationLevel_tDD7C55ABAF179BD6273AA3DC6AC59A265B006E17::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize997 = { sizeof (SslPolicyErrors_t821E0247A29EDB8CD8327153A81349E907DBE6E9)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable997[5] = 
{
	SslPolicyErrors_t821E0247A29EDB8CD8327153A81349E907DBE6E9::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize998 = { sizeof (AddressFamily_t56E41B784F73C1D53BE91A309AB9E5A35F947876)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable998[32] = 
{
	AddressFamily_t56E41B784F73C1D53BE91A309AB9E5A35F947876::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize999 = { sizeof (LingerOption_t62B714AFE2251DFCF0B64F164C08A8A533EE1267), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable999[2] = 
{
	LingerOption_t62B714AFE2251DFCF0B64F164C08A8A533EE1267::get_offset_of_enabled_0(),
	LingerOption_t62B714AFE2251DFCF0B64F164C08A8A533EE1267::get_offset_of_seconds_1(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
