﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// Boundary
struct Boundary_t524EE905C1329FEB0BA75BFEB4B1A6E15B155779;
// DisplayRankings
struct DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265;
// EnvMapAnimator
struct EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73;
// HumbleMovement
struct HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C;
// IUnityService
struct IUnityService_t0EAE7AE1CC6EE81ABA46281945A052D605CF3286;
// PlayerShip
struct PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158;
// Puppetry.Puppet.Contracts.DriverRequest
struct DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54;
// Puppetry.Puppet.DriverHandler/<HandleDriverRequest>c__AnonStorey1
struct U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885;
// RankingManager
struct RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5;
// Ranking[]
struct RankingU5BU5D_tF69C11F82420CCB8330D1331FF0B5B914556949D;
// System.Action
struct Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21;
// System.Char[]
struct CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744;
// System.Collections.Generic.Dictionary`2<System.String,System.Int32>
struct Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1;
// System.Collections.Generic.List`1<CustomObject>
struct List_1_t99FDB733A99492B0B8925E98134406016B269FB7;
// System.Collections.Generic.List`1<Sound>
struct List_1_t4B3595BCFD01CD62DAF26342761E57EA20AAC3E7;
// System.Collections.Generic.List`1<System.Action>
struct List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE;
// System.Collections.Generic.List`1<UnityEngine.Transform>
struct List_1_t1863EF4EE1FDEED14D460C85AF61BE0850892F6D;
// System.Func`1<System.String>
struct Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220;
// System.Func`2<CustomObject,System.Int32>
struct Func_2_t762C596D906C081DEAB6A6125C7EC9900AEBD588;
// System.Func`2<Ranking,System.Int32>
struct Func_2_tB345E72356ED3DD90BBA4049309FD04BEC430306;
// System.Func`2<System.Collections.Generic.List`1<UnityEngine.GameObject>,System.String>
struct Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2;
// System.Func`2<UnityEngine.GameObject,System.String>
struct Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C;
// System.Int32[]
struct Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074;
// System.Net.Sockets.TcpClient
struct TcpClient_tC0F2BB1744837FB736E2C4A97F61C6DFFD36CBF8;
// System.String
struct String_t;
// System.Threading.AutoResetEvent
struct AutoResetEvent_t332410718633EC57126829912EE4C000906421EB;
// System.Threading.Thread
struct Thread_t83C301EC970792455F76D89E58140949B003EA50;
// System.Void
struct Void_tDB81A15FA2AB53E2401A76B745D215397B29F783;
// TMPro.Examples.Benchmark01
struct Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761;
// TMPro.Examples.Benchmark01_UGUI
struct Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55;
// TMPro.Examples.ShaderPropAnimator
struct ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72;
// TMPro.Examples.SkewTextExample
struct SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7;
// TMPro.Examples.TeleType
struct TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716;
// TMPro.Examples.TextConsoleSimulator
struct TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163;
// TMPro.Examples.TextMeshProFloatingText
struct TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913;
// TMPro.TMP_FontAsset
struct TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C;
// TMPro.TMP_InputField
struct TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB;
// TMPro.TMP_Text
struct TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7;
// TMPro.TMP_TextEventHandler
struct TMP_TextEventHandler_t6046295E0F06C5138916541DBE6B476E6FE66B54;
// TMPro.TMP_TextInfo
struct TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181;
// TMPro.TextContainer
struct TextContainer_tF5E5EB56D152102B19C27607F84847CA594391DE;
// TMPro.TextMeshPro
struct TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2;
// TMPro.TextMeshProUGUI
struct TextMeshProUGUI_tBA60B913AB6151F8563F7078AD67EB6458129438;
// UnityEngine.AnimationCurve
struct AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C;
// UnityEngine.AudioClip
struct AudioClip_tCC3C35F579203CE2601243585AB3D6953C3BA051;
// UnityEngine.AudioSource
struct AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.Canvas
struct Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591;
// UnityEngine.EventSystems.PointerEventData
struct PointerEventData_tC18994283B7753E430E316A62D9E45BA6D644C63;
// UnityEngine.Font
struct Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.GameObject[]
struct GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520;
// UnityEngine.Material
struct Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598;
// UnityEngine.Networking.UnityWebRequest
struct UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129;
// UnityEngine.Renderer
struct Renderer_t0556D67DD582620D1F495627EDE30D03284151F4;
// UnityEngine.TextMesh
struct TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A;
// UnityEngine.Transform
struct Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA;
// UnityEngine.UI.Button
struct Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B;
// UnityEngine.UI.Image
struct Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E;
// UnityEngine.UI.InputField
struct InputField_t533609195B110760BCFF00B746C87D81969CB005;
// UnityEngine.UI.Scrollbar
struct Scrollbar_t8F8679D0EAFACBCBD603E6B0E741E6A783DB3389;
// UnityEngine.UI.Text
struct Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28;




#ifndef U3CMODULEU3E_T6CDDDF959E7E18A6744E43B613F41CDAC780256A_H
#define U3CMODULEU3E_T6CDDDF959E7E18A6744E43B613F41CDAC780256A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t6CDDDF959E7E18A6744E43B613F41CDAC780256A 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T6CDDDF959E7E18A6744E43B613F41CDAC780256A_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef U3CREFRESHU3EC__ITERATOR0_T491A3481D3E1363C2F2E126516D088D0D19082F4_H
#define U3CREFRESHU3EC__ITERATOR0_T491A3481D3E1363C2F2E126516D088D0D19082F4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// DisplayRankings_<Refresh>c__Iterator0
struct  U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4  : public RuntimeObject
{
public:
	// DisplayRankings DisplayRankings_<Refresh>c__Iterator0::U24this
	DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 * ___U24this_0;
	// System.Object DisplayRankings_<Refresh>c__Iterator0::U24current
	RuntimeObject * ___U24current_1;
	// System.Boolean DisplayRankings_<Refresh>c__Iterator0::U24disposing
	bool ___U24disposing_2;
	// System.Int32 DisplayRankings_<Refresh>c__Iterator0::U24PC
	int32_t ___U24PC_3;

public:
	inline static int32_t get_offset_of_U24this_0() { return static_cast<int32_t>(offsetof(U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4, ___U24this_0)); }
	inline DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 * get_U24this_0() const { return ___U24this_0; }
	inline DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 ** get_address_of_U24this_0() { return &___U24this_0; }
	inline void set_U24this_0(DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 * value)
	{
		___U24this_0 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_0), value);
	}

	inline static int32_t get_offset_of_U24current_1() { return static_cast<int32_t>(offsetof(U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4, ___U24current_1)); }
	inline RuntimeObject * get_U24current_1() const { return ___U24current_1; }
	inline RuntimeObject ** get_address_of_U24current_1() { return &___U24current_1; }
	inline void set_U24current_1(RuntimeObject * value)
	{
		___U24current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_1), value);
	}

	inline static int32_t get_offset_of_U24disposing_2() { return static_cast<int32_t>(offsetof(U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4, ___U24disposing_2)); }
	inline bool get_U24disposing_2() const { return ___U24disposing_2; }
	inline bool* get_address_of_U24disposing_2() { return &___U24disposing_2; }
	inline void set_U24disposing_2(bool value)
	{
		___U24disposing_2 = value;
	}

	inline static int32_t get_offset_of_U24PC_3() { return static_cast<int32_t>(offsetof(U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4, ___U24PC_3)); }
	inline int32_t get_U24PC_3() const { return ___U24PC_3; }
	inline int32_t* get_address_of_U24PC_3() { return &___U24PC_3; }
	inline void set_U24PC_3(int32_t value)
	{
		___U24PC_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREFRESHU3EC__ITERATOR0_T491A3481D3E1363C2F2E126516D088D0D19082F4_H
#ifndef U3CDISABLEOBJECTU3EC__ITERATOR1_T336C5B2D046246A629236BA814DA0D3C09D14A22_H
#define U3CDISABLEOBJECTU3EC__ITERATOR1_T336C5B2D046246A629236BA814DA0D3C09D14A22_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// GameManager_<DisableObject>c__Iterator1
struct  U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22  : public RuntimeObject
{
public:
	// System.Single GameManager_<DisableObject>c__Iterator1::time
	float ___time_0;
	// UnityEngine.GameObject GameManager_<DisableObject>c__Iterator1::go
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go_1;
	// System.Object GameManager_<DisableObject>c__Iterator1::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean GameManager_<DisableObject>c__Iterator1::U24disposing
	bool ___U24disposing_3;
	// System.Int32 GameManager_<DisableObject>c__Iterator1::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_time_0() { return static_cast<int32_t>(offsetof(U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22, ___time_0)); }
	inline float get_time_0() const { return ___time_0; }
	inline float* get_address_of_time_0() { return &___time_0; }
	inline void set_time_0(float value)
	{
		___time_0 = value;
	}

	inline static int32_t get_offset_of_go_1() { return static_cast<int32_t>(offsetof(U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22, ___go_1)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_go_1() const { return ___go_1; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_go_1() { return &___go_1; }
	inline void set_go_1(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___go_1 = value;
		Il2CppCodeGenWriteBarrier((&___go_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDISABLEOBJECTU3EC__ITERATOR1_T336C5B2D046246A629236BA814DA0D3C09D14A22_H
#ifndef U3CSHOWOBJECTU3EC__ITERATOR0_TE22CD38779E13CD2EF83A3074FDC7791AB8731BC_H
#define U3CSHOWOBJECTU3EC__ITERATOR0_TE22CD38779E13CD2EF83A3074FDC7791AB8731BC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// GameManager_<ShowObject>c__Iterator0
struct  U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC  : public RuntimeObject
{
public:
	// System.Single GameManager_<ShowObject>c__Iterator0::time
	float ___time_0;
	// UnityEngine.GameObject GameManager_<ShowObject>c__Iterator0::go
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go_1;
	// System.Object GameManager_<ShowObject>c__Iterator0::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean GameManager_<ShowObject>c__Iterator0::U24disposing
	bool ___U24disposing_3;
	// System.Int32 GameManager_<ShowObject>c__Iterator0::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_time_0() { return static_cast<int32_t>(offsetof(U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC, ___time_0)); }
	inline float get_time_0() const { return ___time_0; }
	inline float* get_address_of_time_0() { return &___time_0; }
	inline void set_time_0(float value)
	{
		___time_0 = value;
	}

	inline static int32_t get_offset_of_go_1() { return static_cast<int32_t>(offsetof(U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC, ___go_1)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_go_1() const { return ___go_1; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_go_1() { return &___go_1; }
	inline void set_go_1(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___go_1 = value;
		Il2CppCodeGenWriteBarrier((&___go_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSHOWOBJECTU3EC__ITERATOR0_TE22CD38779E13CD2EF83A3074FDC7791AB8731BC_H
#ifndef HUMBLEMOVEMENT_T04AB4236479ACEDFD7458821DD750DCB0CFAC30C_H
#define HUMBLEMOVEMENT_T04AB4236479ACEDFD7458821DD750DCB0CFAC30C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// HumbleMovement
struct  HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C  : public RuntimeObject
{
public:
	// System.Single HumbleMovement::speed
	float ___speed_0;

public:
	inline static int32_t get_offset_of_speed_0() { return static_cast<int32_t>(offsetof(HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C, ___speed_0)); }
	inline float get_speed_0() const { return ___speed_0; }
	inline float* get_address_of_speed_0() { return &___speed_0; }
	inline void set_speed_0(float value)
	{
		___speed_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HUMBLEMOVEMENT_T04AB4236479ACEDFD7458821DD750DCB0CFAC30C_H
#ifndef U3CRELOADNUMMISSILESU3EC__ITERATOR0_TEBB6F5C5B352C279E3B41396E713A35F2B9FC496_H
#define U3CRELOADNUMMISSILESU3EC__ITERATOR0_TEBB6F5C5B352C279E3B41396E713A35F2B9FC496_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayerShip_<ReloadNumMissiles>c__Iterator0
struct  U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496  : public RuntimeObject
{
public:
	// PlayerShip PlayerShip_<ReloadNumMissiles>c__Iterator0::U24this
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158 * ___U24this_0;
	// System.Object PlayerShip_<ReloadNumMissiles>c__Iterator0::U24current
	RuntimeObject * ___U24current_1;
	// System.Boolean PlayerShip_<ReloadNumMissiles>c__Iterator0::U24disposing
	bool ___U24disposing_2;
	// System.Int32 PlayerShip_<ReloadNumMissiles>c__Iterator0::U24PC
	int32_t ___U24PC_3;

public:
	inline static int32_t get_offset_of_U24this_0() { return static_cast<int32_t>(offsetof(U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496, ___U24this_0)); }
	inline PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158 * get_U24this_0() const { return ___U24this_0; }
	inline PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158 ** get_address_of_U24this_0() { return &___U24this_0; }
	inline void set_U24this_0(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158 * value)
	{
		___U24this_0 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_0), value);
	}

	inline static int32_t get_offset_of_U24current_1() { return static_cast<int32_t>(offsetof(U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496, ___U24current_1)); }
	inline RuntimeObject * get_U24current_1() const { return ___U24current_1; }
	inline RuntimeObject ** get_address_of_U24current_1() { return &___U24current_1; }
	inline void set_U24current_1(RuntimeObject * value)
	{
		___U24current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_1), value);
	}

	inline static int32_t get_offset_of_U24disposing_2() { return static_cast<int32_t>(offsetof(U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496, ___U24disposing_2)); }
	inline bool get_U24disposing_2() const { return ___U24disposing_2; }
	inline bool* get_address_of_U24disposing_2() { return &___U24disposing_2; }
	inline void set_U24disposing_2(bool value)
	{
		___U24disposing_2 = value;
	}

	inline static int32_t get_offset_of_U24PC_3() { return static_cast<int32_t>(offsetof(U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496, ___U24PC_3)); }
	inline int32_t get_U24PC_3() const { return ___U24PC_3; }
	inline int32_t* get_address_of_U24PC_3() { return &___U24PC_3; }
	inline void set_U24PC_3(int32_t value)
	{
		___U24PC_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CRELOADNUMMISSILESU3EC__ITERATOR0_TEBB6F5C5B352C279E3B41396E713A35F2B9FC496_H
#ifndef DRIVERREQUEST_TA1CDE9FCC919C41546154F2D8917254371889A54_H
#define DRIVERREQUEST_TA1CDE9FCC919C41546154F2D8917254371889A54_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.Contracts.DriverRequest
struct  DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54  : public RuntimeObject
{
public:
	// System.String Puppetry.Puppet.Contracts.DriverRequest::session
	String_t* ___session_0;
	// System.String Puppetry.Puppet.Contracts.DriverRequest::method
	String_t* ___method_1;
	// System.String Puppetry.Puppet.Contracts.DriverRequest::upath
	String_t* ___upath_2;
	// System.String Puppetry.Puppet.Contracts.DriverRequest::key
	String_t* ___key_3;
	// System.String Puppetry.Puppet.Contracts.DriverRequest::value
	String_t* ___value_4;

public:
	inline static int32_t get_offset_of_session_0() { return static_cast<int32_t>(offsetof(DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54, ___session_0)); }
	inline String_t* get_session_0() const { return ___session_0; }
	inline String_t** get_address_of_session_0() { return &___session_0; }
	inline void set_session_0(String_t* value)
	{
		___session_0 = value;
		Il2CppCodeGenWriteBarrier((&___session_0), value);
	}

	inline static int32_t get_offset_of_method_1() { return static_cast<int32_t>(offsetof(DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54, ___method_1)); }
	inline String_t* get_method_1() const { return ___method_1; }
	inline String_t** get_address_of_method_1() { return &___method_1; }
	inline void set_method_1(String_t* value)
	{
		___method_1 = value;
		Il2CppCodeGenWriteBarrier((&___method_1), value);
	}

	inline static int32_t get_offset_of_upath_2() { return static_cast<int32_t>(offsetof(DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54, ___upath_2)); }
	inline String_t* get_upath_2() const { return ___upath_2; }
	inline String_t** get_address_of_upath_2() { return &___upath_2; }
	inline void set_upath_2(String_t* value)
	{
		___upath_2 = value;
		Il2CppCodeGenWriteBarrier((&___upath_2), value);
	}

	inline static int32_t get_offset_of_key_3() { return static_cast<int32_t>(offsetof(DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54, ___key_3)); }
	inline String_t* get_key_3() const { return ___key_3; }
	inline String_t** get_address_of_key_3() { return &___key_3; }
	inline void set_key_3(String_t* value)
	{
		___key_3 = value;
		Il2CppCodeGenWriteBarrier((&___key_3), value);
	}

	inline static int32_t get_offset_of_value_4() { return static_cast<int32_t>(offsetof(DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54, ___value_4)); }
	inline String_t* get_value_4() const { return ___value_4; }
	inline String_t** get_address_of_value_4() { return &___value_4; }
	inline void set_value_4(String_t* value)
	{
		___value_4 = value;
		Il2CppCodeGenWriteBarrier((&___value_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DRIVERREQUEST_TA1CDE9FCC919C41546154F2D8917254371889A54_H
#ifndef DRIVERRESPONSE_TC7A742E830EC85DB946EC52B6FECF22708129B9D_H
#define DRIVERRESPONSE_TC7A742E830EC85DB946EC52B6FECF22708129B9D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.Contracts.DriverResponse
struct  DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D  : public RuntimeObject
{
public:
	// System.String Puppetry.Puppet.Contracts.DriverResponse::session
	String_t* ___session_0;
	// System.String Puppetry.Puppet.Contracts.DriverResponse::method
	String_t* ___method_1;
	// System.String Puppetry.Puppet.Contracts.DriverResponse::result
	String_t* ___result_2;
	// System.String Puppetry.Puppet.Contracts.DriverResponse::errormessage
	String_t* ___errormessage_3;
	// System.Int32 Puppetry.Puppet.Contracts.DriverResponse::statuscode
	int32_t ___statuscode_4;

public:
	inline static int32_t get_offset_of_session_0() { return static_cast<int32_t>(offsetof(DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D, ___session_0)); }
	inline String_t* get_session_0() const { return ___session_0; }
	inline String_t** get_address_of_session_0() { return &___session_0; }
	inline void set_session_0(String_t* value)
	{
		___session_0 = value;
		Il2CppCodeGenWriteBarrier((&___session_0), value);
	}

	inline static int32_t get_offset_of_method_1() { return static_cast<int32_t>(offsetof(DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D, ___method_1)); }
	inline String_t* get_method_1() const { return ___method_1; }
	inline String_t** get_address_of_method_1() { return &___method_1; }
	inline void set_method_1(String_t* value)
	{
		___method_1 = value;
		Il2CppCodeGenWriteBarrier((&___method_1), value);
	}

	inline static int32_t get_offset_of_result_2() { return static_cast<int32_t>(offsetof(DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D, ___result_2)); }
	inline String_t* get_result_2() const { return ___result_2; }
	inline String_t** get_address_of_result_2() { return &___result_2; }
	inline void set_result_2(String_t* value)
	{
		___result_2 = value;
		Il2CppCodeGenWriteBarrier((&___result_2), value);
	}

	inline static int32_t get_offset_of_errormessage_3() { return static_cast<int32_t>(offsetof(DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D, ___errormessage_3)); }
	inline String_t* get_errormessage_3() const { return ___errormessage_3; }
	inline String_t** get_address_of_errormessage_3() { return &___errormessage_3; }
	inline void set_errormessage_3(String_t* value)
	{
		___errormessage_3 = value;
		Il2CppCodeGenWriteBarrier((&___errormessage_3), value);
	}

	inline static int32_t get_offset_of_statuscode_4() { return static_cast<int32_t>(offsetof(DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D, ___statuscode_4)); }
	inline int32_t get_statuscode_4() const { return ___statuscode_4; }
	inline int32_t* get_address_of_statuscode_4() { return &___statuscode_4; }
	inline void set_statuscode_4(int32_t value)
	{
		___statuscode_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DRIVERRESPONSE_TC7A742E830EC85DB946EC52B6FECF22708129B9D_H
#ifndef ERRORMESSAGES_TC2C6195E8704C009FCC56F8A8E09CE2F6DB02172_H
#define ERRORMESSAGES_TC2C6195E8704C009FCC56F8A8E09CE2F6DB02172_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.Contracts.ErrorMessages
struct  ErrorMessages_tC2C6195E8704C009FCC56F8A8E09CE2F6DB02172  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERRORMESSAGES_TC2C6195E8704C009FCC56F8A8E09CE2F6DB02172_H
#ifndef SCREENCOORDINATES_TB5F27E411B2685288432A8C0F450795E3B508AA0_H
#define SCREENCOORDINATES_TB5F27E411B2685288432A8C0F450795E3B508AA0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.Contracts.ScreenCoordinates
struct  ScreenCoordinates_tB5F27E411B2685288432A8C0F450795E3B508AA0  : public RuntimeObject
{
public:
	// System.Single Puppetry.Puppet.Contracts.ScreenCoordinates::X
	float ___X_0;
	// System.Single Puppetry.Puppet.Contracts.ScreenCoordinates::Y
	float ___Y_1;

public:
	inline static int32_t get_offset_of_X_0() { return static_cast<int32_t>(offsetof(ScreenCoordinates_tB5F27E411B2685288432A8C0F450795E3B508AA0, ___X_0)); }
	inline float get_X_0() const { return ___X_0; }
	inline float* get_address_of_X_0() { return &___X_0; }
	inline void set_X_0(float value)
	{
		___X_0 = value;
	}

	inline static int32_t get_offset_of_Y_1() { return static_cast<int32_t>(offsetof(ScreenCoordinates_tB5F27E411B2685288432A8C0F450795E3B508AA0, ___Y_1)); }
	inline float get_Y_1() const { return ___Y_1; }
	inline float* get_address_of_Y_1() { return &___Y_1; }
	inline void set_Y_1(float value)
	{
		___Y_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENCOORDINATES_TB5F27E411B2685288432A8C0F450795E3B508AA0_H
#ifndef SESSIONINFO_T78925ED0E6155BB75F0C07C5082BFEAC4989A14D_H
#define SESSIONINFO_T78925ED0E6155BB75F0C07C5082BFEAC4989A14D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.Contracts.SessionInfo
struct  SessionInfo_t78925ED0E6155BB75F0C07C5082BFEAC4989A14D  : public RuntimeObject
{
public:
	// System.String Puppetry.Puppet.Contracts.SessionInfo::Session
	String_t* ___Session_0;

public:
	inline static int32_t get_offset_of_Session_0() { return static_cast<int32_t>(offsetof(SessionInfo_t78925ED0E6155BB75F0C07C5082BFEAC4989A14D, ___Session_0)); }
	inline String_t* get_Session_0() const { return ___Session_0; }
	inline String_t** get_address_of_Session_0() { return &___Session_0; }
	inline void set_Session_0(String_t* value)
	{
		___Session_0 = value;
		Il2CppCodeGenWriteBarrier((&___Session_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SESSIONINFO_T78925ED0E6155BB75F0C07C5082BFEAC4989A14D_H
#ifndef CUSTOMDRIVERHANDLER_T58C1D7FF0BDE8F720704B1507BFDDC40340FBC52_H
#define CUSTOMDRIVERHANDLER_T58C1D7FF0BDE8F720704B1507BFDDC40340FBC52_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.CustomDriverHandler
struct  CustomDriverHandler_t58C1D7FF0BDE8F720704B1507BFDDC40340FBC52  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CUSTOMDRIVERHANDLER_T58C1D7FF0BDE8F720704B1507BFDDC40340FBC52_H
#ifndef DRIVERAPICLIENT_TEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_H
#define DRIVERAPICLIENT_TEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.DriverApiClient
struct  DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07  : public RuntimeObject
{
public:
	// System.Threading.Thread Puppetry.Puppet.DriverApiClient::_thread
	Thread_t83C301EC970792455F76D89E58140949B003EA50 * ____thread_1;
	// System.Net.Sockets.TcpClient Puppetry.Puppet.DriverApiClient::_client
	TcpClient_tC0F2BB1744837FB736E2C4A97F61C6DFFD36CBF8 * ____client_2;
	// System.Int32 Puppetry.Puppet.DriverApiClient::<Port>k__BackingField
	int32_t ___U3CPortU3Ek__BackingField_4;
	// System.String Puppetry.Puppet.DriverApiClient::<IpAddress>k__BackingField
	String_t* ___U3CIpAddressU3Ek__BackingField_5;

public:
	inline static int32_t get_offset_of__thread_1() { return static_cast<int32_t>(offsetof(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07, ____thread_1)); }
	inline Thread_t83C301EC970792455F76D89E58140949B003EA50 * get__thread_1() const { return ____thread_1; }
	inline Thread_t83C301EC970792455F76D89E58140949B003EA50 ** get_address_of__thread_1() { return &____thread_1; }
	inline void set__thread_1(Thread_t83C301EC970792455F76D89E58140949B003EA50 * value)
	{
		____thread_1 = value;
		Il2CppCodeGenWriteBarrier((&____thread_1), value);
	}

	inline static int32_t get_offset_of__client_2() { return static_cast<int32_t>(offsetof(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07, ____client_2)); }
	inline TcpClient_tC0F2BB1744837FB736E2C4A97F61C6DFFD36CBF8 * get__client_2() const { return ____client_2; }
	inline TcpClient_tC0F2BB1744837FB736E2C4A97F61C6DFFD36CBF8 ** get_address_of__client_2() { return &____client_2; }
	inline void set__client_2(TcpClient_tC0F2BB1744837FB736E2C4A97F61C6DFFD36CBF8 * value)
	{
		____client_2 = value;
		Il2CppCodeGenWriteBarrier((&____client_2), value);
	}

	inline static int32_t get_offset_of_U3CPortU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07, ___U3CPortU3Ek__BackingField_4)); }
	inline int32_t get_U3CPortU3Ek__BackingField_4() const { return ___U3CPortU3Ek__BackingField_4; }
	inline int32_t* get_address_of_U3CPortU3Ek__BackingField_4() { return &___U3CPortU3Ek__BackingField_4; }
	inline void set_U3CPortU3Ek__BackingField_4(int32_t value)
	{
		___U3CPortU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_U3CIpAddressU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07, ___U3CIpAddressU3Ek__BackingField_5)); }
	inline String_t* get_U3CIpAddressU3Ek__BackingField_5() const { return ___U3CIpAddressU3Ek__BackingField_5; }
	inline String_t** get_address_of_U3CIpAddressU3Ek__BackingField_5() { return &___U3CIpAddressU3Ek__BackingField_5; }
	inline void set_U3CIpAddressU3Ek__BackingField_5(String_t* value)
	{
		___U3CIpAddressU3Ek__BackingField_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CIpAddressU3Ek__BackingField_5), value);
	}
};

struct DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_StaticFields
{
public:
	// Puppetry.Puppet.DriverApiClient Puppetry.Puppet.DriverApiClient::_instance
	DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07 * ____instance_3;

public:
	inline static int32_t get_offset_of__instance_3() { return static_cast<int32_t>(offsetof(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_StaticFields, ____instance_3)); }
	inline DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07 * get__instance_3() const { return ____instance_3; }
	inline DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07 ** get_address_of__instance_3() { return &____instance_3; }
	inline void set__instance_3(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07 * value)
	{
		____instance_3 = value;
		Il2CppCodeGenWriteBarrier((&____instance_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DRIVERAPICLIENT_TEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_H
#ifndef DRIVERHANDLER_T32101232D25D40AA9AC96264AF3CD15F9BAB3229_H
#define DRIVERHANDLER_T32101232D25D40AA9AC96264AF3CD15F9BAB3229_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.DriverHandler
struct  DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229  : public RuntimeObject
{
public:

public:
};

struct DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> Puppetry.Puppet.DriverHandler::<>f__switchU24map0
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map0_0;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache0
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache0_1;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache1
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache1_2;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache2
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache2_3;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache3
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache3_4;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache4
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache4_5;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache5
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache5_6;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache6
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache6_7;
	// System.Func`2<System.Collections.Generic.List`1<UnityEngine.GameObject>,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache7
	Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 * ___U3CU3Ef__amU24cache7_8;
	// System.Action Puppetry.Puppet.DriverHandler::<>f__amU24cache8
	Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 * ___U3CU3Ef__amU24cache8_9;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cache9
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___U3CU3Ef__amU24cache9_10;
	// System.Func`1<System.String> Puppetry.Puppet.DriverHandler::<>f__amU24cacheA
	Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 * ___U3CU3Ef__amU24cacheA_11;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map0_0() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__switchU24map0_0)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map0_0() const { return ___U3CU3Ef__switchU24map0_0; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map0_0() { return &___U3CU3Ef__switchU24map0_0; }
	inline void set_U3CU3Ef__switchU24map0_0(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map0_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_1() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache0_1)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache0_1() const { return ___U3CU3Ef__amU24cache0_1; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache0_1() { return &___U3CU3Ef__amU24cache0_1; }
	inline void set_U3CU3Ef__amU24cache0_1(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_1), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache1_2() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache1_2)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache1_2() const { return ___U3CU3Ef__amU24cache1_2; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache1_2() { return &___U3CU3Ef__amU24cache1_2; }
	inline void set_U3CU3Ef__amU24cache1_2(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache1_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache1_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache2_3() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache2_3)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache2_3() const { return ___U3CU3Ef__amU24cache2_3; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache2_3() { return &___U3CU3Ef__amU24cache2_3; }
	inline void set_U3CU3Ef__amU24cache2_3(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache2_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache2_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache3_4() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache3_4)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache3_4() const { return ___U3CU3Ef__amU24cache3_4; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache3_4() { return &___U3CU3Ef__amU24cache3_4; }
	inline void set_U3CU3Ef__amU24cache3_4(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache3_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache3_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache4_5() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache4_5)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache4_5() const { return ___U3CU3Ef__amU24cache4_5; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache4_5() { return &___U3CU3Ef__amU24cache4_5; }
	inline void set_U3CU3Ef__amU24cache4_5(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache4_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache4_5), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache5_6() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache5_6)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache5_6() const { return ___U3CU3Ef__amU24cache5_6; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache5_6() { return &___U3CU3Ef__amU24cache5_6; }
	inline void set_U3CU3Ef__amU24cache5_6(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache5_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache5_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache6_7() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache6_7)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache6_7() const { return ___U3CU3Ef__amU24cache6_7; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache6_7() { return &___U3CU3Ef__amU24cache6_7; }
	inline void set_U3CU3Ef__amU24cache6_7(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache6_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache6_7), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache7_8() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache7_8)); }
	inline Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 * get_U3CU3Ef__amU24cache7_8() const { return ___U3CU3Ef__amU24cache7_8; }
	inline Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 ** get_address_of_U3CU3Ef__amU24cache7_8() { return &___U3CU3Ef__amU24cache7_8; }
	inline void set_U3CU3Ef__amU24cache7_8(Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 * value)
	{
		___U3CU3Ef__amU24cache7_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache7_8), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache8_9() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache8_9)); }
	inline Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 * get_U3CU3Ef__amU24cache8_9() const { return ___U3CU3Ef__amU24cache8_9; }
	inline Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 ** get_address_of_U3CU3Ef__amU24cache8_9() { return &___U3CU3Ef__amU24cache8_9; }
	inline void set_U3CU3Ef__amU24cache8_9(Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 * value)
	{
		___U3CU3Ef__amU24cache8_9 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache8_9), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache9_10() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cache9_10)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_U3CU3Ef__amU24cache9_10() const { return ___U3CU3Ef__amU24cache9_10; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_U3CU3Ef__amU24cache9_10() { return &___U3CU3Ef__amU24cache9_10; }
	inline void set_U3CU3Ef__amU24cache9_10(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___U3CU3Ef__amU24cache9_10 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache9_10), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheA_11() { return static_cast<int32_t>(offsetof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields, ___U3CU3Ef__amU24cacheA_11)); }
	inline Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 * get_U3CU3Ef__amU24cacheA_11() const { return ___U3CU3Ef__amU24cacheA_11; }
	inline Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 ** get_address_of_U3CU3Ef__amU24cacheA_11() { return &___U3CU3Ef__amU24cacheA_11; }
	inline void set_U3CU3Ef__amU24cacheA_11(Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 * value)
	{
		___U3CU3Ef__amU24cacheA_11 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheA_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DRIVERHANDLER_T32101232D25D40AA9AC96264AF3CD15F9BAB3229_H
#ifndef U3CHANDLEDRIVERREQUESTU3EC__ANONSTOREY1_TC085566AAFAEB764D7E9BA108D523A3315274885_H
#define U3CHANDLEDRIVERREQUESTU3EC__ANONSTOREY1_TC085566AAFAEB764D7E9BA108D523A3315274885_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey1
struct  U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885  : public RuntimeObject
{
public:
	// Puppetry.Puppet.Contracts.DriverRequest Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey1::request
	DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54 * ___request_0;

public:
	inline static int32_t get_offset_of_request_0() { return static_cast<int32_t>(offsetof(U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885, ___request_0)); }
	inline DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54 * get_request_0() const { return ___request_0; }
	inline DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54 ** get_address_of_request_0() { return &___request_0; }
	inline void set_request_0(DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54 * value)
	{
		___request_0 = value;
		Il2CppCodeGenWriteBarrier((&___request_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CHANDLEDRIVERREQUESTU3EC__ANONSTOREY1_TC085566AAFAEB764D7E9BA108D523A3315274885_H
#ifndef FINDGAMEOBJECTHELPER_T23594A0561F660C38E54C5274FA29A583E319505_H
#define FINDGAMEOBJECTHELPER_T23594A0561F660C38E54C5274FA29A583E319505_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.FindGameObjectHelper
struct  FindGameObjectHelper_t23594A0561F660C38E54C5274FA29A583E319505  : public RuntimeObject
{
public:

public:
};

struct FindGameObjectHelper_t23594A0561F660C38E54C5274FA29A583E319505_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> Puppetry.Puppet.FindGameObjectHelper::<>f__switchU24map1
	Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * ___U3CU3Ef__switchU24map1_6;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map1_6() { return static_cast<int32_t>(offsetof(FindGameObjectHelper_t23594A0561F660C38E54C5274FA29A583E319505_StaticFields, ___U3CU3Ef__switchU24map1_6)); }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * get_U3CU3Ef__switchU24map1_6() const { return ___U3CU3Ef__switchU24map1_6; }
	inline Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 ** get_address_of_U3CU3Ef__switchU24map1_6() { return &___U3CU3Ef__switchU24map1_6; }
	inline void set_U3CU3Ef__switchU24map1_6(Dictionary_2_tC40CE8B8795121971E021F04C9E151F97814FCA1 * value)
	{
		___U3CU3Ef__switchU24map1_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map1_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FINDGAMEOBJECTHELPER_T23594A0561F660C38E54C5274FA29A583E319505_H
#ifndef MAINTHREADHELPER_T6707B844B9B93866058C7DA20936C2FC97AC3451_H
#define MAINTHREADHELPER_T6707B844B9B93866058C7DA20936C2FC97AC3451_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.MainThreadHelper
struct  MainThreadHelper_t6707B844B9B93866058C7DA20936C2FC97AC3451  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MAINTHREADHELPER_T6707B844B9B93866058C7DA20936C2FC97AC3451_H
#ifndef U3CEXECUTEGAMEOBJECTEMULATIONU3EC__ANONSTOREY0_TACF40F1EF8A67ED2D09BB276CA060472EC614664_H
#define U3CEXECUTEGAMEOBJECTEMULATIONU3EC__ANONSTOREY0_TACF40F1EF8A67ED2D09BB276CA060472EC614664_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectEmulation>c__AnonStorey0
struct  U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664  : public RuntimeObject
{
public:
	// System.String Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectEmulation>c__AnonStorey0::upath
	String_t* ___upath_0;
	// System.Func`2<UnityEngine.GameObject,System.String> Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectEmulation>c__AnonStorey0::onComplete
	Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * ___onComplete_1;
	// System.String Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectEmulation>c__AnonStorey0::response
	String_t* ___response_2;
	// System.Threading.AutoResetEvent Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectEmulation>c__AnonStorey0::autoEvent
	AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * ___autoEvent_3;

public:
	inline static int32_t get_offset_of_upath_0() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664, ___upath_0)); }
	inline String_t* get_upath_0() const { return ___upath_0; }
	inline String_t** get_address_of_upath_0() { return &___upath_0; }
	inline void set_upath_0(String_t* value)
	{
		___upath_0 = value;
		Il2CppCodeGenWriteBarrier((&___upath_0), value);
	}

	inline static int32_t get_offset_of_onComplete_1() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664, ___onComplete_1)); }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * get_onComplete_1() const { return ___onComplete_1; }
	inline Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C ** get_address_of_onComplete_1() { return &___onComplete_1; }
	inline void set_onComplete_1(Func_2_tF3C10EE2E8D60CB24FB58C2F8B10A8B66F7DEB9C * value)
	{
		___onComplete_1 = value;
		Il2CppCodeGenWriteBarrier((&___onComplete_1), value);
	}

	inline static int32_t get_offset_of_response_2() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664, ___response_2)); }
	inline String_t* get_response_2() const { return ___response_2; }
	inline String_t** get_address_of_response_2() { return &___response_2; }
	inline void set_response_2(String_t* value)
	{
		___response_2 = value;
		Il2CppCodeGenWriteBarrier((&___response_2), value);
	}

	inline static int32_t get_offset_of_autoEvent_3() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664, ___autoEvent_3)); }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * get_autoEvent_3() const { return ___autoEvent_3; }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB ** get_address_of_autoEvent_3() { return &___autoEvent_3; }
	inline void set_autoEvent_3(AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * value)
	{
		___autoEvent_3 = value;
		Il2CppCodeGenWriteBarrier((&___autoEvent_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CEXECUTEGAMEOBJECTEMULATIONU3EC__ANONSTOREY0_TACF40F1EF8A67ED2D09BB276CA060472EC614664_H
#ifndef U3CEXECUTEGAMEOBJECTSEMULATIONU3EC__ANONSTOREY1_T9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8_H
#define U3CEXECUTEGAMEOBJECTSEMULATIONU3EC__ANONSTOREY1_T9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectsEmulation>c__AnonStorey1
struct  U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8  : public RuntimeObject
{
public:
	// System.String Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectsEmulation>c__AnonStorey1::upath
	String_t* ___upath_0;
	// System.Func`2<System.Collections.Generic.List`1<UnityEngine.GameObject>,System.String> Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectsEmulation>c__AnonStorey1::onComplete
	Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 * ___onComplete_1;
	// System.String Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectsEmulation>c__AnonStorey1::response
	String_t* ___response_2;
	// System.Threading.AutoResetEvent Puppetry.Puppet.MainThreadHelper_<ExecuteGameObjectsEmulation>c__AnonStorey1::autoEvent
	AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * ___autoEvent_3;

public:
	inline static int32_t get_offset_of_upath_0() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8, ___upath_0)); }
	inline String_t* get_upath_0() const { return ___upath_0; }
	inline String_t** get_address_of_upath_0() { return &___upath_0; }
	inline void set_upath_0(String_t* value)
	{
		___upath_0 = value;
		Il2CppCodeGenWriteBarrier((&___upath_0), value);
	}

	inline static int32_t get_offset_of_onComplete_1() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8, ___onComplete_1)); }
	inline Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 * get_onComplete_1() const { return ___onComplete_1; }
	inline Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 ** get_address_of_onComplete_1() { return &___onComplete_1; }
	inline void set_onComplete_1(Func_2_t6855BEABE3A17480339FA64BA44795738C3B95E2 * value)
	{
		___onComplete_1 = value;
		Il2CppCodeGenWriteBarrier((&___onComplete_1), value);
	}

	inline static int32_t get_offset_of_response_2() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8, ___response_2)); }
	inline String_t* get_response_2() const { return ___response_2; }
	inline String_t** get_address_of_response_2() { return &___response_2; }
	inline void set_response_2(String_t* value)
	{
		___response_2 = value;
		Il2CppCodeGenWriteBarrier((&___response_2), value);
	}

	inline static int32_t get_offset_of_autoEvent_3() { return static_cast<int32_t>(offsetof(U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8, ___autoEvent_3)); }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * get_autoEvent_3() const { return ___autoEvent_3; }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB ** get_address_of_autoEvent_3() { return &___autoEvent_3; }
	inline void set_autoEvent_3(AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * value)
	{
		___autoEvent_3 = value;
		Il2CppCodeGenWriteBarrier((&___autoEvent_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CEXECUTEGAMEOBJECTSEMULATIONU3EC__ANONSTOREY1_T9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8_H
#ifndef U3CINVOKEONMAINTHREADANDWAITU3EC__ANONSTOREY2_TBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D_H
#define U3CINVOKEONMAINTHREADANDWAITU3EC__ANONSTOREY2_TBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey2
struct  U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D  : public RuntimeObject
{
public:
	// System.Action Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey2::action
	Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 * ___action_0;
	// System.String Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey2::response
	String_t* ___response_1;
	// System.Threading.AutoResetEvent Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey2::autoEvent
	AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * ___autoEvent_2;

public:
	inline static int32_t get_offset_of_action_0() { return static_cast<int32_t>(offsetof(U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D, ___action_0)); }
	inline Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 * get_action_0() const { return ___action_0; }
	inline Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 ** get_address_of_action_0() { return &___action_0; }
	inline void set_action_0(Action_tC9F24EBA5075EA0322C6E0DC6BE2C7BDF962FB21 * value)
	{
		___action_0 = value;
		Il2CppCodeGenWriteBarrier((&___action_0), value);
	}

	inline static int32_t get_offset_of_response_1() { return static_cast<int32_t>(offsetof(U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D, ___response_1)); }
	inline String_t* get_response_1() const { return ___response_1; }
	inline String_t** get_address_of_response_1() { return &___response_1; }
	inline void set_response_1(String_t* value)
	{
		___response_1 = value;
		Il2CppCodeGenWriteBarrier((&___response_1), value);
	}

	inline static int32_t get_offset_of_autoEvent_2() { return static_cast<int32_t>(offsetof(U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D, ___autoEvent_2)); }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * get_autoEvent_2() const { return ___autoEvent_2; }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB ** get_address_of_autoEvent_2() { return &___autoEvent_2; }
	inline void set_autoEvent_2(AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * value)
	{
		___autoEvent_2 = value;
		Il2CppCodeGenWriteBarrier((&___autoEvent_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CINVOKEONMAINTHREADANDWAITU3EC__ANONSTOREY2_TBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D_H
#ifndef U3CINVOKEONMAINTHREADANDWAITU3EC__ANONSTOREY3_T5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8_H
#define U3CINVOKEONMAINTHREADANDWAITU3EC__ANONSTOREY3_T5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey3
struct  U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8  : public RuntimeObject
{
public:
	// System.Func`1<System.String> Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey3::action
	Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 * ___action_0;
	// System.String Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey3::response
	String_t* ___response_1;
	// System.Threading.AutoResetEvent Puppetry.Puppet.MainThreadHelper_<InvokeOnMainThreadAndWait>c__AnonStorey3::autoEvent
	AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * ___autoEvent_2;

public:
	inline static int32_t get_offset_of_action_0() { return static_cast<int32_t>(offsetof(U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8, ___action_0)); }
	inline Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 * get_action_0() const { return ___action_0; }
	inline Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 ** get_address_of_action_0() { return &___action_0; }
	inline void set_action_0(Func_1_tFFD07C3F37BA096E036FCF22D6E90F7FF88C5220 * value)
	{
		___action_0 = value;
		Il2CppCodeGenWriteBarrier((&___action_0), value);
	}

	inline static int32_t get_offset_of_response_1() { return static_cast<int32_t>(offsetof(U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8, ___response_1)); }
	inline String_t* get_response_1() const { return ___response_1; }
	inline String_t** get_address_of_response_1() { return &___response_1; }
	inline void set_response_1(String_t* value)
	{
		___response_1 = value;
		Il2CppCodeGenWriteBarrier((&___response_1), value);
	}

	inline static int32_t get_offset_of_autoEvent_2() { return static_cast<int32_t>(offsetof(U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8, ___autoEvent_2)); }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * get_autoEvent_2() const { return ___autoEvent_2; }
	inline AutoResetEvent_t332410718633EC57126829912EE4C000906421EB ** get_address_of_autoEvent_2() { return &___autoEvent_2; }
	inline void set_autoEvent_2(AutoResetEvent_t332410718633EC57126829912EE4C000906421EB * value)
	{
		___autoEvent_2 = value;
		Il2CppCodeGenWriteBarrier((&___autoEvent_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CINVOKEONMAINTHREADANDWAITU3EC__ANONSTOREY3_T5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8_H
#ifndef SCREENHELPER_TD87C1BD8FC297CD317C9C76117D8A3F59BABBCDD_H
#define SCREENHELPER_TD87C1BD8FC297CD317C9C76117D8A3F59BABBCDD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.ScreenHelper
struct  ScreenHelper_tD87C1BD8FC297CD317C9C76117D8A3F59BABBCDD  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENHELPER_TD87C1BD8FC297CD317C9C76117D8A3F59BABBCDD_H
#ifndef LOGGER_T4DECB1CDD98DCFE720C202E15F81C7BDDF662214_H
#define LOGGER_T4DECB1CDD98DCFE720C202E15F81C7BDDF662214_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.Utils.Logger
struct  Logger_t4DECB1CDD98DCFE720C202E15F81C7BDDF662214  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGGER_T4DECB1CDD98DCFE720C202E15F81C7BDDF662214_H
#ifndef U3CDOWNLOADRANKINGSFROMDATABASEU3EC__ITERATOR1_T2395A532B2B74FBCBB773C6C38117D3EF69B01EE_H
#define U3CDOWNLOADRANKINGSFROMDATABASEU3EC__ITERATOR1_T2395A532B2B74FBCBB773C6C38117D3EF69B01EE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// RankingManager_<DownloadRankingsFromDatabase>c__Iterator1
struct  U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE  : public RuntimeObject
{
public:
	// UnityEngine.Networking.UnityWebRequest RankingManager_<DownloadRankingsFromDatabase>c__Iterator1::<www>__0
	UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 * ___U3CwwwU3E__0_0;
	// RankingManager RankingManager_<DownloadRankingsFromDatabase>c__Iterator1::U24this
	RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5 * ___U24this_1;
	// System.Object RankingManager_<DownloadRankingsFromDatabase>c__Iterator1::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean RankingManager_<DownloadRankingsFromDatabase>c__Iterator1::U24disposing
	bool ___U24disposing_3;
	// System.Int32 RankingManager_<DownloadRankingsFromDatabase>c__Iterator1::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_U3CwwwU3E__0_0() { return static_cast<int32_t>(offsetof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE, ___U3CwwwU3E__0_0)); }
	inline UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 * get_U3CwwwU3E__0_0() const { return ___U3CwwwU3E__0_0; }
	inline UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 ** get_address_of_U3CwwwU3E__0_0() { return &___U3CwwwU3E__0_0; }
	inline void set_U3CwwwU3E__0_0(UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 * value)
	{
		___U3CwwwU3E__0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CwwwU3E__0_0), value);
	}

	inline static int32_t get_offset_of_U24this_1() { return static_cast<int32_t>(offsetof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE, ___U24this_1)); }
	inline RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5 * get_U24this_1() const { return ___U24this_1; }
	inline RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5 ** get_address_of_U24this_1() { return &___U24this_1; }
	inline void set_U24this_1(RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5 * value)
	{
		___U24this_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

struct U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE_StaticFields
{
public:
	// System.Func`2<Ranking,System.Int32> RankingManager_<DownloadRankingsFromDatabase>c__Iterator1::<>f__amU24cache0
	Func_2_tB345E72356ED3DD90BBA4049309FD04BEC430306 * ___U3CU3Ef__amU24cache0_5;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_5() { return static_cast<int32_t>(offsetof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE_StaticFields, ___U3CU3Ef__amU24cache0_5)); }
	inline Func_2_tB345E72356ED3DD90BBA4049309FD04BEC430306 * get_U3CU3Ef__amU24cache0_5() const { return ___U3CU3Ef__amU24cache0_5; }
	inline Func_2_tB345E72356ED3DD90BBA4049309FD04BEC430306 ** get_address_of_U3CU3Ef__amU24cache0_5() { return &___U3CU3Ef__amU24cache0_5; }
	inline void set_U3CU3Ef__amU24cache0_5(Func_2_tB345E72356ED3DD90BBA4049309FD04BEC430306 * value)
	{
		___U3CU3Ef__amU24cache0_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDOWNLOADRANKINGSFROMDATABASEU3EC__ITERATOR1_T2395A532B2B74FBCBB773C6C38117D3EF69B01EE_H
#ifndef U3CUPLOADSCOREU3EC__ITERATOR0_T1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8_H
#define U3CUPLOADSCOREU3EC__ITERATOR0_T1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// RankingManager_<UploadScore>c__Iterator0
struct  U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8  : public RuntimeObject
{
public:
	// System.String RankingManager_<UploadScore>c__Iterator0::name
	String_t* ___name_0;
	// System.Int32 RankingManager_<UploadScore>c__Iterator0::score
	int32_t ___score_1;
	// UnityEngine.Networking.UnityWebRequest RankingManager_<UploadScore>c__Iterator0::<www>__0
	UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 * ___U3CwwwU3E__0_2;
	// System.Object RankingManager_<UploadScore>c__Iterator0::U24current
	RuntimeObject * ___U24current_3;
	// System.Boolean RankingManager_<UploadScore>c__Iterator0::U24disposing
	bool ___U24disposing_4;
	// System.Int32 RankingManager_<UploadScore>c__Iterator0::U24PC
	int32_t ___U24PC_5;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}

	inline static int32_t get_offset_of_score_1() { return static_cast<int32_t>(offsetof(U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8, ___score_1)); }
	inline int32_t get_score_1() const { return ___score_1; }
	inline int32_t* get_address_of_score_1() { return &___score_1; }
	inline void set_score_1(int32_t value)
	{
		___score_1 = value;
	}

	inline static int32_t get_offset_of_U3CwwwU3E__0_2() { return static_cast<int32_t>(offsetof(U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8, ___U3CwwwU3E__0_2)); }
	inline UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 * get_U3CwwwU3E__0_2() const { return ___U3CwwwU3E__0_2; }
	inline UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 ** get_address_of_U3CwwwU3E__0_2() { return &___U3CwwwU3E__0_2; }
	inline void set_U3CwwwU3E__0_2(UnityWebRequest_t9120F5A2C7D43B936B49C0B7E4CA54C822689129 * value)
	{
		___U3CwwwU3E__0_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CwwwU3E__0_2), value);
	}

	inline static int32_t get_offset_of_U24current_3() { return static_cast<int32_t>(offsetof(U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8, ___U24current_3)); }
	inline RuntimeObject * get_U24current_3() const { return ___U24current_3; }
	inline RuntimeObject ** get_address_of_U24current_3() { return &___U24current_3; }
	inline void set_U24current_3(RuntimeObject * value)
	{
		___U24current_3 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_3), value);
	}

	inline static int32_t get_offset_of_U24disposing_4() { return static_cast<int32_t>(offsetof(U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8, ___U24disposing_4)); }
	inline bool get_U24disposing_4() const { return ___U24disposing_4; }
	inline bool* get_address_of_U24disposing_4() { return &___U24disposing_4; }
	inline void set_U24disposing_4(bool value)
	{
		___U24disposing_4 = value;
	}

	inline static int32_t get_offset_of_U24PC_5() { return static_cast<int32_t>(offsetof(U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8, ___U24PC_5)); }
	inline int32_t get_U24PC_5() const { return ___U24PC_5; }
	inline int32_t* get_address_of_U24PC_5() { return &___U24PC_5; }
	inline void set_U24PC_5(int32_t value)
	{
		___U24PC_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CUPLOADSCOREU3EC__ITERATOR0_T1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8_H
#ifndef SOUND_T4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E_H
#define SOUND_T4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Sound
struct  Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E  : public RuntimeObject
{
public:
	// UnityEngine.AudioSource Sound::audioSource
	AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C * ___audioSource_0;
	// System.Boolean Sound::loop
	bool ___loop_1;
	// UnityEngine.AudioClip Sound::audio
	AudioClip_tCC3C35F579203CE2601243585AB3D6953C3BA051 * ___audio_2;
	// System.String Sound::audioName
	String_t* ___audioName_3;
	// System.Single Sound::audioPitch
	float ___audioPitch_4;
	// System.Single Sound::audioVolume
	float ___audioVolume_5;
	// System.Single Sound::blend
	float ___blend_6;

public:
	inline static int32_t get_offset_of_audioSource_0() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___audioSource_0)); }
	inline AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C * get_audioSource_0() const { return ___audioSource_0; }
	inline AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C ** get_address_of_audioSource_0() { return &___audioSource_0; }
	inline void set_audioSource_0(AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C * value)
	{
		___audioSource_0 = value;
		Il2CppCodeGenWriteBarrier((&___audioSource_0), value);
	}

	inline static int32_t get_offset_of_loop_1() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___loop_1)); }
	inline bool get_loop_1() const { return ___loop_1; }
	inline bool* get_address_of_loop_1() { return &___loop_1; }
	inline void set_loop_1(bool value)
	{
		___loop_1 = value;
	}

	inline static int32_t get_offset_of_audio_2() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___audio_2)); }
	inline AudioClip_tCC3C35F579203CE2601243585AB3D6953C3BA051 * get_audio_2() const { return ___audio_2; }
	inline AudioClip_tCC3C35F579203CE2601243585AB3D6953C3BA051 ** get_address_of_audio_2() { return &___audio_2; }
	inline void set_audio_2(AudioClip_tCC3C35F579203CE2601243585AB3D6953C3BA051 * value)
	{
		___audio_2 = value;
		Il2CppCodeGenWriteBarrier((&___audio_2), value);
	}

	inline static int32_t get_offset_of_audioName_3() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___audioName_3)); }
	inline String_t* get_audioName_3() const { return ___audioName_3; }
	inline String_t** get_address_of_audioName_3() { return &___audioName_3; }
	inline void set_audioName_3(String_t* value)
	{
		___audioName_3 = value;
		Il2CppCodeGenWriteBarrier((&___audioName_3), value);
	}

	inline static int32_t get_offset_of_audioPitch_4() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___audioPitch_4)); }
	inline float get_audioPitch_4() const { return ___audioPitch_4; }
	inline float* get_address_of_audioPitch_4() { return &___audioPitch_4; }
	inline void set_audioPitch_4(float value)
	{
		___audioPitch_4 = value;
	}

	inline static int32_t get_offset_of_audioVolume_5() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___audioVolume_5)); }
	inline float get_audioVolume_5() const { return ___audioVolume_5; }
	inline float* get_address_of_audioVolume_5() { return &___audioVolume_5; }
	inline void set_audioVolume_5(float value)
	{
		___audioVolume_5 = value;
	}

	inline static int32_t get_offset_of_blend_6() { return static_cast<int32_t>(offsetof(Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E, ___blend_6)); }
	inline float get_blend_6() const { return ___blend_6; }
	inline float* get_address_of_blend_6() { return &___blend_6; }
	inline void set_blend_6(float value)
	{
		___blend_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOUND_T4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E_H
#ifndef U3CPAUSEBGMU3EC__ANONSTOREY1_T83D3B0F0B349EA8AF19FF21F3B152401F90BF051_H
#define U3CPAUSEBGMU3EC__ANONSTOREY1_T83D3B0F0B349EA8AF19FF21F3B152401F90BF051_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SoundManager_<PauseBGM>c__AnonStorey1
struct  U3CPauseBGMU3Ec__AnonStorey1_t83D3B0F0B349EA8AF19FF21F3B152401F90BF051  : public RuntimeObject
{
public:
	// System.String SoundManager_<PauseBGM>c__AnonStorey1::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(U3CPauseBGMU3Ec__AnonStorey1_t83D3B0F0B349EA8AF19FF21F3B152401F90BF051, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPAUSEBGMU3EC__ANONSTOREY1_T83D3B0F0B349EA8AF19FF21F3B152401F90BF051_H
#ifndef U3CPLAYU3EC__ANONSTOREY0_TE9F12C6A82F00C24759129E343897F1556D7A1A4_H
#define U3CPLAYU3EC__ANONSTOREY0_TE9F12C6A82F00C24759129E343897F1556D7A1A4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SoundManager_<Play>c__AnonStorey0
struct  U3CPlayU3Ec__AnonStorey0_tE9F12C6A82F00C24759129E343897F1556D7A1A4  : public RuntimeObject
{
public:
	// System.String SoundManager_<Play>c__AnonStorey0::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(U3CPlayU3Ec__AnonStorey0_tE9F12C6A82F00C24759129E343897F1556D7A1A4, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPLAYU3EC__ANONSTOREY0_TE9F12C6A82F00C24759129E343897F1556D7A1A4_H
#ifndef U3CPLAYONCEU3EC__ANONSTOREY3_TA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12_H
#define U3CPLAYONCEU3EC__ANONSTOREY3_TA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SoundManager_<PlayOnce>c__AnonStorey3
struct  U3CPlayOnceU3Ec__AnonStorey3_tA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12  : public RuntimeObject
{
public:
	// System.String SoundManager_<PlayOnce>c__AnonStorey3::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(U3CPlayOnceU3Ec__AnonStorey3_tA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPLAYONCEU3EC__ANONSTOREY3_TA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12_H
#ifndef U3CSTOPBGMU3EC__ANONSTOREY2_TF5F4EBB797E8C73E54C8D29223893FAB467B58C2_H
#define U3CSTOPBGMU3EC__ANONSTOREY2_TF5F4EBB797E8C73E54C8D29223893FAB467B58C2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SoundManager_<StopBGM>c__AnonStorey2
struct  U3CStopBGMU3Ec__AnonStorey2_tF5F4EBB797E8C73E54C8D29223893FAB467B58C2  : public RuntimeObject
{
public:
	// System.String SoundManager_<StopBGM>c__AnonStorey2::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(U3CStopBGMU3Ec__AnonStorey2_tF5F4EBB797E8C73E54C8D29223893FAB467B58C2, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTOPBGMU3EC__ANONSTOREY2_TF5F4EBB797E8C73E54C8D29223893FAB467B58C2_H
#ifndef VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#define VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_marshaled_com
{
};
#endif // VALUETYPE_T1810BD84E0FDB5D3A7CD34286A5B22F343995C9C_H
#ifndef U3CSTARTU3EC__ITERATOR0_T9773F6F451324B5BE08303CA8473793A5A1A0983_H
#define U3CSTARTU3EC__ITERATOR0_T9773F6F451324B5BE08303CA8473793A5A1A0983_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark01_<Start>c__Iterator0
struct  U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983  : public RuntimeObject
{
public:
	// System.Int32 TMPro.Examples.Benchmark01_<Start>c__Iterator0::<i>__1
	int32_t ___U3CiU3E__1_0;
	// TMPro.Examples.Benchmark01 TMPro.Examples.Benchmark01_<Start>c__Iterator0::U24this
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761 * ___U24this_1;
	// System.Object TMPro.Examples.Benchmark01_<Start>c__Iterator0::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean TMPro.Examples.Benchmark01_<Start>c__Iterator0::U24disposing
	bool ___U24disposing_3;
	// System.Int32 TMPro.Examples.Benchmark01_<Start>c__Iterator0::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_U3CiU3E__1_0() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983, ___U3CiU3E__1_0)); }
	inline int32_t get_U3CiU3E__1_0() const { return ___U3CiU3E__1_0; }
	inline int32_t* get_address_of_U3CiU3E__1_0() { return &___U3CiU3E__1_0; }
	inline void set_U3CiU3E__1_0(int32_t value)
	{
		___U3CiU3E__1_0 = value;
	}

	inline static int32_t get_offset_of_U24this_1() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983, ___U24this_1)); }
	inline Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761 * get_U24this_1() const { return ___U24this_1; }
	inline Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761 ** get_address_of_U24this_1() { return &___U24this_1; }
	inline void set_U24this_1(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761 * value)
	{
		___U24this_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTU3EC__ITERATOR0_T9773F6F451324B5BE08303CA8473793A5A1A0983_H
#ifndef U3CSTARTU3EC__ITERATOR0_TB09B8CA6B313051AC5AB40F7176915D70036EFD5_H
#define U3CSTARTU3EC__ITERATOR0_TB09B8CA6B313051AC5AB40F7176915D70036EFD5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark01_UGUI_<Start>c__Iterator0
struct  U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5  : public RuntimeObject
{
public:
	// System.Int32 TMPro.Examples.Benchmark01_UGUI_<Start>c__Iterator0::<i>__1
	int32_t ___U3CiU3E__1_0;
	// TMPro.Examples.Benchmark01_UGUI TMPro.Examples.Benchmark01_UGUI_<Start>c__Iterator0::U24this
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55 * ___U24this_1;
	// System.Object TMPro.Examples.Benchmark01_UGUI_<Start>c__Iterator0::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean TMPro.Examples.Benchmark01_UGUI_<Start>c__Iterator0::U24disposing
	bool ___U24disposing_3;
	// System.Int32 TMPro.Examples.Benchmark01_UGUI_<Start>c__Iterator0::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_U3CiU3E__1_0() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5, ___U3CiU3E__1_0)); }
	inline int32_t get_U3CiU3E__1_0() const { return ___U3CiU3E__1_0; }
	inline int32_t* get_address_of_U3CiU3E__1_0() { return &___U3CiU3E__1_0; }
	inline void set_U3CiU3E__1_0(int32_t value)
	{
		___U3CiU3E__1_0 = value;
	}

	inline static int32_t get_offset_of_U24this_1() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5, ___U24this_1)); }
	inline Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55 * get_U24this_1() const { return ___U24this_1; }
	inline Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55 ** get_address_of_U24this_1() { return &___U24this_1; }
	inline void set_U24this_1(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55 * value)
	{
		___U24this_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTU3EC__ITERATOR0_TB09B8CA6B313051AC5AB40F7176915D70036EFD5_H
#ifndef U3CANIMATEPROPERTIESU3EC__ITERATOR0_T46D8DBC8E5800C77BA5D6C76B7983576447A1CF5_H
#define U3CANIMATEPROPERTIESU3EC__ITERATOR0_T46D8DBC8E5800C77BA5D6C76B7983576447A1CF5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.ShaderPropAnimator_<AnimateProperties>c__Iterator0
struct  U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5  : public RuntimeObject
{
public:
	// System.Single TMPro.Examples.ShaderPropAnimator_<AnimateProperties>c__Iterator0::<glowPower>__1
	float ___U3CglowPowerU3E__1_0;
	// TMPro.Examples.ShaderPropAnimator TMPro.Examples.ShaderPropAnimator_<AnimateProperties>c__Iterator0::U24this
	ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72 * ___U24this_1;
	// System.Object TMPro.Examples.ShaderPropAnimator_<AnimateProperties>c__Iterator0::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean TMPro.Examples.ShaderPropAnimator_<AnimateProperties>c__Iterator0::U24disposing
	bool ___U24disposing_3;
	// System.Int32 TMPro.Examples.ShaderPropAnimator_<AnimateProperties>c__Iterator0::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_U3CglowPowerU3E__1_0() { return static_cast<int32_t>(offsetof(U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5, ___U3CglowPowerU3E__1_0)); }
	inline float get_U3CglowPowerU3E__1_0() const { return ___U3CglowPowerU3E__1_0; }
	inline float* get_address_of_U3CglowPowerU3E__1_0() { return &___U3CglowPowerU3E__1_0; }
	inline void set_U3CglowPowerU3E__1_0(float value)
	{
		___U3CglowPowerU3E__1_0 = value;
	}

	inline static int32_t get_offset_of_U24this_1() { return static_cast<int32_t>(offsetof(U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5, ___U24this_1)); }
	inline ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72 * get_U24this_1() const { return ___U24this_1; }
	inline ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72 ** get_address_of_U24this_1() { return &___U24this_1; }
	inline void set_U24this_1(ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72 * value)
	{
		___U24this_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CANIMATEPROPERTIESU3EC__ITERATOR0_T46D8DBC8E5800C77BA5D6C76B7983576447A1CF5_H
#ifndef U3CSTARTU3EC__ITERATOR0_T438726BF18FBCABCE5555E618B5A5B0DE934B94A_H
#define U3CSTARTU3EC__ITERATOR0_T438726BF18FBCABCE5555E618B5A5B0DE934B94A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TeleType_<Start>c__Iterator0
struct  U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A  : public RuntimeObject
{
public:
	// System.Int32 TMPro.Examples.TeleType_<Start>c__Iterator0::<totalVisibleCharacters>__0
	int32_t ___U3CtotalVisibleCharactersU3E__0_0;
	// System.Int32 TMPro.Examples.TeleType_<Start>c__Iterator0::<counter>__0
	int32_t ___U3CcounterU3E__0_1;
	// System.Int32 TMPro.Examples.TeleType_<Start>c__Iterator0::<visibleCount>__0
	int32_t ___U3CvisibleCountU3E__0_2;
	// TMPro.Examples.TeleType TMPro.Examples.TeleType_<Start>c__Iterator0::U24this
	TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716 * ___U24this_3;
	// System.Object TMPro.Examples.TeleType_<Start>c__Iterator0::U24current
	RuntimeObject * ___U24current_4;
	// System.Boolean TMPro.Examples.TeleType_<Start>c__Iterator0::U24disposing
	bool ___U24disposing_5;
	// System.Int32 TMPro.Examples.TeleType_<Start>c__Iterator0::U24PC
	int32_t ___U24PC_6;

public:
	inline static int32_t get_offset_of_U3CtotalVisibleCharactersU3E__0_0() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U3CtotalVisibleCharactersU3E__0_0)); }
	inline int32_t get_U3CtotalVisibleCharactersU3E__0_0() const { return ___U3CtotalVisibleCharactersU3E__0_0; }
	inline int32_t* get_address_of_U3CtotalVisibleCharactersU3E__0_0() { return &___U3CtotalVisibleCharactersU3E__0_0; }
	inline void set_U3CtotalVisibleCharactersU3E__0_0(int32_t value)
	{
		___U3CtotalVisibleCharactersU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U3CcounterU3E__0_1() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U3CcounterU3E__0_1)); }
	inline int32_t get_U3CcounterU3E__0_1() const { return ___U3CcounterU3E__0_1; }
	inline int32_t* get_address_of_U3CcounterU3E__0_1() { return &___U3CcounterU3E__0_1; }
	inline void set_U3CcounterU3E__0_1(int32_t value)
	{
		___U3CcounterU3E__0_1 = value;
	}

	inline static int32_t get_offset_of_U3CvisibleCountU3E__0_2() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U3CvisibleCountU3E__0_2)); }
	inline int32_t get_U3CvisibleCountU3E__0_2() const { return ___U3CvisibleCountU3E__0_2; }
	inline int32_t* get_address_of_U3CvisibleCountU3E__0_2() { return &___U3CvisibleCountU3E__0_2; }
	inline void set_U3CvisibleCountU3E__0_2(int32_t value)
	{
		___U3CvisibleCountU3E__0_2 = value;
	}

	inline static int32_t get_offset_of_U24this_3() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U24this_3)); }
	inline TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716 * get_U24this_3() const { return ___U24this_3; }
	inline TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716 ** get_address_of_U24this_3() { return &___U24this_3; }
	inline void set_U24this_3(TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716 * value)
	{
		___U24this_3 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_3), value);
	}

	inline static int32_t get_offset_of_U24current_4() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U24current_4)); }
	inline RuntimeObject * get_U24current_4() const { return ___U24current_4; }
	inline RuntimeObject ** get_address_of_U24current_4() { return &___U24current_4; }
	inline void set_U24current_4(RuntimeObject * value)
	{
		___U24current_4 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_4), value);
	}

	inline static int32_t get_offset_of_U24disposing_5() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U24disposing_5)); }
	inline bool get_U24disposing_5() const { return ___U24disposing_5; }
	inline bool* get_address_of_U24disposing_5() { return &___U24disposing_5; }
	inline void set_U24disposing_5(bool value)
	{
		___U24disposing_5 = value;
	}

	inline static int32_t get_offset_of_U24PC_6() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A, ___U24PC_6)); }
	inline int32_t get_U24PC_6() const { return ___U24PC_6; }
	inline int32_t* get_address_of_U24PC_6() { return &___U24PC_6; }
	inline void set_U24PC_6(int32_t value)
	{
		___U24PC_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTU3EC__ITERATOR0_T438726BF18FBCABCE5555E618B5A5B0DE934B94A_H
#ifndef U3CREVEALCHARACTERSU3EC__ITERATOR0_TE4A39B5FABDABB7BB85C935C9E234676154219D8_H
#define U3CREVEALCHARACTERSU3EC__ITERATOR0_TE4A39B5FABDABB7BB85C935C9E234676154219D8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0
struct  U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8  : public RuntimeObject
{
public:
	// TMPro.TMP_Text TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::textComponent
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___textComponent_0;
	// TMPro.TMP_TextInfo TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::<textInfo>__0
	TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 * ___U3CtextInfoU3E__0_1;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::<totalVisibleCharacters>__0
	int32_t ___U3CtotalVisibleCharactersU3E__0_2;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::<visibleCount>__0
	int32_t ___U3CvisibleCountU3E__0_3;
	// TMPro.Examples.TextConsoleSimulator TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::U24this
	TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163 * ___U24this_4;
	// System.Object TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::U24current
	RuntimeObject * ___U24current_5;
	// System.Boolean TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::U24disposing
	bool ___U24disposing_6;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealCharacters>c__Iterator0::U24PC
	int32_t ___U24PC_7;

public:
	inline static int32_t get_offset_of_textComponent_0() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___textComponent_0)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_textComponent_0() const { return ___textComponent_0; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_textComponent_0() { return &___textComponent_0; }
	inline void set_textComponent_0(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___textComponent_0 = value;
		Il2CppCodeGenWriteBarrier((&___textComponent_0), value);
	}

	inline static int32_t get_offset_of_U3CtextInfoU3E__0_1() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U3CtextInfoU3E__0_1)); }
	inline TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 * get_U3CtextInfoU3E__0_1() const { return ___U3CtextInfoU3E__0_1; }
	inline TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 ** get_address_of_U3CtextInfoU3E__0_1() { return &___U3CtextInfoU3E__0_1; }
	inline void set_U3CtextInfoU3E__0_1(TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 * value)
	{
		___U3CtextInfoU3E__0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CtextInfoU3E__0_1), value);
	}

	inline static int32_t get_offset_of_U3CtotalVisibleCharactersU3E__0_2() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U3CtotalVisibleCharactersU3E__0_2)); }
	inline int32_t get_U3CtotalVisibleCharactersU3E__0_2() const { return ___U3CtotalVisibleCharactersU3E__0_2; }
	inline int32_t* get_address_of_U3CtotalVisibleCharactersU3E__0_2() { return &___U3CtotalVisibleCharactersU3E__0_2; }
	inline void set_U3CtotalVisibleCharactersU3E__0_2(int32_t value)
	{
		___U3CtotalVisibleCharactersU3E__0_2 = value;
	}

	inline static int32_t get_offset_of_U3CvisibleCountU3E__0_3() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U3CvisibleCountU3E__0_3)); }
	inline int32_t get_U3CvisibleCountU3E__0_3() const { return ___U3CvisibleCountU3E__0_3; }
	inline int32_t* get_address_of_U3CvisibleCountU3E__0_3() { return &___U3CvisibleCountU3E__0_3; }
	inline void set_U3CvisibleCountU3E__0_3(int32_t value)
	{
		___U3CvisibleCountU3E__0_3 = value;
	}

	inline static int32_t get_offset_of_U24this_4() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U24this_4)); }
	inline TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163 * get_U24this_4() const { return ___U24this_4; }
	inline TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163 ** get_address_of_U24this_4() { return &___U24this_4; }
	inline void set_U24this_4(TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163 * value)
	{
		___U24this_4 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_4), value);
	}

	inline static int32_t get_offset_of_U24current_5() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U24current_5)); }
	inline RuntimeObject * get_U24current_5() const { return ___U24current_5; }
	inline RuntimeObject ** get_address_of_U24current_5() { return &___U24current_5; }
	inline void set_U24current_5(RuntimeObject * value)
	{
		___U24current_5 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_5), value);
	}

	inline static int32_t get_offset_of_U24disposing_6() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U24disposing_6)); }
	inline bool get_U24disposing_6() const { return ___U24disposing_6; }
	inline bool* get_address_of_U24disposing_6() { return &___U24disposing_6; }
	inline void set_U24disposing_6(bool value)
	{
		___U24disposing_6 = value;
	}

	inline static int32_t get_offset_of_U24PC_7() { return static_cast<int32_t>(offsetof(U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8, ___U24PC_7)); }
	inline int32_t get_U24PC_7() const { return ___U24PC_7; }
	inline int32_t* get_address_of_U24PC_7() { return &___U24PC_7; }
	inline void set_U24PC_7(int32_t value)
	{
		___U24PC_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREVEALCHARACTERSU3EC__ITERATOR0_TE4A39B5FABDABB7BB85C935C9E234676154219D8_H
#ifndef U3CREVEALWORDSU3EC__ITERATOR1_TA0378C234D4F01B254D8F9900BD8D00AA238D49D_H
#define U3CREVEALWORDSU3EC__ITERATOR1_TA0378C234D4F01B254D8F9900BD8D00AA238D49D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1
struct  U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D  : public RuntimeObject
{
public:
	// TMPro.TMP_Text TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::textComponent
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___textComponent_0;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::<totalWordCount>__0
	int32_t ___U3CtotalWordCountU3E__0_1;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::<totalVisibleCharacters>__0
	int32_t ___U3CtotalVisibleCharactersU3E__0_2;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::<counter>__0
	int32_t ___U3CcounterU3E__0_3;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::<currentWord>__0
	int32_t ___U3CcurrentWordU3E__0_4;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::<visibleCount>__0
	int32_t ___U3CvisibleCountU3E__0_5;
	// System.Object TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::U24current
	RuntimeObject * ___U24current_6;
	// System.Boolean TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::U24disposing
	bool ___U24disposing_7;
	// System.Int32 TMPro.Examples.TextConsoleSimulator_<RevealWords>c__Iterator1::U24PC
	int32_t ___U24PC_8;

public:
	inline static int32_t get_offset_of_textComponent_0() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___textComponent_0)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_textComponent_0() const { return ___textComponent_0; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_textComponent_0() { return &___textComponent_0; }
	inline void set_textComponent_0(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___textComponent_0 = value;
		Il2CppCodeGenWriteBarrier((&___textComponent_0), value);
	}

	inline static int32_t get_offset_of_U3CtotalWordCountU3E__0_1() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U3CtotalWordCountU3E__0_1)); }
	inline int32_t get_U3CtotalWordCountU3E__0_1() const { return ___U3CtotalWordCountU3E__0_1; }
	inline int32_t* get_address_of_U3CtotalWordCountU3E__0_1() { return &___U3CtotalWordCountU3E__0_1; }
	inline void set_U3CtotalWordCountU3E__0_1(int32_t value)
	{
		___U3CtotalWordCountU3E__0_1 = value;
	}

	inline static int32_t get_offset_of_U3CtotalVisibleCharactersU3E__0_2() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U3CtotalVisibleCharactersU3E__0_2)); }
	inline int32_t get_U3CtotalVisibleCharactersU3E__0_2() const { return ___U3CtotalVisibleCharactersU3E__0_2; }
	inline int32_t* get_address_of_U3CtotalVisibleCharactersU3E__0_2() { return &___U3CtotalVisibleCharactersU3E__0_2; }
	inline void set_U3CtotalVisibleCharactersU3E__0_2(int32_t value)
	{
		___U3CtotalVisibleCharactersU3E__0_2 = value;
	}

	inline static int32_t get_offset_of_U3CcounterU3E__0_3() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U3CcounterU3E__0_3)); }
	inline int32_t get_U3CcounterU3E__0_3() const { return ___U3CcounterU3E__0_3; }
	inline int32_t* get_address_of_U3CcounterU3E__0_3() { return &___U3CcounterU3E__0_3; }
	inline void set_U3CcounterU3E__0_3(int32_t value)
	{
		___U3CcounterU3E__0_3 = value;
	}

	inline static int32_t get_offset_of_U3CcurrentWordU3E__0_4() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U3CcurrentWordU3E__0_4)); }
	inline int32_t get_U3CcurrentWordU3E__0_4() const { return ___U3CcurrentWordU3E__0_4; }
	inline int32_t* get_address_of_U3CcurrentWordU3E__0_4() { return &___U3CcurrentWordU3E__0_4; }
	inline void set_U3CcurrentWordU3E__0_4(int32_t value)
	{
		___U3CcurrentWordU3E__0_4 = value;
	}

	inline static int32_t get_offset_of_U3CvisibleCountU3E__0_5() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U3CvisibleCountU3E__0_5)); }
	inline int32_t get_U3CvisibleCountU3E__0_5() const { return ___U3CvisibleCountU3E__0_5; }
	inline int32_t* get_address_of_U3CvisibleCountU3E__0_5() { return &___U3CvisibleCountU3E__0_5; }
	inline void set_U3CvisibleCountU3E__0_5(int32_t value)
	{
		___U3CvisibleCountU3E__0_5 = value;
	}

	inline static int32_t get_offset_of_U24current_6() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U24current_6)); }
	inline RuntimeObject * get_U24current_6() const { return ___U24current_6; }
	inline RuntimeObject ** get_address_of_U24current_6() { return &___U24current_6; }
	inline void set_U24current_6(RuntimeObject * value)
	{
		___U24current_6 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_6), value);
	}

	inline static int32_t get_offset_of_U24disposing_7() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U24disposing_7)); }
	inline bool get_U24disposing_7() const { return ___U24disposing_7; }
	inline bool* get_address_of_U24disposing_7() { return &___U24disposing_7; }
	inline void set_U24disposing_7(bool value)
	{
		___U24disposing_7 = value;
	}

	inline static int32_t get_offset_of_U24PC_8() { return static_cast<int32_t>(offsetof(U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D, ___U24PC_8)); }
	inline int32_t get_U24PC_8() const { return ___U24PC_8; }
	inline int32_t* get_address_of_U24PC_8() { return &___U24PC_8; }
	inline void set_U24PC_8(int32_t value)
	{
		___U24PC_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREVEALWORDSU3EC__ITERATOR1_TA0378C234D4F01B254D8F9900BD8D00AA238D49D_H
#ifndef UNITYSERVICE_TFBBD4B37C3CFC02004512FB59BA0A8E7833A8754_H
#define UNITYSERVICE_TFBBD4B37C3CFC02004512FB59BA0A8E7833A8754_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityService
struct  UnityService_tFBBD4B37C3CFC02004512FB59BA0A8E7833A8754  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYSERVICE_TFBBD4B37C3CFC02004512FB59BA0A8E7833A8754_H
#ifndef RANKING_T387D158090B6D04BF47953B530388C56E96B9810_H
#define RANKING_T387D158090B6D04BF47953B530388C56E96B9810_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Ranking
struct  Ranking_t387D158090B6D04BF47953B530388C56E96B9810 
{
public:
	// System.String Ranking::name
	String_t* ___name_0;
	// System.Int32 Ranking::score
	int32_t ___score_1;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(Ranking_t387D158090B6D04BF47953B530388C56E96B9810, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}

	inline static int32_t get_offset_of_score_1() { return static_cast<int32_t>(offsetof(Ranking_t387D158090B6D04BF47953B530388C56E96B9810, ___score_1)); }
	inline int32_t get_score_1() const { return ___score_1; }
	inline int32_t* get_address_of_score_1() { return &___score_1; }
	inline void set_score_1(int32_t value)
	{
		___score_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of Ranking
struct Ranking_t387D158090B6D04BF47953B530388C56E96B9810_marshaled_pinvoke
{
	char* ___name_0;
	int32_t ___score_1;
};
// Native definition for COM marshalling of Ranking
struct Ranking_t387D158090B6D04BF47953B530388C56E96B9810_marshaled_com
{
	Il2CppChar* ___name_0;
	int32_t ___score_1;
};
#endif // RANKING_T387D158090B6D04BF47953B530388C56E96B9810_H
#ifndef ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#define ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF  : public ValueType_t1810BD84E0FDB5D3A7CD34286A5B22F343995C9C
{
public:

public:
};

struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t79D85CE93255C78D04436552445C364ED409B744* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t5AAC444DFCAA78411386665A25FE3CD3169879EF_marshaled_com
{
};
#endif // ENUM_T5AAC444DFCAA78411386665A25FE3CD3169879EF_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef COLOR32_T23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23_H
#define COLOR32_T23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color32
struct  Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23 
{
public:
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Int32 UnityEngine.Color32::rgba
			int32_t ___rgba_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___rgba_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Byte UnityEngine.Color32::r
			uint8_t ___r_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			uint8_t ___r_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___g_2_OffsetPadding[1];
			// System.Byte UnityEngine.Color32::g
			uint8_t ___g_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___g_2_OffsetPadding_forAlignmentOnly[1];
			uint8_t ___g_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___b_3_OffsetPadding[2];
			// System.Byte UnityEngine.Color32::b
			uint8_t ___b_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___b_3_OffsetPadding_forAlignmentOnly[2];
			uint8_t ___b_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___a_4_OffsetPadding[3];
			// System.Byte UnityEngine.Color32::a
			uint8_t ___a_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___a_4_OffsetPadding_forAlignmentOnly[3];
			uint8_t ___a_4_forAlignmentOnly;
		};
	};

public:
	inline static int32_t get_offset_of_rgba_0() { return static_cast<int32_t>(offsetof(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23, ___rgba_0)); }
	inline int32_t get_rgba_0() const { return ___rgba_0; }
	inline int32_t* get_address_of_rgba_0() { return &___rgba_0; }
	inline void set_rgba_0(int32_t value)
	{
		___rgba_0 = value;
	}

	inline static int32_t get_offset_of_r_1() { return static_cast<int32_t>(offsetof(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23, ___r_1)); }
	inline uint8_t get_r_1() const { return ___r_1; }
	inline uint8_t* get_address_of_r_1() { return &___r_1; }
	inline void set_r_1(uint8_t value)
	{
		___r_1 = value;
	}

	inline static int32_t get_offset_of_g_2() { return static_cast<int32_t>(offsetof(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23, ___g_2)); }
	inline uint8_t get_g_2() const { return ___g_2; }
	inline uint8_t* get_address_of_g_2() { return &___g_2; }
	inline void set_g_2(uint8_t value)
	{
		___g_2 = value;
	}

	inline static int32_t get_offset_of_b_3() { return static_cast<int32_t>(offsetof(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23, ___b_3)); }
	inline uint8_t get_b_3() const { return ___b_3; }
	inline uint8_t* get_address_of_b_3() { return &___b_3; }
	inline void set_b_3(uint8_t value)
	{
		___b_3 = value;
	}

	inline static int32_t get_offset_of_a_4() { return static_cast<int32_t>(offsetof(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23, ___a_4)); }
	inline uint8_t get_a_4() const { return ___a_4; }
	inline uint8_t* get_address_of_a_4() { return &___a_4; }
	inline void set_a_4(uint8_t value)
	{
		___a_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR32_T23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23_H
#ifndef MATRIX4X4_T6BF60F70C9169DF14C9D2577672A44224B236ECA_H
#define MATRIX4X4_T6BF60F70C9169DF14C9D2577672A44224B236ECA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Matrix4x4
struct  Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA 
{
public:
	// System.Single UnityEngine.Matrix4x4::m00
	float ___m00_0;
	// System.Single UnityEngine.Matrix4x4::m10
	float ___m10_1;
	// System.Single UnityEngine.Matrix4x4::m20
	float ___m20_2;
	// System.Single UnityEngine.Matrix4x4::m30
	float ___m30_3;
	// System.Single UnityEngine.Matrix4x4::m01
	float ___m01_4;
	// System.Single UnityEngine.Matrix4x4::m11
	float ___m11_5;
	// System.Single UnityEngine.Matrix4x4::m21
	float ___m21_6;
	// System.Single UnityEngine.Matrix4x4::m31
	float ___m31_7;
	// System.Single UnityEngine.Matrix4x4::m02
	float ___m02_8;
	// System.Single UnityEngine.Matrix4x4::m12
	float ___m12_9;
	// System.Single UnityEngine.Matrix4x4::m22
	float ___m22_10;
	// System.Single UnityEngine.Matrix4x4::m32
	float ___m32_11;
	// System.Single UnityEngine.Matrix4x4::m03
	float ___m03_12;
	// System.Single UnityEngine.Matrix4x4::m13
	float ___m13_13;
	// System.Single UnityEngine.Matrix4x4::m23
	float ___m23_14;
	// System.Single UnityEngine.Matrix4x4::m33
	float ___m33_15;

public:
	inline static int32_t get_offset_of_m00_0() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m00_0)); }
	inline float get_m00_0() const { return ___m00_0; }
	inline float* get_address_of_m00_0() { return &___m00_0; }
	inline void set_m00_0(float value)
	{
		___m00_0 = value;
	}

	inline static int32_t get_offset_of_m10_1() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m10_1)); }
	inline float get_m10_1() const { return ___m10_1; }
	inline float* get_address_of_m10_1() { return &___m10_1; }
	inline void set_m10_1(float value)
	{
		___m10_1 = value;
	}

	inline static int32_t get_offset_of_m20_2() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m20_2)); }
	inline float get_m20_2() const { return ___m20_2; }
	inline float* get_address_of_m20_2() { return &___m20_2; }
	inline void set_m20_2(float value)
	{
		___m20_2 = value;
	}

	inline static int32_t get_offset_of_m30_3() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m30_3)); }
	inline float get_m30_3() const { return ___m30_3; }
	inline float* get_address_of_m30_3() { return &___m30_3; }
	inline void set_m30_3(float value)
	{
		___m30_3 = value;
	}

	inline static int32_t get_offset_of_m01_4() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m01_4)); }
	inline float get_m01_4() const { return ___m01_4; }
	inline float* get_address_of_m01_4() { return &___m01_4; }
	inline void set_m01_4(float value)
	{
		___m01_4 = value;
	}

	inline static int32_t get_offset_of_m11_5() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m11_5)); }
	inline float get_m11_5() const { return ___m11_5; }
	inline float* get_address_of_m11_5() { return &___m11_5; }
	inline void set_m11_5(float value)
	{
		___m11_5 = value;
	}

	inline static int32_t get_offset_of_m21_6() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m21_6)); }
	inline float get_m21_6() const { return ___m21_6; }
	inline float* get_address_of_m21_6() { return &___m21_6; }
	inline void set_m21_6(float value)
	{
		___m21_6 = value;
	}

	inline static int32_t get_offset_of_m31_7() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m31_7)); }
	inline float get_m31_7() const { return ___m31_7; }
	inline float* get_address_of_m31_7() { return &___m31_7; }
	inline void set_m31_7(float value)
	{
		___m31_7 = value;
	}

	inline static int32_t get_offset_of_m02_8() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m02_8)); }
	inline float get_m02_8() const { return ___m02_8; }
	inline float* get_address_of_m02_8() { return &___m02_8; }
	inline void set_m02_8(float value)
	{
		___m02_8 = value;
	}

	inline static int32_t get_offset_of_m12_9() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m12_9)); }
	inline float get_m12_9() const { return ___m12_9; }
	inline float* get_address_of_m12_9() { return &___m12_9; }
	inline void set_m12_9(float value)
	{
		___m12_9 = value;
	}

	inline static int32_t get_offset_of_m22_10() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m22_10)); }
	inline float get_m22_10() const { return ___m22_10; }
	inline float* get_address_of_m22_10() { return &___m22_10; }
	inline void set_m22_10(float value)
	{
		___m22_10 = value;
	}

	inline static int32_t get_offset_of_m32_11() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m32_11)); }
	inline float get_m32_11() const { return ___m32_11; }
	inline float* get_address_of_m32_11() { return &___m32_11; }
	inline void set_m32_11(float value)
	{
		___m32_11 = value;
	}

	inline static int32_t get_offset_of_m03_12() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m03_12)); }
	inline float get_m03_12() const { return ___m03_12; }
	inline float* get_address_of_m03_12() { return &___m03_12; }
	inline void set_m03_12(float value)
	{
		___m03_12 = value;
	}

	inline static int32_t get_offset_of_m13_13() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m13_13)); }
	inline float get_m13_13() const { return ___m13_13; }
	inline float* get_address_of_m13_13() { return &___m13_13; }
	inline void set_m13_13(float value)
	{
		___m13_13 = value;
	}

	inline static int32_t get_offset_of_m23_14() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m23_14)); }
	inline float get_m23_14() const { return ___m23_14; }
	inline float* get_address_of_m23_14() { return &___m23_14; }
	inline void set_m23_14(float value)
	{
		___m23_14 = value;
	}

	inline static int32_t get_offset_of_m33_15() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m33_15)); }
	inline float get_m33_15() const { return ___m33_15; }
	inline float* get_address_of_m33_15() { return &___m33_15; }
	inline void set_m33_15(float value)
	{
		___m33_15 = value;
	}
};

struct Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields
{
public:
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::zeroMatrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___zeroMatrix_16;
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::identityMatrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___identityMatrix_17;

public:
	inline static int32_t get_offset_of_zeroMatrix_16() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields, ___zeroMatrix_16)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_zeroMatrix_16() const { return ___zeroMatrix_16; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_zeroMatrix_16() { return &___zeroMatrix_16; }
	inline void set_zeroMatrix_16(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___zeroMatrix_16 = value;
	}

	inline static int32_t get_offset_of_identityMatrix_17() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields, ___identityMatrix_17)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_identityMatrix_17() const { return ___identityMatrix_17; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_identityMatrix_17() { return &___identityMatrix_17; }
	inline void set_identityMatrix_17(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___identityMatrix_17 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MATRIX4X4_T6BF60F70C9169DF14C9D2577672A44224B236ECA_H
#ifndef QUATERNION_T319F3319A7D43FFA5D819AD6C0A98851F0095357_H
#define QUATERNION_T319F3319A7D43FFA5D819AD6C0A98851F0095357_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Quaternion
struct  Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___identityQuaternion_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUATERNION_T319F3319A7D43FFA5D819AD6C0A98851F0095357_H
#ifndef VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#define VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifndef VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#define VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___zeroVector_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___oneVector_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___upVector_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___downVector_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___leftVector_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___rightVector_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___forwardVector_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___backVector_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifndef U3CSTARTU3EC__ITERATOR0_T49699E552D5107F74192EFBFB84CA9D4390B7E16_H
#define U3CSTARTU3EC__ITERATOR0_T49699E552D5107F74192EFBFB84CA9D4390B7E16_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// EnvMapAnimator_<Start>c__Iterator0
struct  U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16  : public RuntimeObject
{
public:
	// UnityEngine.Matrix4x4 EnvMapAnimator_<Start>c__Iterator0::<matrix>__0
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___U3CmatrixU3E__0_0;
	// EnvMapAnimator EnvMapAnimator_<Start>c__Iterator0::U24this
	EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73 * ___U24this_1;
	// System.Object EnvMapAnimator_<Start>c__Iterator0::U24current
	RuntimeObject * ___U24current_2;
	// System.Boolean EnvMapAnimator_<Start>c__Iterator0::U24disposing
	bool ___U24disposing_3;
	// System.Int32 EnvMapAnimator_<Start>c__Iterator0::U24PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_U3CmatrixU3E__0_0() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16, ___U3CmatrixU3E__0_0)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_U3CmatrixU3E__0_0() const { return ___U3CmatrixU3E__0_0; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_U3CmatrixU3E__0_0() { return &___U3CmatrixU3E__0_0; }
	inline void set_U3CmatrixU3E__0_0(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___U3CmatrixU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U24this_1() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16, ___U24this_1)); }
	inline EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73 * get_U24this_1() const { return ___U24this_1; }
	inline EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73 ** get_address_of_U24this_1() { return &___U24this_1; }
	inline void set_U24this_1(EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73 * value)
	{
		___U24this_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTU3EC__ITERATOR0_T49699E552D5107F74192EFBFB84CA9D4390B7E16_H
#ifndef U3CDRAGCOROUTINEU3EC__ITERATOR0_T53A0AB6AF394428462610EDBB7215EFF75E3F36D_H
#define U3CDRAGCOROUTINEU3EC__ITERATOR0_T53A0AB6AF394428462610EDBB7215EFF75E3F36D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0
struct  U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D  : public RuntimeObject
{
public:
	// UnityEngine.GameObject Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::go
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go_0;
	// UnityEngine.Vector3 Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::<currentCoordinates>__0
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___U3CcurrentCoordinatesU3E__0_1;
	// UnityEngine.EventSystems.PointerEventData Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::dragPointer
	PointerEventData_tC18994283B7753E430E316A62D9E45BA6D644C63 * ___dragPointer_2;
	// UnityEngine.Vector2 Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::screenCoordinates
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___screenCoordinates_3;
	// UnityEngine.Vector2 Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::<dragDelta>__0
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___U3CdragDeltaU3E__0_4;
	// System.Int32 Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::<i>__1
	int32_t ___U3CiU3E__1_5;
	// System.Object Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::U24current
	RuntimeObject * ___U24current_6;
	// System.Boolean Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::U24disposing
	bool ___U24disposing_7;
	// System.Int32 Puppetry.Puppet.DriverHandler_<DragCoroutine>c__Iterator0::U24PC
	int32_t ___U24PC_8;

public:
	inline static int32_t get_offset_of_go_0() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___go_0)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_go_0() const { return ___go_0; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_go_0() { return &___go_0; }
	inline void set_go_0(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___go_0 = value;
		Il2CppCodeGenWriteBarrier((&___go_0), value);
	}

	inline static int32_t get_offset_of_U3CcurrentCoordinatesU3E__0_1() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___U3CcurrentCoordinatesU3E__0_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_U3CcurrentCoordinatesU3E__0_1() const { return ___U3CcurrentCoordinatesU3E__0_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_U3CcurrentCoordinatesU3E__0_1() { return &___U3CcurrentCoordinatesU3E__0_1; }
	inline void set_U3CcurrentCoordinatesU3E__0_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___U3CcurrentCoordinatesU3E__0_1 = value;
	}

	inline static int32_t get_offset_of_dragPointer_2() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___dragPointer_2)); }
	inline PointerEventData_tC18994283B7753E430E316A62D9E45BA6D644C63 * get_dragPointer_2() const { return ___dragPointer_2; }
	inline PointerEventData_tC18994283B7753E430E316A62D9E45BA6D644C63 ** get_address_of_dragPointer_2() { return &___dragPointer_2; }
	inline void set_dragPointer_2(PointerEventData_tC18994283B7753E430E316A62D9E45BA6D644C63 * value)
	{
		___dragPointer_2 = value;
		Il2CppCodeGenWriteBarrier((&___dragPointer_2), value);
	}

	inline static int32_t get_offset_of_screenCoordinates_3() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___screenCoordinates_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_screenCoordinates_3() const { return ___screenCoordinates_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_screenCoordinates_3() { return &___screenCoordinates_3; }
	inline void set_screenCoordinates_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___screenCoordinates_3 = value;
	}

	inline static int32_t get_offset_of_U3CdragDeltaU3E__0_4() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___U3CdragDeltaU3E__0_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_U3CdragDeltaU3E__0_4() const { return ___U3CdragDeltaU3E__0_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_U3CdragDeltaU3E__0_4() { return &___U3CdragDeltaU3E__0_4; }
	inline void set_U3CdragDeltaU3E__0_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___U3CdragDeltaU3E__0_4 = value;
	}

	inline static int32_t get_offset_of_U3CiU3E__1_5() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___U3CiU3E__1_5)); }
	inline int32_t get_U3CiU3E__1_5() const { return ___U3CiU3E__1_5; }
	inline int32_t* get_address_of_U3CiU3E__1_5() { return &___U3CiU3E__1_5; }
	inline void set_U3CiU3E__1_5(int32_t value)
	{
		___U3CiU3E__1_5 = value;
	}

	inline static int32_t get_offset_of_U24current_6() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___U24current_6)); }
	inline RuntimeObject * get_U24current_6() const { return ___U24current_6; }
	inline RuntimeObject ** get_address_of_U24current_6() { return &___U24current_6; }
	inline void set_U24current_6(RuntimeObject * value)
	{
		___U24current_6 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_6), value);
	}

	inline static int32_t get_offset_of_U24disposing_7() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___U24disposing_7)); }
	inline bool get_U24disposing_7() const { return ___U24disposing_7; }
	inline bool* get_address_of_U24disposing_7() { return &___U24disposing_7; }
	inline void set_U24disposing_7(bool value)
	{
		___U24disposing_7 = value;
	}

	inline static int32_t get_offset_of_U24PC_8() { return static_cast<int32_t>(offsetof(U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D, ___U24PC_8)); }
	inline int32_t get_U24PC_8() const { return ___U24PC_8; }
	inline int32_t* get_address_of_U24PC_8() { return &___U24PC_8; }
	inline void set_U24PC_8(int32_t value)
	{
		___U24PC_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDRAGCOROUTINEU3EC__ITERATOR0_T53A0AB6AF394428462610EDBB7215EFF75E3F36D_H
#ifndef U3CHANDLEDRIVERREQUESTU3EC__ANONSTOREY2_TCE7319B26ED709B9C242041243C421F7C5907956_H
#define U3CHANDLEDRIVERREQUESTU3EC__ANONSTOREY2_TCE7319B26ED709B9C242041243C421F7C5907956_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey2
struct  U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956  : public RuntimeObject
{
public:
	// UnityEngine.Vector2 Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey2::swipeDirection
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___swipeDirection_0;
	// System.String Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey2::path
	String_t* ___path_1;
	// Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey1 Puppetry.Puppet.DriverHandler_<HandleDriverRequest>c__AnonStorey2::<>f__refU241
	U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885 * ___U3CU3Ef__refU241_2;

public:
	inline static int32_t get_offset_of_swipeDirection_0() { return static_cast<int32_t>(offsetof(U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956, ___swipeDirection_0)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_swipeDirection_0() const { return ___swipeDirection_0; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_swipeDirection_0() { return &___swipeDirection_0; }
	inline void set_swipeDirection_0(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___swipeDirection_0 = value;
	}

	inline static int32_t get_offset_of_path_1() { return static_cast<int32_t>(offsetof(U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956, ___path_1)); }
	inline String_t* get_path_1() const { return ___path_1; }
	inline String_t** get_address_of_path_1() { return &___path_1; }
	inline void set_path_1(String_t* value)
	{
		___path_1 = value;
		Il2CppCodeGenWriteBarrier((&___path_1), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__refU241_2() { return static_cast<int32_t>(offsetof(U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956, ___U3CU3Ef__refU241_2)); }
	inline U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885 * get_U3CU3Ef__refU241_2() const { return ___U3CU3Ef__refU241_2; }
	inline U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885 ** get_address_of_U3CU3Ef__refU241_2() { return &___U3CU3Ef__refU241_2; }
	inline void set_U3CU3Ef__refU241_2(U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885 * value)
	{
		___U3CU3Ef__refU241_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__refU241_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CHANDLEDRIVERREQUESTU3EC__ANONSTOREY2_TCE7319B26ED709B9C242041243C421F7C5907956_H
#ifndef CAMERAMODES_T4B24D50582F214FB9AB0B82E700305CB97C9CF9D_H
#define CAMERAMODES_T4B24D50582F214FB9AB0B82E700305CB97C9CF9D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.CameraController_CameraModes
struct  CameraModes_t4B24D50582F214FB9AB0B82E700305CB97C9CF9D 
{
public:
	// System.Int32 TMPro.Examples.CameraController_CameraModes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CameraModes_t4B24D50582F214FB9AB0B82E700305CB97C9CF9D, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERAMODES_T4B24D50582F214FB9AB0B82E700305CB97C9CF9D_H
#ifndef MOTIONTYPE_T0B038BCA79B1865C903414BFE3B65AF46B2A6833_H
#define MOTIONTYPE_T0B038BCA79B1865C903414BFE3B65AF46B2A6833_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.ObjectSpin_MotionType
struct  MotionType_t0B038BCA79B1865C903414BFE3B65AF46B2A6833 
{
public:
	// System.Int32 TMPro.Examples.ObjectSpin_MotionType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(MotionType_t0B038BCA79B1865C903414BFE3B65AF46B2A6833, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOTIONTYPE_T0B038BCA79B1865C903414BFE3B65AF46B2A6833_H
#ifndef U3CWARPTEXTU3EC__ITERATOR0_T0275814BC3ED63C685B86286D7DD936B90EC71AA_H
#define U3CWARPTEXTU3EC__ITERATOR0_T0275814BC3ED63C685B86286D7DD936B90EC71AA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0
struct  U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA  : public RuntimeObject
{
public:
	// System.Single TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<old_CurveScale>__0
	float ___U3Cold_CurveScaleU3E__0_0;
	// System.Single TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<old_ShearValue>__0
	float ___U3Cold_ShearValueU3E__0_1;
	// UnityEngine.AnimationCurve TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<old_curve>__0
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___U3Cold_curveU3E__0_2;
	// TMPro.TMP_TextInfo TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<textInfo>__1
	TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 * ___U3CtextInfoU3E__1_3;
	// System.Int32 TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<characterCount>__1
	int32_t ___U3CcharacterCountU3E__1_4;
	// System.Single TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<boundsMinX>__1
	float ___U3CboundsMinXU3E__1_5;
	// System.Single TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<boundsMaxX>__1
	float ___U3CboundsMaxXU3E__1_6;
	// UnityEngine.Vector3[] TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<vertices>__2
	Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* ___U3CverticesU3E__2_7;
	// UnityEngine.Matrix4x4 TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::<matrix>__2
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___U3CmatrixU3E__2_8;
	// TMPro.Examples.SkewTextExample TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::U24this
	SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7 * ___U24this_9;
	// System.Object TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::U24current
	RuntimeObject * ___U24current_10;
	// System.Boolean TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::U24disposing
	bool ___U24disposing_11;
	// System.Int32 TMPro.Examples.SkewTextExample_<WarpText>c__Iterator0::U24PC
	int32_t ___U24PC_12;

public:
	inline static int32_t get_offset_of_U3Cold_CurveScaleU3E__0_0() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3Cold_CurveScaleU3E__0_0)); }
	inline float get_U3Cold_CurveScaleU3E__0_0() const { return ___U3Cold_CurveScaleU3E__0_0; }
	inline float* get_address_of_U3Cold_CurveScaleU3E__0_0() { return &___U3Cold_CurveScaleU3E__0_0; }
	inline void set_U3Cold_CurveScaleU3E__0_0(float value)
	{
		___U3Cold_CurveScaleU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U3Cold_ShearValueU3E__0_1() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3Cold_ShearValueU3E__0_1)); }
	inline float get_U3Cold_ShearValueU3E__0_1() const { return ___U3Cold_ShearValueU3E__0_1; }
	inline float* get_address_of_U3Cold_ShearValueU3E__0_1() { return &___U3Cold_ShearValueU3E__0_1; }
	inline void set_U3Cold_ShearValueU3E__0_1(float value)
	{
		___U3Cold_ShearValueU3E__0_1 = value;
	}

	inline static int32_t get_offset_of_U3Cold_curveU3E__0_2() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3Cold_curveU3E__0_2)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_U3Cold_curveU3E__0_2() const { return ___U3Cold_curveU3E__0_2; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_U3Cold_curveU3E__0_2() { return &___U3Cold_curveU3E__0_2; }
	inline void set_U3Cold_curveU3E__0_2(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___U3Cold_curveU3E__0_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3Cold_curveU3E__0_2), value);
	}

	inline static int32_t get_offset_of_U3CtextInfoU3E__1_3() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3CtextInfoU3E__1_3)); }
	inline TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 * get_U3CtextInfoU3E__1_3() const { return ___U3CtextInfoU3E__1_3; }
	inline TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 ** get_address_of_U3CtextInfoU3E__1_3() { return &___U3CtextInfoU3E__1_3; }
	inline void set_U3CtextInfoU3E__1_3(TMP_TextInfo_tC40DAAB47C5BD5AD21B3F456D860474D96D9C181 * value)
	{
		___U3CtextInfoU3E__1_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CtextInfoU3E__1_3), value);
	}

	inline static int32_t get_offset_of_U3CcharacterCountU3E__1_4() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3CcharacterCountU3E__1_4)); }
	inline int32_t get_U3CcharacterCountU3E__1_4() const { return ___U3CcharacterCountU3E__1_4; }
	inline int32_t* get_address_of_U3CcharacterCountU3E__1_4() { return &___U3CcharacterCountU3E__1_4; }
	inline void set_U3CcharacterCountU3E__1_4(int32_t value)
	{
		___U3CcharacterCountU3E__1_4 = value;
	}

	inline static int32_t get_offset_of_U3CboundsMinXU3E__1_5() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3CboundsMinXU3E__1_5)); }
	inline float get_U3CboundsMinXU3E__1_5() const { return ___U3CboundsMinXU3E__1_5; }
	inline float* get_address_of_U3CboundsMinXU3E__1_5() { return &___U3CboundsMinXU3E__1_5; }
	inline void set_U3CboundsMinXU3E__1_5(float value)
	{
		___U3CboundsMinXU3E__1_5 = value;
	}

	inline static int32_t get_offset_of_U3CboundsMaxXU3E__1_6() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3CboundsMaxXU3E__1_6)); }
	inline float get_U3CboundsMaxXU3E__1_6() const { return ___U3CboundsMaxXU3E__1_6; }
	inline float* get_address_of_U3CboundsMaxXU3E__1_6() { return &___U3CboundsMaxXU3E__1_6; }
	inline void set_U3CboundsMaxXU3E__1_6(float value)
	{
		___U3CboundsMaxXU3E__1_6 = value;
	}

	inline static int32_t get_offset_of_U3CverticesU3E__2_7() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3CverticesU3E__2_7)); }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* get_U3CverticesU3E__2_7() const { return ___U3CverticesU3E__2_7; }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28** get_address_of_U3CverticesU3E__2_7() { return &___U3CverticesU3E__2_7; }
	inline void set_U3CverticesU3E__2_7(Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* value)
	{
		___U3CverticesU3E__2_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CverticesU3E__2_7), value);
	}

	inline static int32_t get_offset_of_U3CmatrixU3E__2_8() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U3CmatrixU3E__2_8)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_U3CmatrixU3E__2_8() const { return ___U3CmatrixU3E__2_8; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_U3CmatrixU3E__2_8() { return &___U3CmatrixU3E__2_8; }
	inline void set_U3CmatrixU3E__2_8(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___U3CmatrixU3E__2_8 = value;
	}

	inline static int32_t get_offset_of_U24this_9() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U24this_9)); }
	inline SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7 * get_U24this_9() const { return ___U24this_9; }
	inline SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7 ** get_address_of_U24this_9() { return &___U24this_9; }
	inline void set_U24this_9(SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7 * value)
	{
		___U24this_9 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_9), value);
	}

	inline static int32_t get_offset_of_U24current_10() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U24current_10)); }
	inline RuntimeObject * get_U24current_10() const { return ___U24current_10; }
	inline RuntimeObject ** get_address_of_U24current_10() { return &___U24current_10; }
	inline void set_U24current_10(RuntimeObject * value)
	{
		___U24current_10 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_10), value);
	}

	inline static int32_t get_offset_of_U24disposing_11() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U24disposing_11)); }
	inline bool get_U24disposing_11() const { return ___U24disposing_11; }
	inline bool* get_address_of_U24disposing_11() { return &___U24disposing_11; }
	inline void set_U24disposing_11(bool value)
	{
		___U24disposing_11 = value;
	}

	inline static int32_t get_offset_of_U24PC_12() { return static_cast<int32_t>(offsetof(U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA, ___U24PC_12)); }
	inline int32_t get_U24PC_12() const { return ___U24PC_12; }
	inline int32_t* get_address_of_U24PC_12() { return &___U24PC_12; }
	inline void set_U24PC_12(int32_t value)
	{
		___U24PC_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CWARPTEXTU3EC__ITERATOR0_T0275814BC3ED63C685B86286D7DD936B90EC71AA_H
#ifndef OBJECTTYPE_T4A9206B564B1134F55E176CB1D6A831B7F2CD0BE_H
#define OBJECTTYPE_T4A9206B564B1134F55E176CB1D6A831B7F2CD0BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TMP_ExampleScript_01_objectType
struct  objectType_t4A9206B564B1134F55E176CB1D6A831B7F2CD0BE 
{
public:
	// System.Int32 TMPro.Examples.TMP_ExampleScript_01_objectType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(objectType_t4A9206B564B1134F55E176CB1D6A831B7F2CD0BE, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJECTTYPE_T4A9206B564B1134F55E176CB1D6A831B7F2CD0BE_H
#ifndef FPSCOUNTERANCHORPOSITIONS_TF97255C7539822AFCA3511F3C0C4E6803A11EA97_H
#define FPSCOUNTERANCHORPOSITIONS_TF97255C7539822AFCA3511F3C0C4E6803A11EA97_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TMP_FrameRateCounter_FpsCounterAnchorPositions
struct  FpsCounterAnchorPositions_tF97255C7539822AFCA3511F3C0C4E6803A11EA97 
{
public:
	// System.Int32 TMPro.Examples.TMP_FrameRateCounter_FpsCounterAnchorPositions::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(FpsCounterAnchorPositions_tF97255C7539822AFCA3511F3C0C4E6803A11EA97, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FPSCOUNTERANCHORPOSITIONS_TF97255C7539822AFCA3511F3C0C4E6803A11EA97_H
#ifndef U3CDISPLAYTEXTMESHFLOATINGTEXTU3EC__ITERATOR1_T8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E_H
#define U3CDISPLAYTEXTMESHFLOATINGTEXTU3EC__ITERATOR1_T8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1
struct  U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E  : public RuntimeObject
{
public:
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<CountDuration>__0
	float ___U3CCountDurationU3E__0_0;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<starting_Count>__0
	float ___U3Cstarting_CountU3E__0_1;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<current_Count>__0
	float ___U3Ccurrent_CountU3E__0_2;
	// UnityEngine.Vector3 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<start_pos>__0
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___U3Cstart_posU3E__0_3;
	// UnityEngine.Color32 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<start_color>__0
	Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  ___U3Cstart_colorU3E__0_4;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<alpha>__0
	float ___U3CalphaU3E__0_5;
	// System.Int32 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<int_counter>__0
	int32_t ___U3Cint_counterU3E__0_6;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::<fadeDuration>__0
	float ___U3CfadeDurationU3E__0_7;
	// TMPro.Examples.TextMeshProFloatingText TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::U24this
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * ___U24this_8;
	// System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::U24current
	RuntimeObject * ___U24current_9;
	// System.Boolean TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::U24disposing
	bool ___U24disposing_10;
	// System.Int32 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>c__Iterator1::U24PC
	int32_t ___U24PC_11;

public:
	inline static int32_t get_offset_of_U3CCountDurationU3E__0_0() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3CCountDurationU3E__0_0)); }
	inline float get_U3CCountDurationU3E__0_0() const { return ___U3CCountDurationU3E__0_0; }
	inline float* get_address_of_U3CCountDurationU3E__0_0() { return &___U3CCountDurationU3E__0_0; }
	inline void set_U3CCountDurationU3E__0_0(float value)
	{
		___U3CCountDurationU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U3Cstarting_CountU3E__0_1() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3Cstarting_CountU3E__0_1)); }
	inline float get_U3Cstarting_CountU3E__0_1() const { return ___U3Cstarting_CountU3E__0_1; }
	inline float* get_address_of_U3Cstarting_CountU3E__0_1() { return &___U3Cstarting_CountU3E__0_1; }
	inline void set_U3Cstarting_CountU3E__0_1(float value)
	{
		___U3Cstarting_CountU3E__0_1 = value;
	}

	inline static int32_t get_offset_of_U3Ccurrent_CountU3E__0_2() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3Ccurrent_CountU3E__0_2)); }
	inline float get_U3Ccurrent_CountU3E__0_2() const { return ___U3Ccurrent_CountU3E__0_2; }
	inline float* get_address_of_U3Ccurrent_CountU3E__0_2() { return &___U3Ccurrent_CountU3E__0_2; }
	inline void set_U3Ccurrent_CountU3E__0_2(float value)
	{
		___U3Ccurrent_CountU3E__0_2 = value;
	}

	inline static int32_t get_offset_of_U3Cstart_posU3E__0_3() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3Cstart_posU3E__0_3)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_U3Cstart_posU3E__0_3() const { return ___U3Cstart_posU3E__0_3; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_U3Cstart_posU3E__0_3() { return &___U3Cstart_posU3E__0_3; }
	inline void set_U3Cstart_posU3E__0_3(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___U3Cstart_posU3E__0_3 = value;
	}

	inline static int32_t get_offset_of_U3Cstart_colorU3E__0_4() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3Cstart_colorU3E__0_4)); }
	inline Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  get_U3Cstart_colorU3E__0_4() const { return ___U3Cstart_colorU3E__0_4; }
	inline Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23 * get_address_of_U3Cstart_colorU3E__0_4() { return &___U3Cstart_colorU3E__0_4; }
	inline void set_U3Cstart_colorU3E__0_4(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  value)
	{
		___U3Cstart_colorU3E__0_4 = value;
	}

	inline static int32_t get_offset_of_U3CalphaU3E__0_5() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3CalphaU3E__0_5)); }
	inline float get_U3CalphaU3E__0_5() const { return ___U3CalphaU3E__0_5; }
	inline float* get_address_of_U3CalphaU3E__0_5() { return &___U3CalphaU3E__0_5; }
	inline void set_U3CalphaU3E__0_5(float value)
	{
		___U3CalphaU3E__0_5 = value;
	}

	inline static int32_t get_offset_of_U3Cint_counterU3E__0_6() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3Cint_counterU3E__0_6)); }
	inline int32_t get_U3Cint_counterU3E__0_6() const { return ___U3Cint_counterU3E__0_6; }
	inline int32_t* get_address_of_U3Cint_counterU3E__0_6() { return &___U3Cint_counterU3E__0_6; }
	inline void set_U3Cint_counterU3E__0_6(int32_t value)
	{
		___U3Cint_counterU3E__0_6 = value;
	}

	inline static int32_t get_offset_of_U3CfadeDurationU3E__0_7() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U3CfadeDurationU3E__0_7)); }
	inline float get_U3CfadeDurationU3E__0_7() const { return ___U3CfadeDurationU3E__0_7; }
	inline float* get_address_of_U3CfadeDurationU3E__0_7() { return &___U3CfadeDurationU3E__0_7; }
	inline void set_U3CfadeDurationU3E__0_7(float value)
	{
		___U3CfadeDurationU3E__0_7 = value;
	}

	inline static int32_t get_offset_of_U24this_8() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U24this_8)); }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * get_U24this_8() const { return ___U24this_8; }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 ** get_address_of_U24this_8() { return &___U24this_8; }
	inline void set_U24this_8(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * value)
	{
		___U24this_8 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_8), value);
	}

	inline static int32_t get_offset_of_U24current_9() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U24current_9)); }
	inline RuntimeObject * get_U24current_9() const { return ___U24current_9; }
	inline RuntimeObject ** get_address_of_U24current_9() { return &___U24current_9; }
	inline void set_U24current_9(RuntimeObject * value)
	{
		___U24current_9 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_9), value);
	}

	inline static int32_t get_offset_of_U24disposing_10() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U24disposing_10)); }
	inline bool get_U24disposing_10() const { return ___U24disposing_10; }
	inline bool* get_address_of_U24disposing_10() { return &___U24disposing_10; }
	inline void set_U24disposing_10(bool value)
	{
		___U24disposing_10 = value;
	}

	inline static int32_t get_offset_of_U24PC_11() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E, ___U24PC_11)); }
	inline int32_t get_U24PC_11() const { return ___U24PC_11; }
	inline int32_t* get_address_of_U24PC_11() { return &___U24PC_11; }
	inline void set_U24PC_11(int32_t value)
	{
		___U24PC_11 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDISPLAYTEXTMESHFLOATINGTEXTU3EC__ITERATOR1_T8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E_H
#ifndef U3CDISPLAYTEXTMESHPROFLOATINGTEXTU3EC__ITERATOR0_T4B346781A46C6DD8AE230D0664D0282888DC6913_H
#define U3CDISPLAYTEXTMESHPROFLOATINGTEXTU3EC__ITERATOR0_T4B346781A46C6DD8AE230D0664D0282888DC6913_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0
struct  U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913  : public RuntimeObject
{
public:
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<CountDuration>__0
	float ___U3CCountDurationU3E__0_0;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<starting_Count>__0
	float ___U3Cstarting_CountU3E__0_1;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<current_Count>__0
	float ___U3Ccurrent_CountU3E__0_2;
	// UnityEngine.Vector3 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<start_pos>__0
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___U3Cstart_posU3E__0_3;
	// UnityEngine.Color32 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<start_color>__0
	Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  ___U3Cstart_colorU3E__0_4;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<alpha>__0
	float ___U3CalphaU3E__0_5;
	// System.Int32 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<int_counter>__0
	int32_t ___U3Cint_counterU3E__0_6;
	// System.Single TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::<fadeDuration>__0
	float ___U3CfadeDurationU3E__0_7;
	// TMPro.Examples.TextMeshProFloatingText TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::U24this
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * ___U24this_8;
	// System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::U24current
	RuntimeObject * ___U24current_9;
	// System.Boolean TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::U24disposing
	bool ___U24disposing_10;
	// System.Int32 TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>c__Iterator0::U24PC
	int32_t ___U24PC_11;

public:
	inline static int32_t get_offset_of_U3CCountDurationU3E__0_0() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3CCountDurationU3E__0_0)); }
	inline float get_U3CCountDurationU3E__0_0() const { return ___U3CCountDurationU3E__0_0; }
	inline float* get_address_of_U3CCountDurationU3E__0_0() { return &___U3CCountDurationU3E__0_0; }
	inline void set_U3CCountDurationU3E__0_0(float value)
	{
		___U3CCountDurationU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U3Cstarting_CountU3E__0_1() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3Cstarting_CountU3E__0_1)); }
	inline float get_U3Cstarting_CountU3E__0_1() const { return ___U3Cstarting_CountU3E__0_1; }
	inline float* get_address_of_U3Cstarting_CountU3E__0_1() { return &___U3Cstarting_CountU3E__0_1; }
	inline void set_U3Cstarting_CountU3E__0_1(float value)
	{
		___U3Cstarting_CountU3E__0_1 = value;
	}

	inline static int32_t get_offset_of_U3Ccurrent_CountU3E__0_2() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3Ccurrent_CountU3E__0_2)); }
	inline float get_U3Ccurrent_CountU3E__0_2() const { return ___U3Ccurrent_CountU3E__0_2; }
	inline float* get_address_of_U3Ccurrent_CountU3E__0_2() { return &___U3Ccurrent_CountU3E__0_2; }
	inline void set_U3Ccurrent_CountU3E__0_2(float value)
	{
		___U3Ccurrent_CountU3E__0_2 = value;
	}

	inline static int32_t get_offset_of_U3Cstart_posU3E__0_3() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3Cstart_posU3E__0_3)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_U3Cstart_posU3E__0_3() const { return ___U3Cstart_posU3E__0_3; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_U3Cstart_posU3E__0_3() { return &___U3Cstart_posU3E__0_3; }
	inline void set_U3Cstart_posU3E__0_3(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___U3Cstart_posU3E__0_3 = value;
	}

	inline static int32_t get_offset_of_U3Cstart_colorU3E__0_4() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3Cstart_colorU3E__0_4)); }
	inline Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  get_U3Cstart_colorU3E__0_4() const { return ___U3Cstart_colorU3E__0_4; }
	inline Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23 * get_address_of_U3Cstart_colorU3E__0_4() { return &___U3Cstart_colorU3E__0_4; }
	inline void set_U3Cstart_colorU3E__0_4(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  value)
	{
		___U3Cstart_colorU3E__0_4 = value;
	}

	inline static int32_t get_offset_of_U3CalphaU3E__0_5() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3CalphaU3E__0_5)); }
	inline float get_U3CalphaU3E__0_5() const { return ___U3CalphaU3E__0_5; }
	inline float* get_address_of_U3CalphaU3E__0_5() { return &___U3CalphaU3E__0_5; }
	inline void set_U3CalphaU3E__0_5(float value)
	{
		___U3CalphaU3E__0_5 = value;
	}

	inline static int32_t get_offset_of_U3Cint_counterU3E__0_6() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3Cint_counterU3E__0_6)); }
	inline int32_t get_U3Cint_counterU3E__0_6() const { return ___U3Cint_counterU3E__0_6; }
	inline int32_t* get_address_of_U3Cint_counterU3E__0_6() { return &___U3Cint_counterU3E__0_6; }
	inline void set_U3Cint_counterU3E__0_6(int32_t value)
	{
		___U3Cint_counterU3E__0_6 = value;
	}

	inline static int32_t get_offset_of_U3CfadeDurationU3E__0_7() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U3CfadeDurationU3E__0_7)); }
	inline float get_U3CfadeDurationU3E__0_7() const { return ___U3CfadeDurationU3E__0_7; }
	inline float* get_address_of_U3CfadeDurationU3E__0_7() { return &___U3CfadeDurationU3E__0_7; }
	inline void set_U3CfadeDurationU3E__0_7(float value)
	{
		___U3CfadeDurationU3E__0_7 = value;
	}

	inline static int32_t get_offset_of_U24this_8() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U24this_8)); }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * get_U24this_8() const { return ___U24this_8; }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 ** get_address_of_U24this_8() { return &___U24this_8; }
	inline void set_U24this_8(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * value)
	{
		___U24this_8 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_8), value);
	}

	inline static int32_t get_offset_of_U24current_9() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U24current_9)); }
	inline RuntimeObject * get_U24current_9() const { return ___U24current_9; }
	inline RuntimeObject ** get_address_of_U24current_9() { return &___U24current_9; }
	inline void set_U24current_9(RuntimeObject * value)
	{
		___U24current_9 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_9), value);
	}

	inline static int32_t get_offset_of_U24disposing_10() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U24disposing_10)); }
	inline bool get_U24disposing_10() const { return ___U24disposing_10; }
	inline bool* get_address_of_U24disposing_10() { return &___U24disposing_10; }
	inline void set_U24disposing_10(bool value)
	{
		___U24disposing_10 = value;
	}

	inline static int32_t get_offset_of_U24PC_11() { return static_cast<int32_t>(offsetof(U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913, ___U24PC_11)); }
	inline int32_t get_U24PC_11() const { return ___U24PC_11; }
	inline int32_t* get_address_of_U24PC_11() { return &___U24PC_11; }
	inline void set_U24PC_11(int32_t value)
	{
		___U24PC_11 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDISPLAYTEXTMESHPROFLOATINGTEXTU3EC__ITERATOR0_T4B346781A46C6DD8AE230D0664D0282888DC6913_H
#ifndef KEYCODE_TC93EA87C5A6901160B583ADFCD3EF6726570DC3C_H
#define KEYCODE_TC93EA87C5A6901160B583ADFCD3EF6726570DC3C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.KeyCode
struct  KeyCode_tC93EA87C5A6901160B583ADFCD3EF6726570DC3C 
{
public:
	// System.Int32 UnityEngine.KeyCode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(KeyCode_tC93EA87C5A6901160B583ADFCD3EF6726570DC3C, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYCODE_TC93EA87C5A6901160B583ADFCD3EF6726570DC3C_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#define RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RaycastHit2D
struct  RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE 
{
public:
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Centroid
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Centroid_0;
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Point
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Point_1;
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Normal
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Normal_2;
	// System.Single UnityEngine.RaycastHit2D::m_Distance
	float ___m_Distance_3;
	// System.Single UnityEngine.RaycastHit2D::m_Fraction
	float ___m_Fraction_4;
	// System.Int32 UnityEngine.RaycastHit2D::m_Collider
	int32_t ___m_Collider_5;

public:
	inline static int32_t get_offset_of_m_Centroid_0() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Centroid_0)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Centroid_0() const { return ___m_Centroid_0; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Centroid_0() { return &___m_Centroid_0; }
	inline void set_m_Centroid_0(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Centroid_0 = value;
	}

	inline static int32_t get_offset_of_m_Point_1() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Point_1)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Point_1() const { return ___m_Point_1; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Point_1() { return &___m_Point_1; }
	inline void set_m_Point_1(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Point_1 = value;
	}

	inline static int32_t get_offset_of_m_Normal_2() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Normal_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Normal_2() const { return ___m_Normal_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Normal_2() { return &___m_Normal_2; }
	inline void set_m_Normal_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Normal_2 = value;
	}

	inline static int32_t get_offset_of_m_Distance_3() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Distance_3)); }
	inline float get_m_Distance_3() const { return ___m_Distance_3; }
	inline float* get_address_of_m_Distance_3() { return &___m_Distance_3; }
	inline void set_m_Distance_3(float value)
	{
		___m_Distance_3 = value;
	}

	inline static int32_t get_offset_of_m_Fraction_4() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Fraction_4)); }
	inline float get_m_Fraction_4() const { return ___m_Fraction_4; }
	inline float* get_address_of_m_Fraction_4() { return &___m_Fraction_4; }
	inline void set_m_Fraction_4(float value)
	{
		___m_Fraction_4 = value;
	}

	inline static int32_t get_offset_of_m_Collider_5() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Collider_5)); }
	inline int32_t get_m_Collider_5() const { return ___m_Collider_5; }
	inline int32_t* get_address_of_m_Collider_5() { return &___m_Collider_5; }
	inline void set_m_Collider_5(int32_t value)
	{
		___m_Collider_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#define SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};
#endif // SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifndef TMP_INPUTVALIDATOR_T4C673E12211AFB82AAF94D9DEA556FDC306E69CD_H
#define TMP_INPUTVALIDATOR_T4C673E12211AFB82AAF94D9DEA556FDC306E69CD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.TMP_InputValidator
struct  TMP_InputValidator_t4C673E12211AFB82AAF94D9DEA556FDC306E69CD  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TMP_INPUTVALIDATOR_T4C673E12211AFB82AAF94D9DEA556FDC306E69CD_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef TMP_DIGITVALIDATOR_TD53B3EF123D04F923055895ED56555317D239AB5_H
#define TMP_DIGITVALIDATOR_TD53B3EF123D04F923055895ED56555317D239AB5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.TMP_DigitValidator
struct  TMP_DigitValidator_tD53B3EF123D04F923055895ED56555317D239AB5  : public TMP_InputValidator_t4C673E12211AFB82AAF94D9DEA556FDC306E69CD
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TMP_DIGITVALIDATOR_TD53B3EF123D04F923055895ED56555317D239AB5_H
#ifndef TMP_PHONENUMBERVALIDATOR_T7EB41CFDB7C6AA586BF5AF04151FC2228F565BD2_H
#define TMP_PHONENUMBERVALIDATOR_T7EB41CFDB7C6AA586BF5AF04151FC2228F565BD2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.TMP_PhoneNumberValidator
struct  TMP_PhoneNumberValidator_t7EB41CFDB7C6AA586BF5AF04151FC2228F565BD2  : public TMP_InputValidator_t4C673E12211AFB82AAF94D9DEA556FDC306E69CD
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TMP_PHONENUMBERVALIDATOR_T7EB41CFDB7C6AA586BF5AF04151FC2228F565BD2_H
#ifndef MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#define MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifndef CHATCONTROLLER_T49D7A1D868EED265CD37C4469FAFCF44235384FB_H
#define CHATCONTROLLER_T49D7A1D868EED265CD37C4469FAFCF44235384FB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ChatController
struct  ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.TMP_InputField ChatController::TMP_ChatInput
	TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB * ___TMP_ChatInput_4;
	// TMPro.TMP_Text ChatController::TMP_ChatOutput
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___TMP_ChatOutput_5;
	// UnityEngine.UI.Scrollbar ChatController::ChatScrollbar
	Scrollbar_t8F8679D0EAFACBCBD603E6B0E741E6A783DB3389 * ___ChatScrollbar_6;

public:
	inline static int32_t get_offset_of_TMP_ChatInput_4() { return static_cast<int32_t>(offsetof(ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB, ___TMP_ChatInput_4)); }
	inline TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB * get_TMP_ChatInput_4() const { return ___TMP_ChatInput_4; }
	inline TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB ** get_address_of_TMP_ChatInput_4() { return &___TMP_ChatInput_4; }
	inline void set_TMP_ChatInput_4(TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB * value)
	{
		___TMP_ChatInput_4 = value;
		Il2CppCodeGenWriteBarrier((&___TMP_ChatInput_4), value);
	}

	inline static int32_t get_offset_of_TMP_ChatOutput_5() { return static_cast<int32_t>(offsetof(ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB, ___TMP_ChatOutput_5)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_TMP_ChatOutput_5() const { return ___TMP_ChatOutput_5; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_TMP_ChatOutput_5() { return &___TMP_ChatOutput_5; }
	inline void set_TMP_ChatOutput_5(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___TMP_ChatOutput_5 = value;
		Il2CppCodeGenWriteBarrier((&___TMP_ChatOutput_5), value);
	}

	inline static int32_t get_offset_of_ChatScrollbar_6() { return static_cast<int32_t>(offsetof(ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB, ___ChatScrollbar_6)); }
	inline Scrollbar_t8F8679D0EAFACBCBD603E6B0E741E6A783DB3389 * get_ChatScrollbar_6() const { return ___ChatScrollbar_6; }
	inline Scrollbar_t8F8679D0EAFACBCBD603E6B0E741E6A783DB3389 ** get_address_of_ChatScrollbar_6() { return &___ChatScrollbar_6; }
	inline void set_ChatScrollbar_6(Scrollbar_t8F8679D0EAFACBCBD603E6B0E741E6A783DB3389 * value)
	{
		___ChatScrollbar_6 = value;
		Il2CppCodeGenWriteBarrier((&___ChatScrollbar_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHATCONTROLLER_T49D7A1D868EED265CD37C4469FAFCF44235384FB_H
#ifndef ELIMINATE_TD19E434B1BA30A6843A103A9C12F718FC7CEB58C_H
#define ELIMINATE_TD19E434B1BA30A6843A103A9C12F718FC7CEB58C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Eliminate
struct  Eliminate_tD19E434B1BA30A6843A103A9C12F718FC7CEB58C  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ELIMINATE_TD19E434B1BA30A6843A103A9C12F718FC7CEB58C_H
#ifndef ENEMYCOLLIDER_TA27BF3664568741AC689D0579029618549B94906_H
#define ENEMYCOLLIDER_TA27BF3664568741AC689D0579029618549B94906_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// EnemyCollider
struct  EnemyCollider_tA27BF3664568741AC689D0579029618549B94906  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 EnemyCollider::killScore
	int32_t ___killScore_4;
	// System.Int32 EnemyCollider::enemyMaxHP
	int32_t ___enemyMaxHP_5;
	// System.Int32 EnemyCollider::damage
	int32_t ___damage_6;
	// System.Boolean EnemyCollider::collisionDetected
	bool ___collisionDetected_7;
	// UnityEngine.GameObject EnemyCollider::scoreText
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___scoreText_8;
	// UnityEngine.GameObject EnemyCollider::explosionAnimationObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___explosionAnimationObject_9;
	// System.Boolean EnemyCollider::isBlinkable
	bool ___isBlinkable_10;

public:
	inline static int32_t get_offset_of_killScore_4() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___killScore_4)); }
	inline int32_t get_killScore_4() const { return ___killScore_4; }
	inline int32_t* get_address_of_killScore_4() { return &___killScore_4; }
	inline void set_killScore_4(int32_t value)
	{
		___killScore_4 = value;
	}

	inline static int32_t get_offset_of_enemyMaxHP_5() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___enemyMaxHP_5)); }
	inline int32_t get_enemyMaxHP_5() const { return ___enemyMaxHP_5; }
	inline int32_t* get_address_of_enemyMaxHP_5() { return &___enemyMaxHP_5; }
	inline void set_enemyMaxHP_5(int32_t value)
	{
		___enemyMaxHP_5 = value;
	}

	inline static int32_t get_offset_of_damage_6() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___damage_6)); }
	inline int32_t get_damage_6() const { return ___damage_6; }
	inline int32_t* get_address_of_damage_6() { return &___damage_6; }
	inline void set_damage_6(int32_t value)
	{
		___damage_6 = value;
	}

	inline static int32_t get_offset_of_collisionDetected_7() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___collisionDetected_7)); }
	inline bool get_collisionDetected_7() const { return ___collisionDetected_7; }
	inline bool* get_address_of_collisionDetected_7() { return &___collisionDetected_7; }
	inline void set_collisionDetected_7(bool value)
	{
		___collisionDetected_7 = value;
	}

	inline static int32_t get_offset_of_scoreText_8() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___scoreText_8)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_scoreText_8() const { return ___scoreText_8; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_scoreText_8() { return &___scoreText_8; }
	inline void set_scoreText_8(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___scoreText_8 = value;
		Il2CppCodeGenWriteBarrier((&___scoreText_8), value);
	}

	inline static int32_t get_offset_of_explosionAnimationObject_9() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___explosionAnimationObject_9)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_explosionAnimationObject_9() const { return ___explosionAnimationObject_9; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_explosionAnimationObject_9() { return &___explosionAnimationObject_9; }
	inline void set_explosionAnimationObject_9(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___explosionAnimationObject_9 = value;
		Il2CppCodeGenWriteBarrier((&___explosionAnimationObject_9), value);
	}

	inline static int32_t get_offset_of_isBlinkable_10() { return static_cast<int32_t>(offsetof(EnemyCollider_tA27BF3664568741AC689D0579029618549B94906, ___isBlinkable_10)); }
	inline bool get_isBlinkable_10() const { return ___isBlinkable_10; }
	inline bool* get_address_of_isBlinkable_10() { return &___isBlinkable_10; }
	inline void set_isBlinkable_10(bool value)
	{
		___isBlinkable_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENEMYCOLLIDER_TA27BF3664568741AC689D0579029618549B94906_H
#ifndef ENEMYMISSILE_T5B59658B2A3A83D8D000EDD07D448C9821E5D616_H
#define ENEMYMISSILE_T5B59658B2A3A83D8D000EDD07D448C9821E5D616_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// EnemyMissile
struct  EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single EnemyMissile::missileSpeed
	float ___missileSpeed_4;
	// UnityEngine.Vector2 EnemyMissile::missileDirection
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___missileDirection_5;
	// UnityEngine.Vector2 EnemyMissile::missilePosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___missilePosition_6;
	// System.Boolean EnemyMissile::isDirectionSet
	bool ___isDirectionSet_7;
	// UnityEngine.Vector2 EnemyMissile::topRight
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___topRight_8;
	// UnityEngine.Vector2 EnemyMissile::bottomLeft
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___bottomLeft_9;

public:
	inline static int32_t get_offset_of_missileSpeed_4() { return static_cast<int32_t>(offsetof(EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616, ___missileSpeed_4)); }
	inline float get_missileSpeed_4() const { return ___missileSpeed_4; }
	inline float* get_address_of_missileSpeed_4() { return &___missileSpeed_4; }
	inline void set_missileSpeed_4(float value)
	{
		___missileSpeed_4 = value;
	}

	inline static int32_t get_offset_of_missileDirection_5() { return static_cast<int32_t>(offsetof(EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616, ___missileDirection_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_missileDirection_5() const { return ___missileDirection_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_missileDirection_5() { return &___missileDirection_5; }
	inline void set_missileDirection_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___missileDirection_5 = value;
	}

	inline static int32_t get_offset_of_missilePosition_6() { return static_cast<int32_t>(offsetof(EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616, ___missilePosition_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_missilePosition_6() const { return ___missilePosition_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_missilePosition_6() { return &___missilePosition_6; }
	inline void set_missilePosition_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___missilePosition_6 = value;
	}

	inline static int32_t get_offset_of_isDirectionSet_7() { return static_cast<int32_t>(offsetof(EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616, ___isDirectionSet_7)); }
	inline bool get_isDirectionSet_7() const { return ___isDirectionSet_7; }
	inline bool* get_address_of_isDirectionSet_7() { return &___isDirectionSet_7; }
	inline void set_isDirectionSet_7(bool value)
	{
		___isDirectionSet_7 = value;
	}

	inline static int32_t get_offset_of_topRight_8() { return static_cast<int32_t>(offsetof(EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616, ___topRight_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_topRight_8() const { return ___topRight_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_topRight_8() { return &___topRight_8; }
	inline void set_topRight_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___topRight_8 = value;
	}

	inline static int32_t get_offset_of_bottomLeft_9() { return static_cast<int32_t>(offsetof(EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616, ___bottomLeft_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_bottomLeft_9() const { return ___bottomLeft_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_bottomLeft_9() { return &___bottomLeft_9; }
	inline void set_bottomLeft_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___bottomLeft_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENEMYMISSILE_T5B59658B2A3A83D8D000EDD07D448C9821E5D616_H
#ifndef ENEMYSHOOTER_T98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40_H
#define ENEMYSHOOTER_T98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// EnemyShooter
struct  EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject EnemyShooter::enemyMissile
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___enemyMissile_4;
	// UnityEngine.Transform EnemyShooter::playerShip
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___playerShip_5;
	// UnityEngine.Vector2 EnemyShooter::direction
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___direction_6;
	// System.Single EnemyShooter::startTime
	float ___startTime_7;
	// System.Single EnemyShooter::repeatTime
	float ___repeatTime_8;

public:
	inline static int32_t get_offset_of_enemyMissile_4() { return static_cast<int32_t>(offsetof(EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40, ___enemyMissile_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_enemyMissile_4() const { return ___enemyMissile_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_enemyMissile_4() { return &___enemyMissile_4; }
	inline void set_enemyMissile_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___enemyMissile_4 = value;
		Il2CppCodeGenWriteBarrier((&___enemyMissile_4), value);
	}

	inline static int32_t get_offset_of_playerShip_5() { return static_cast<int32_t>(offsetof(EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40, ___playerShip_5)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_playerShip_5() const { return ___playerShip_5; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_playerShip_5() { return &___playerShip_5; }
	inline void set_playerShip_5(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___playerShip_5 = value;
		Il2CppCodeGenWriteBarrier((&___playerShip_5), value);
	}

	inline static int32_t get_offset_of_direction_6() { return static_cast<int32_t>(offsetof(EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40, ___direction_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_direction_6() const { return ___direction_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_direction_6() { return &___direction_6; }
	inline void set_direction_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___direction_6 = value;
	}

	inline static int32_t get_offset_of_startTime_7() { return static_cast<int32_t>(offsetof(EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40, ___startTime_7)); }
	inline float get_startTime_7() const { return ___startTime_7; }
	inline float* get_address_of_startTime_7() { return &___startTime_7; }
	inline void set_startTime_7(float value)
	{
		___startTime_7 = value;
	}

	inline static int32_t get_offset_of_repeatTime_8() { return static_cast<int32_t>(offsetof(EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40, ___repeatTime_8)); }
	inline float get_repeatTime_8() const { return ___repeatTime_8; }
	inline float* get_address_of_repeatTime_8() { return &___repeatTime_8; }
	inline void set_repeatTime_8(float value)
	{
		___repeatTime_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENEMYSHOOTER_T98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40_H
#ifndef ENVMAPANIMATOR_T32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73_H
#define ENVMAPANIMATOR_T32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// EnvMapAnimator
struct  EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Vector3 EnvMapAnimator::RotationSpeeds
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___RotationSpeeds_4;
	// TMPro.TMP_Text EnvMapAnimator::m_textMeshPro
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___m_textMeshPro_5;
	// UnityEngine.Material EnvMapAnimator::m_material
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___m_material_6;

public:
	inline static int32_t get_offset_of_RotationSpeeds_4() { return static_cast<int32_t>(offsetof(EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73, ___RotationSpeeds_4)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_RotationSpeeds_4() const { return ___RotationSpeeds_4; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_RotationSpeeds_4() { return &___RotationSpeeds_4; }
	inline void set_RotationSpeeds_4(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___RotationSpeeds_4 = value;
	}

	inline static int32_t get_offset_of_m_textMeshPro_5() { return static_cast<int32_t>(offsetof(EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73, ___m_textMeshPro_5)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_m_textMeshPro_5() const { return ___m_textMeshPro_5; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_m_textMeshPro_5() { return &___m_textMeshPro_5; }
	inline void set_m_textMeshPro_5(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___m_textMeshPro_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMeshPro_5), value);
	}

	inline static int32_t get_offset_of_m_material_6() { return static_cast<int32_t>(offsetof(EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73, ___m_material_6)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_m_material_6() const { return ___m_material_6; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_m_material_6() { return &___m_material_6; }
	inline void set_m_material_6(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___m_material_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_material_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENVMAPANIMATOR_T32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73_H
#ifndef FOLLOW_T6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB_H
#define FOLLOW_T6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Follow
struct  Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single Follow::speed
	float ___speed_4;
	// System.Boolean Follow::stopped
	bool ___stopped_5;
	// UnityEngine.GameObject Follow::player
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___player_6;
	// UnityEngine.Transform Follow::stop
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___stop_7;
	// System.Single Follow::stoppingDistance
	float ___stoppingDistance_8;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_stopped_5() { return static_cast<int32_t>(offsetof(Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB, ___stopped_5)); }
	inline bool get_stopped_5() const { return ___stopped_5; }
	inline bool* get_address_of_stopped_5() { return &___stopped_5; }
	inline void set_stopped_5(bool value)
	{
		___stopped_5 = value;
	}

	inline static int32_t get_offset_of_player_6() { return static_cast<int32_t>(offsetof(Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB, ___player_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_player_6() const { return ___player_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_player_6() { return &___player_6; }
	inline void set_player_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___player_6 = value;
		Il2CppCodeGenWriteBarrier((&___player_6), value);
	}

	inline static int32_t get_offset_of_stop_7() { return static_cast<int32_t>(offsetof(Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB, ___stop_7)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_stop_7() const { return ___stop_7; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_stop_7() { return &___stop_7; }
	inline void set_stop_7(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___stop_7 = value;
		Il2CppCodeGenWriteBarrier((&___stop_7), value);
	}

	inline static int32_t get_offset_of_stoppingDistance_8() { return static_cast<int32_t>(offsetof(Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB, ___stoppingDistance_8)); }
	inline float get_stoppingDistance_8() const { return ___stoppingDistance_8; }
	inline float* get_address_of_stoppingDistance_8() { return &___stoppingDistance_8; }
	inline void set_stoppingDistance_8(float value)
	{
		___stoppingDistance_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FOLLOW_T6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB_H
#ifndef GAMEMANAGER_T0CECDB772A95511D7F1B74DA25E1BDA4BEE39258_H
#define GAMEMANAGER_T0CECDB772A95511D7F1B74DA25E1BDA4BEE39258_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// GameManager
struct  GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject GameManager::gameOver
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameOver_4;
	// UnityEngine.GameObject GameManager::spawnManager
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___spawnManager_5;
	// System.Boolean GameManager::gameIsOver
	bool ___gameIsOver_6;

public:
	inline static int32_t get_offset_of_gameOver_4() { return static_cast<int32_t>(offsetof(GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258, ___gameOver_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_gameOver_4() const { return ___gameOver_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_gameOver_4() { return &___gameOver_4; }
	inline void set_gameOver_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___gameOver_4 = value;
		Il2CppCodeGenWriteBarrier((&___gameOver_4), value);
	}

	inline static int32_t get_offset_of_spawnManager_5() { return static_cast<int32_t>(offsetof(GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258, ___spawnManager_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_spawnManager_5() const { return ___spawnManager_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_spawnManager_5() { return &___spawnManager_5; }
	inline void set_spawnManager_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___spawnManager_5 = value;
		Il2CppCodeGenWriteBarrier((&___spawnManager_5), value);
	}

	inline static int32_t get_offset_of_gameIsOver_6() { return static_cast<int32_t>(offsetof(GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258, ___gameIsOver_6)); }
	inline bool get_gameIsOver_6() const { return ___gameIsOver_6; }
	inline bool* get_address_of_gameIsOver_6() { return &___gameIsOver_6; }
	inline void set_gameIsOver_6(bool value)
	{
		___gameIsOver_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GAMEMANAGER_T0CECDB772A95511D7F1B74DA25E1BDA4BEE39258_H
#ifndef GAMEMENU_T152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_H
#define GAMEMENU_T152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// GameMenu
struct  GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.KeyCode GameMenu::pauseKey
	int32_t ___pauseKey_5;
	// UnityEngine.GameObject GameMenu::gameMenuUI
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameMenuUI_6;

public:
	inline static int32_t get_offset_of_pauseKey_5() { return static_cast<int32_t>(offsetof(GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89, ___pauseKey_5)); }
	inline int32_t get_pauseKey_5() const { return ___pauseKey_5; }
	inline int32_t* get_address_of_pauseKey_5() { return &___pauseKey_5; }
	inline void set_pauseKey_5(int32_t value)
	{
		___pauseKey_5 = value;
	}

	inline static int32_t get_offset_of_gameMenuUI_6() { return static_cast<int32_t>(offsetof(GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89, ___gameMenuUI_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_gameMenuUI_6() const { return ___gameMenuUI_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_gameMenuUI_6() { return &___gameMenuUI_6; }
	inline void set_gameMenuUI_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___gameMenuUI_6 = value;
		Il2CppCodeGenWriteBarrier((&___gameMenuUI_6), value);
	}
};

struct GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_StaticFields
{
public:
	// System.Boolean GameMenu::<Paused>k__BackingField
	bool ___U3CPausedU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_U3CPausedU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_StaticFields, ___U3CPausedU3Ek__BackingField_4)); }
	inline bool get_U3CPausedU3Ek__BackingField_4() const { return ___U3CPausedU3Ek__BackingField_4; }
	inline bool* get_address_of_U3CPausedU3Ek__BackingField_4() { return &___U3CPausedU3Ek__BackingField_4; }
	inline void set_U3CPausedU3Ek__BackingField_4(bool value)
	{
		___U3CPausedU3Ek__BackingField_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GAMEMENU_T152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_H
#ifndef GUNNER_T4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45_H
#define GUNNER_T4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Gunner
struct  Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single Gunner::speed
	float ___speed_4;
	// System.Single Gunner::maxDistance
	float ___maxDistance_5;
	// UnityEngine.Vector2 Gunner::bottomLeft
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___bottomLeft_6;
	// UnityEngine.Vector2 Gunner::gunnerPosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___gunnerPosition_7;
	// UnityEngine.Vector2 Gunner::nextPosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___nextPosition_8;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_maxDistance_5() { return static_cast<int32_t>(offsetof(Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45, ___maxDistance_5)); }
	inline float get_maxDistance_5() const { return ___maxDistance_5; }
	inline float* get_address_of_maxDistance_5() { return &___maxDistance_5; }
	inline void set_maxDistance_5(float value)
	{
		___maxDistance_5 = value;
	}

	inline static int32_t get_offset_of_bottomLeft_6() { return static_cast<int32_t>(offsetof(Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45, ___bottomLeft_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_bottomLeft_6() const { return ___bottomLeft_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_bottomLeft_6() { return &___bottomLeft_6; }
	inline void set_bottomLeft_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___bottomLeft_6 = value;
	}

	inline static int32_t get_offset_of_gunnerPosition_7() { return static_cast<int32_t>(offsetof(Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45, ___gunnerPosition_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_gunnerPosition_7() const { return ___gunnerPosition_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_gunnerPosition_7() { return &___gunnerPosition_7; }
	inline void set_gunnerPosition_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___gunnerPosition_7 = value;
	}

	inline static int32_t get_offset_of_nextPosition_8() { return static_cast<int32_t>(offsetof(Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45, ___nextPosition_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_nextPosition_8() const { return ___nextPosition_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_nextPosition_8() { return &___nextPosition_8; }
	inline void set_nextPosition_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___nextPosition_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GUNNER_T4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45_H
#ifndef HEALTHPOINTS_TC670158B3E1CFD400DEF519CAD7AE417B30A5FDC_H
#define HEALTHPOINTS_TC670158B3E1CFD400DEF519CAD7AE417B30A5FDC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// HealthPoints
struct  HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.Text HealthPoints::livesText
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___livesText_5;
	// UnityEngine.UI.Image HealthPoints::healthBar
	Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * ___healthBar_6;
	// System.Int32 HealthPoints::currentLives
	int32_t ___currentLives_7;
	// System.Single HealthPoints::<DamageHP>k__BackingField
	float ___U3CDamageHPU3Ek__BackingField_8;
	// System.Single HealthPoints::<MaxHP>k__BackingField
	float ___U3CMaxHPU3Ek__BackingField_9;
	// System.Single HealthPoints::hpRatio
	float ___hpRatio_10;

public:
	inline static int32_t get_offset_of_livesText_5() { return static_cast<int32_t>(offsetof(HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC, ___livesText_5)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_livesText_5() const { return ___livesText_5; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_livesText_5() { return &___livesText_5; }
	inline void set_livesText_5(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___livesText_5 = value;
		Il2CppCodeGenWriteBarrier((&___livesText_5), value);
	}

	inline static int32_t get_offset_of_healthBar_6() { return static_cast<int32_t>(offsetof(HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC, ___healthBar_6)); }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * get_healthBar_6() const { return ___healthBar_6; }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E ** get_address_of_healthBar_6() { return &___healthBar_6; }
	inline void set_healthBar_6(Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * value)
	{
		___healthBar_6 = value;
		Il2CppCodeGenWriteBarrier((&___healthBar_6), value);
	}

	inline static int32_t get_offset_of_currentLives_7() { return static_cast<int32_t>(offsetof(HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC, ___currentLives_7)); }
	inline int32_t get_currentLives_7() const { return ___currentLives_7; }
	inline int32_t* get_address_of_currentLives_7() { return &___currentLives_7; }
	inline void set_currentLives_7(int32_t value)
	{
		___currentLives_7 = value;
	}

	inline static int32_t get_offset_of_U3CDamageHPU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC, ___U3CDamageHPU3Ek__BackingField_8)); }
	inline float get_U3CDamageHPU3Ek__BackingField_8() const { return ___U3CDamageHPU3Ek__BackingField_8; }
	inline float* get_address_of_U3CDamageHPU3Ek__BackingField_8() { return &___U3CDamageHPU3Ek__BackingField_8; }
	inline void set_U3CDamageHPU3Ek__BackingField_8(float value)
	{
		___U3CDamageHPU3Ek__BackingField_8 = value;
	}

	inline static int32_t get_offset_of_U3CMaxHPU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC, ___U3CMaxHPU3Ek__BackingField_9)); }
	inline float get_U3CMaxHPU3Ek__BackingField_9() const { return ___U3CMaxHPU3Ek__BackingField_9; }
	inline float* get_address_of_U3CMaxHPU3Ek__BackingField_9() { return &___U3CMaxHPU3Ek__BackingField_9; }
	inline void set_U3CMaxHPU3Ek__BackingField_9(float value)
	{
		___U3CMaxHPU3Ek__BackingField_9 = value;
	}

	inline static int32_t get_offset_of_hpRatio_10() { return static_cast<int32_t>(offsetof(HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC, ___hpRatio_10)); }
	inline float get_hpRatio_10() const { return ___hpRatio_10; }
	inline float* get_address_of_hpRatio_10() { return &___hpRatio_10; }
	inline void set_hpRatio_10(float value)
	{
		___hpRatio_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HEALTHPOINTS_TC670158B3E1CFD400DEF519CAD7AE417B30A5FDC_H
#ifndef HEARTCOLLIDER_T8500C8D4D1517183AC18F2687487198EF403BF7D_H
#define HEARTCOLLIDER_T8500C8D4D1517183AC18F2687487198EF403BF7D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// HeartCollider
struct  HeartCollider_t8500C8D4D1517183AC18F2687487198EF403BF7D  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject HeartCollider::playerShip
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___playerShip_4;
	// System.Boolean HeartCollider::isBlinkable
	bool ___isBlinkable_5;

public:
	inline static int32_t get_offset_of_playerShip_4() { return static_cast<int32_t>(offsetof(HeartCollider_t8500C8D4D1517183AC18F2687487198EF403BF7D, ___playerShip_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_playerShip_4() const { return ___playerShip_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_playerShip_4() { return &___playerShip_4; }
	inline void set_playerShip_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___playerShip_4 = value;
		Il2CppCodeGenWriteBarrier((&___playerShip_4), value);
	}

	inline static int32_t get_offset_of_isBlinkable_5() { return static_cast<int32_t>(offsetof(HeartCollider_t8500C8D4D1517183AC18F2687487198EF403BF7D, ___isBlinkable_5)); }
	inline bool get_isBlinkable_5() const { return ___isBlinkable_5; }
	inline bool* get_address_of_isBlinkable_5() { return &___isBlinkable_5; }
	inline void set_isBlinkable_5(bool value)
	{
		___isBlinkable_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HEARTCOLLIDER_T8500C8D4D1517183AC18F2687487198EF403BF7D_H
#ifndef MENU_T92DE8FC91DDF60C97E1542988D57700F9882B3B5_H
#define MENU_T92DE8FC91DDF60C97E1542988D57700F9882B3B5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Menu
struct  Menu_t92DE8FC91DDF60C97E1542988D57700F9882B3B5  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MENU_T92DE8FC91DDF60C97E1542988D57700F9882B3B5_H
#ifndef MISSILECOLLIDER_TD7605E471DEE089998553FB9DD4251081E878FEB_H
#define MISSILECOLLIDER_TD7605E471DEE089998553FB9DD4251081E878FEB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MissileCollider
struct  MissileCollider_tD7605E471DEE089998553FB9DD4251081E878FEB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MISSILECOLLIDER_TD7605E471DEE089998553FB9DD4251081E878FEB_H
#ifndef MOTHERSHIP_T89DEA61980C543BB64202F85B98CBAF7B2711D30_H
#define MOTHERSHIP_T89DEA61980C543BB64202F85B98CBAF7B2711D30_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MotherShip
struct  MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single MotherShip::speed
	float ___speed_4;
	// System.Single MotherShip::startWaitTime
	float ___startWaitTime_5;
	// System.Single MotherShip::waitTime
	float ___waitTime_6;
	// System.Int32 MotherShip::randomPosition
	int32_t ___randomPosition_7;
	// System.Collections.Generic.List`1<UnityEngine.Transform> MotherShip::movingPositions
	List_1_t1863EF4EE1FDEED14D460C85AF61BE0850892F6D * ___movingPositions_8;
	// UnityEngine.GameObject[] MotherShip::positionObjects
	GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* ___positionObjects_9;
	// UnityEngine.Transform MotherShip::playerShip
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___playerShip_10;
	// UnityEngine.Vector2 MotherShip::direction
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___direction_11;
	// System.Single MotherShip::rotationSpeed
	float ___rotationSpeed_12;
	// UnityEngine.Vector2 MotherShip::topRight
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___topRight_13;
	// UnityEngine.Vector2 MotherShip::bottomLeft
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___bottomLeft_14;
	// UnityEngine.GameObject MotherShip::spawnManager
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___spawnManager_15;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_startWaitTime_5() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___startWaitTime_5)); }
	inline float get_startWaitTime_5() const { return ___startWaitTime_5; }
	inline float* get_address_of_startWaitTime_5() { return &___startWaitTime_5; }
	inline void set_startWaitTime_5(float value)
	{
		___startWaitTime_5 = value;
	}

	inline static int32_t get_offset_of_waitTime_6() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___waitTime_6)); }
	inline float get_waitTime_6() const { return ___waitTime_6; }
	inline float* get_address_of_waitTime_6() { return &___waitTime_6; }
	inline void set_waitTime_6(float value)
	{
		___waitTime_6 = value;
	}

	inline static int32_t get_offset_of_randomPosition_7() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___randomPosition_7)); }
	inline int32_t get_randomPosition_7() const { return ___randomPosition_7; }
	inline int32_t* get_address_of_randomPosition_7() { return &___randomPosition_7; }
	inline void set_randomPosition_7(int32_t value)
	{
		___randomPosition_7 = value;
	}

	inline static int32_t get_offset_of_movingPositions_8() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___movingPositions_8)); }
	inline List_1_t1863EF4EE1FDEED14D460C85AF61BE0850892F6D * get_movingPositions_8() const { return ___movingPositions_8; }
	inline List_1_t1863EF4EE1FDEED14D460C85AF61BE0850892F6D ** get_address_of_movingPositions_8() { return &___movingPositions_8; }
	inline void set_movingPositions_8(List_1_t1863EF4EE1FDEED14D460C85AF61BE0850892F6D * value)
	{
		___movingPositions_8 = value;
		Il2CppCodeGenWriteBarrier((&___movingPositions_8), value);
	}

	inline static int32_t get_offset_of_positionObjects_9() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___positionObjects_9)); }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* get_positionObjects_9() const { return ___positionObjects_9; }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520** get_address_of_positionObjects_9() { return &___positionObjects_9; }
	inline void set_positionObjects_9(GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* value)
	{
		___positionObjects_9 = value;
		Il2CppCodeGenWriteBarrier((&___positionObjects_9), value);
	}

	inline static int32_t get_offset_of_playerShip_10() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___playerShip_10)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_playerShip_10() const { return ___playerShip_10; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_playerShip_10() { return &___playerShip_10; }
	inline void set_playerShip_10(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___playerShip_10 = value;
		Il2CppCodeGenWriteBarrier((&___playerShip_10), value);
	}

	inline static int32_t get_offset_of_direction_11() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___direction_11)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_direction_11() const { return ___direction_11; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_direction_11() { return &___direction_11; }
	inline void set_direction_11(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___direction_11 = value;
	}

	inline static int32_t get_offset_of_rotationSpeed_12() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___rotationSpeed_12)); }
	inline float get_rotationSpeed_12() const { return ___rotationSpeed_12; }
	inline float* get_address_of_rotationSpeed_12() { return &___rotationSpeed_12; }
	inline void set_rotationSpeed_12(float value)
	{
		___rotationSpeed_12 = value;
	}

	inline static int32_t get_offset_of_topRight_13() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___topRight_13)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_topRight_13() const { return ___topRight_13; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_topRight_13() { return &___topRight_13; }
	inline void set_topRight_13(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___topRight_13 = value;
	}

	inline static int32_t get_offset_of_bottomLeft_14() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___bottomLeft_14)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_bottomLeft_14() const { return ___bottomLeft_14; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_bottomLeft_14() { return &___bottomLeft_14; }
	inline void set_bottomLeft_14(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___bottomLeft_14 = value;
	}

	inline static int32_t get_offset_of_spawnManager_15() { return static_cast<int32_t>(offsetof(MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30, ___spawnManager_15)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_spawnManager_15() const { return ___spawnManager_15; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_spawnManager_15() { return &___spawnManager_15; }
	inline void set_spawnManager_15(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___spawnManager_15 = value;
		Il2CppCodeGenWriteBarrier((&___spawnManager_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOTHERSHIP_T89DEA61980C543BB64202F85B98CBAF7B2711D30_H
#ifndef OBJECTGRAVITY_T3769B3F8C7DA666CDC6589A1FE52B64AA520128A_H
#define OBJECTGRAVITY_T3769B3F8C7DA666CDC6589A1FE52B64AA520128A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ObjectGravity
struct  ObjectGravity_t3769B3F8C7DA666CDC6589A1FE52B64AA520128A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single ObjectGravity::speed
	float ___speed_4;
	// UnityEngine.Vector2 ObjectGravity::objectPosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___objectPosition_5;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(ObjectGravity_t3769B3F8C7DA666CDC6589A1FE52B64AA520128A, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_objectPosition_5() { return static_cast<int32_t>(offsetof(ObjectGravity_t3769B3F8C7DA666CDC6589A1FE52B64AA520128A, ___objectPosition_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_objectPosition_5() const { return ___objectPosition_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_objectPosition_5() { return &___objectPosition_5; }
	inline void set_objectPosition_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___objectPosition_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJECTGRAVITY_T3769B3F8C7DA666CDC6589A1FE52B64AA520128A_H
#ifndef OUTOFBOUNDS_T39D816E798B19EEB5F689B04AED1854299C0273E_H
#define OUTOFBOUNDS_T39D816E798B19EEB5F689B04AED1854299C0273E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// OutOfBounds
struct  OutOfBounds_t39D816E798B19EEB5F689B04AED1854299C0273E  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Vector2 OutOfBounds::bottomLeft
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___bottomLeft_4;

public:
	inline static int32_t get_offset_of_bottomLeft_4() { return static_cast<int32_t>(offsetof(OutOfBounds_t39D816E798B19EEB5F689B04AED1854299C0273E, ___bottomLeft_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_bottomLeft_4() const { return ___bottomLeft_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_bottomLeft_4() { return &___bottomLeft_4; }
	inline void set_bottomLeft_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___bottomLeft_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OUTOFBOUNDS_T39D816E798B19EEB5F689B04AED1854299C0273E_H
#ifndef PLAYERSCORE_TBD5A594D2AE925522560066A2E6A55F6127C14FF_H
#define PLAYERSCORE_TBD5A594D2AE925522560066A2E6A55F6127C14FF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayerScore
struct  PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String PlayerScore::<PlayerName>k__BackingField
	String_t* ___U3CPlayerNameU3Ek__BackingField_4;
	// System.Int32 PlayerScore::<Score>k__BackingField
	int32_t ___U3CScoreU3Ek__BackingField_5;
	// UnityEngine.UI.Text PlayerScore::scoreText
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___scoreText_6;
	// UnityEngine.UI.InputField PlayerScore::nameInput
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___nameInput_7;
	// UnityEngine.UI.Button PlayerScore::submitButton
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___submitButton_8;

public:
	inline static int32_t get_offset_of_U3CPlayerNameU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF, ___U3CPlayerNameU3Ek__BackingField_4)); }
	inline String_t* get_U3CPlayerNameU3Ek__BackingField_4() const { return ___U3CPlayerNameU3Ek__BackingField_4; }
	inline String_t** get_address_of_U3CPlayerNameU3Ek__BackingField_4() { return &___U3CPlayerNameU3Ek__BackingField_4; }
	inline void set_U3CPlayerNameU3Ek__BackingField_4(String_t* value)
	{
		___U3CPlayerNameU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CPlayerNameU3Ek__BackingField_4), value);
	}

	inline static int32_t get_offset_of_U3CScoreU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF, ___U3CScoreU3Ek__BackingField_5)); }
	inline int32_t get_U3CScoreU3Ek__BackingField_5() const { return ___U3CScoreU3Ek__BackingField_5; }
	inline int32_t* get_address_of_U3CScoreU3Ek__BackingField_5() { return &___U3CScoreU3Ek__BackingField_5; }
	inline void set_U3CScoreU3Ek__BackingField_5(int32_t value)
	{
		___U3CScoreU3Ek__BackingField_5 = value;
	}

	inline static int32_t get_offset_of_scoreText_6() { return static_cast<int32_t>(offsetof(PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF, ___scoreText_6)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_scoreText_6() const { return ___scoreText_6; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_scoreText_6() { return &___scoreText_6; }
	inline void set_scoreText_6(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___scoreText_6 = value;
		Il2CppCodeGenWriteBarrier((&___scoreText_6), value);
	}

	inline static int32_t get_offset_of_nameInput_7() { return static_cast<int32_t>(offsetof(PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF, ___nameInput_7)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_nameInput_7() const { return ___nameInput_7; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_nameInput_7() { return &___nameInput_7; }
	inline void set_nameInput_7(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___nameInput_7 = value;
		Il2CppCodeGenWriteBarrier((&___nameInput_7), value);
	}

	inline static int32_t get_offset_of_submitButton_8() { return static_cast<int32_t>(offsetof(PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF, ___submitButton_8)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_submitButton_8() const { return ___submitButton_8; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_submitButton_8() { return &___submitButton_8; }
	inline void set_submitButton_8(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___submitButton_8 = value;
		Il2CppCodeGenWriteBarrier((&___submitButton_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYERSCORE_TBD5A594D2AE925522560066A2E6A55F6127C14FF_H
#ifndef PLAYERSHIP_TFD87E5F7047F0DA055206EEFFD15B1B5A000D158_H
#define PLAYERSHIP_TFD87E5F7047F0DA055206EEFFD15B1B5A000D158_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayerShip
struct  PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject PlayerShip::playerShipMissileMovement
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___playerShipMissileMovement_4;
	// UnityEngine.GameObject PlayerShip::playerMissilePosition1
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___playerMissilePosition1_5;
	// UnityEngine.GameObject PlayerShip::playerMissilePosition2
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___playerMissilePosition2_6;
	// UnityEngine.GameObject PlayerShip::playerExplosionAnimationObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___playerExplosionAnimationObject_7;
	// Boundary PlayerShip::boundary
	Boundary_t524EE905C1329FEB0BA75BFEB4B1A6E15B155779 * ___boundary_8;
	// System.Int32 PlayerShip::maxNumMissiles
	int32_t ___maxNumMissiles_9;
	// System.Int32 PlayerShip::currentNumMissiles
	int32_t ___currentNumMissiles_10;
	// System.Single PlayerShip::reloadTime
	float ___reloadTime_11;
	// System.Boolean PlayerShip::isReloading
	bool ___isReloading_12;

public:
	inline static int32_t get_offset_of_playerShipMissileMovement_4() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___playerShipMissileMovement_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_playerShipMissileMovement_4() const { return ___playerShipMissileMovement_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_playerShipMissileMovement_4() { return &___playerShipMissileMovement_4; }
	inline void set_playerShipMissileMovement_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___playerShipMissileMovement_4 = value;
		Il2CppCodeGenWriteBarrier((&___playerShipMissileMovement_4), value);
	}

	inline static int32_t get_offset_of_playerMissilePosition1_5() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___playerMissilePosition1_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_playerMissilePosition1_5() const { return ___playerMissilePosition1_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_playerMissilePosition1_5() { return &___playerMissilePosition1_5; }
	inline void set_playerMissilePosition1_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___playerMissilePosition1_5 = value;
		Il2CppCodeGenWriteBarrier((&___playerMissilePosition1_5), value);
	}

	inline static int32_t get_offset_of_playerMissilePosition2_6() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___playerMissilePosition2_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_playerMissilePosition2_6() const { return ___playerMissilePosition2_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_playerMissilePosition2_6() { return &___playerMissilePosition2_6; }
	inline void set_playerMissilePosition2_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___playerMissilePosition2_6 = value;
		Il2CppCodeGenWriteBarrier((&___playerMissilePosition2_6), value);
	}

	inline static int32_t get_offset_of_playerExplosionAnimationObject_7() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___playerExplosionAnimationObject_7)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_playerExplosionAnimationObject_7() const { return ___playerExplosionAnimationObject_7; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_playerExplosionAnimationObject_7() { return &___playerExplosionAnimationObject_7; }
	inline void set_playerExplosionAnimationObject_7(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___playerExplosionAnimationObject_7 = value;
		Il2CppCodeGenWriteBarrier((&___playerExplosionAnimationObject_7), value);
	}

	inline static int32_t get_offset_of_boundary_8() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___boundary_8)); }
	inline Boundary_t524EE905C1329FEB0BA75BFEB4B1A6E15B155779 * get_boundary_8() const { return ___boundary_8; }
	inline Boundary_t524EE905C1329FEB0BA75BFEB4B1A6E15B155779 ** get_address_of_boundary_8() { return &___boundary_8; }
	inline void set_boundary_8(Boundary_t524EE905C1329FEB0BA75BFEB4B1A6E15B155779 * value)
	{
		___boundary_8 = value;
		Il2CppCodeGenWriteBarrier((&___boundary_8), value);
	}

	inline static int32_t get_offset_of_maxNumMissiles_9() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___maxNumMissiles_9)); }
	inline int32_t get_maxNumMissiles_9() const { return ___maxNumMissiles_9; }
	inline int32_t* get_address_of_maxNumMissiles_9() { return &___maxNumMissiles_9; }
	inline void set_maxNumMissiles_9(int32_t value)
	{
		___maxNumMissiles_9 = value;
	}

	inline static int32_t get_offset_of_currentNumMissiles_10() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___currentNumMissiles_10)); }
	inline int32_t get_currentNumMissiles_10() const { return ___currentNumMissiles_10; }
	inline int32_t* get_address_of_currentNumMissiles_10() { return &___currentNumMissiles_10; }
	inline void set_currentNumMissiles_10(int32_t value)
	{
		___currentNumMissiles_10 = value;
	}

	inline static int32_t get_offset_of_reloadTime_11() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___reloadTime_11)); }
	inline float get_reloadTime_11() const { return ___reloadTime_11; }
	inline float* get_address_of_reloadTime_11() { return &___reloadTime_11; }
	inline void set_reloadTime_11(float value)
	{
		___reloadTime_11 = value;
	}

	inline static int32_t get_offset_of_isReloading_12() { return static_cast<int32_t>(offsetof(PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158, ___isReloading_12)); }
	inline bool get_isReloading_12() const { return ___isReloading_12; }
	inline bool* get_address_of_isReloading_12() { return &___isReloading_12; }
	inline void set_isReloading_12(bool value)
	{
		___isReloading_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYERSHIP_TFD87E5F7047F0DA055206EEFFD15B1B5A000D158_H
#ifndef PLAYERSHIPMISSILE_TD44491B0A48E697AD01C297474E22B1EE6F18649_H
#define PLAYERSHIPMISSILE_TD44491B0A48E697AD01C297474E22B1EE6F18649_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayerShipMissile
struct  PlayerShipMissile_tD44491B0A48E697AD01C297474E22B1EE6F18649  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single PlayerShipMissile::missileSpeed
	float ___missileSpeed_4;
	// UnityEngine.Vector2 PlayerShipMissile::missilePosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___missilePosition_5;

public:
	inline static int32_t get_offset_of_missileSpeed_4() { return static_cast<int32_t>(offsetof(PlayerShipMissile_tD44491B0A48E697AD01C297474E22B1EE6F18649, ___missileSpeed_4)); }
	inline float get_missileSpeed_4() const { return ___missileSpeed_4; }
	inline float* get_address_of_missileSpeed_4() { return &___missileSpeed_4; }
	inline void set_missileSpeed_4(float value)
	{
		___missileSpeed_4 = value;
	}

	inline static int32_t get_offset_of_missilePosition_5() { return static_cast<int32_t>(offsetof(PlayerShipMissile_tD44491B0A48E697AD01C297474E22B1EE6F18649, ___missilePosition_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_missilePosition_5() const { return ___missilePosition_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_missilePosition_5() { return &___missilePosition_5; }
	inline void set_missilePosition_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___missilePosition_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYERSHIPMISSILE_TD44491B0A48E697AD01C297474E22B1EE6F18649_H
#ifndef PLAYERSHIPCONTROLLER_TDAF10AEA10FD5B02D76ACDBA26237882E204AC6A_H
#define PLAYERSHIPCONTROLLER_TDAF10AEA10FD5B02D76ACDBA26237882E204AC6A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayershipController
struct  PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single PlayershipController::playerSpeed
	float ___playerSpeed_4;
	// UnityEngine.Vector2 PlayershipController::playerPosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___playerPosition_5;
	// HumbleMovement PlayershipController::humbleMovement
	HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C * ___humbleMovement_6;
	// IUnityService PlayershipController::unityService
	RuntimeObject* ___unityService_7;

public:
	inline static int32_t get_offset_of_playerSpeed_4() { return static_cast<int32_t>(offsetof(PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A, ___playerSpeed_4)); }
	inline float get_playerSpeed_4() const { return ___playerSpeed_4; }
	inline float* get_address_of_playerSpeed_4() { return &___playerSpeed_4; }
	inline void set_playerSpeed_4(float value)
	{
		___playerSpeed_4 = value;
	}

	inline static int32_t get_offset_of_playerPosition_5() { return static_cast<int32_t>(offsetof(PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A, ___playerPosition_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_playerPosition_5() const { return ___playerPosition_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_playerPosition_5() { return &___playerPosition_5; }
	inline void set_playerPosition_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___playerPosition_5 = value;
	}

	inline static int32_t get_offset_of_humbleMovement_6() { return static_cast<int32_t>(offsetof(PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A, ___humbleMovement_6)); }
	inline HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C * get_humbleMovement_6() const { return ___humbleMovement_6; }
	inline HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C ** get_address_of_humbleMovement_6() { return &___humbleMovement_6; }
	inline void set_humbleMovement_6(HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C * value)
	{
		___humbleMovement_6 = value;
		Il2CppCodeGenWriteBarrier((&___humbleMovement_6), value);
	}

	inline static int32_t get_offset_of_unityService_7() { return static_cast<int32_t>(offsetof(PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A, ___unityService_7)); }
	inline RuntimeObject* get_unityService_7() const { return ___unityService_7; }
	inline RuntimeObject** get_address_of_unityService_7() { return &___unityService_7; }
	inline void set_unityService_7(RuntimeObject* value)
	{
		___unityService_7 = value;
		Il2CppCodeGenWriteBarrier((&___unityService_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYERSHIPCONTROLLER_TDAF10AEA10FD5B02D76ACDBA26237882E204AC6A_H
#ifndef INGAMEAPICLIENTLOADER_T4833912E6352D3821206C67C532AD18A7804C32C_H
#define INGAMEAPICLIENTLOADER_T4833912E6352D3821206C67C532AD18A7804C32C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.InGameApiClientLoader
struct  InGameApiClientLoader_t4833912E6352D3821206C67C532AD18A7804C32C  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INGAMEAPICLIENTLOADER_T4833912E6352D3821206C67C532AD18A7804C32C_H
#ifndef MAINTHREADQUEUE_T4526AB6279A6E9A202B2082EE3251F2EF93BF919_H
#define MAINTHREADQUEUE_T4526AB6279A6E9A202B2082EE3251F2EF93BF919_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Puppetry.Puppet.MainThreadQueue
struct  MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Collections.Generic.List`1<System.Action> Puppetry.Puppet.MainThreadQueue::requestedActions
	List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE * ___requestedActions_4;
	// System.Collections.Generic.List`1<System.Action> Puppetry.Puppet.MainThreadQueue::currentActions
	List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE * ___currentActions_5;

public:
	inline static int32_t get_offset_of_requestedActions_4() { return static_cast<int32_t>(offsetof(MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919, ___requestedActions_4)); }
	inline List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE * get_requestedActions_4() const { return ___requestedActions_4; }
	inline List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE ** get_address_of_requestedActions_4() { return &___requestedActions_4; }
	inline void set_requestedActions_4(List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE * value)
	{
		___requestedActions_4 = value;
		Il2CppCodeGenWriteBarrier((&___requestedActions_4), value);
	}

	inline static int32_t get_offset_of_currentActions_5() { return static_cast<int32_t>(offsetof(MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919, ___currentActions_5)); }
	inline List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE * get_currentActions_5() const { return ___currentActions_5; }
	inline List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE ** get_address_of_currentActions_5() { return &___currentActions_5; }
	inline void set_currentActions_5(List_1_tF4B622C1ABA386932660D23A459A2974FB56E2EE * value)
	{
		___currentActions_5 = value;
		Il2CppCodeGenWriteBarrier((&___currentActions_5), value);
	}
};

struct MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919_StaticFields
{
public:
	// Puppetry.Puppet.MainThreadQueue Puppetry.Puppet.MainThreadQueue::_instance
	MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919 * ____instance_6;

public:
	inline static int32_t get_offset_of__instance_6() { return static_cast<int32_t>(offsetof(MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919_StaticFields, ____instance_6)); }
	inline MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919 * get__instance_6() const { return ____instance_6; }
	inline MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919 ** get_address_of__instance_6() { return &____instance_6; }
	inline void set__instance_6(MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919 * value)
	{
		____instance_6 = value;
		Il2CppCodeGenWriteBarrier((&____instance_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MAINTHREADQUEUE_T4526AB6279A6E9A202B2082EE3251F2EF93BF919_H
#ifndef RANKINGMANAGER_TEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5_H
#define RANKINGMANAGER_TEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// RankingManager
struct  RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Ranking[] RankingManager::rankingList
	RankingU5BU5D_tF69C11F82420CCB8330D1331FF0B5B914556949D* ___rankingList_7;
	// DisplayRankings RankingManager::display
	DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 * ___display_8;
	// System.Int32 RankingManager::averageScore
	int32_t ___averageScore_10;

public:
	inline static int32_t get_offset_of_rankingList_7() { return static_cast<int32_t>(offsetof(RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5, ___rankingList_7)); }
	inline RankingU5BU5D_tF69C11F82420CCB8330D1331FF0B5B914556949D* get_rankingList_7() const { return ___rankingList_7; }
	inline RankingU5BU5D_tF69C11F82420CCB8330D1331FF0B5B914556949D** get_address_of_rankingList_7() { return &___rankingList_7; }
	inline void set_rankingList_7(RankingU5BU5D_tF69C11F82420CCB8330D1331FF0B5B914556949D* value)
	{
		___rankingList_7 = value;
		Il2CppCodeGenWriteBarrier((&___rankingList_7), value);
	}

	inline static int32_t get_offset_of_display_8() { return static_cast<int32_t>(offsetof(RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5, ___display_8)); }
	inline DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 * get_display_8() const { return ___display_8; }
	inline DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 ** get_address_of_display_8() { return &___display_8; }
	inline void set_display_8(DisplayRankings_tD2CB706A983897C99C0A09281B84F302516E8265 * value)
	{
		___display_8 = value;
		Il2CppCodeGenWriteBarrier((&___display_8), value);
	}

	inline static int32_t get_offset_of_averageScore_10() { return static_cast<int32_t>(offsetof(RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5, ___averageScore_10)); }
	inline int32_t get_averageScore_10() const { return ___averageScore_10; }
	inline int32_t* get_address_of_averageScore_10() { return &___averageScore_10; }
	inline void set_averageScore_10(int32_t value)
	{
		___averageScore_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RANKINGMANAGER_TEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5_H
#ifndef RING_T82C8E3DF8F89694921DD83C565B90931BB2AE3AF_H
#define RING_T82C8E3DF8F89694921DD83C565B90931BB2AE3AF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Ring
struct  Ring_t82C8E3DF8F89694921DD83C565B90931BB2AE3AF  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Vector2 Ring::velocity
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___velocity_4;
	// System.Single Ring::degree
	float ___degree_5;

public:
	inline static int32_t get_offset_of_velocity_4() { return static_cast<int32_t>(offsetof(Ring_t82C8E3DF8F89694921DD83C565B90931BB2AE3AF, ___velocity_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_velocity_4() const { return ___velocity_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_velocity_4() { return &___velocity_4; }
	inline void set_velocity_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___velocity_4 = value;
	}

	inline static int32_t get_offset_of_degree_5() { return static_cast<int32_t>(offsetof(Ring_t82C8E3DF8F89694921DD83C565B90931BB2AE3AF, ___degree_5)); }
	inline float get_degree_5() const { return ___degree_5; }
	inline float* get_address_of_degree_5() { return &___degree_5; }
	inline void set_degree_5(float value)
	{
		___degree_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RING_T82C8E3DF8F89694921DD83C565B90931BB2AE3AF_H
#ifndef SLICER_TB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45_H
#define SLICER_TB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Slicer
struct  Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single Slicer::patrolSpeed
	float ___patrolSpeed_4;
	// UnityEngine.Transform Slicer::gizmo
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___gizmo_5;
	// System.Boolean Slicer::barrierDetected
	bool ___barrierDetected_6;
	// UnityEngine.RaycastHit2D Slicer::info
	RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE  ___info_7;

public:
	inline static int32_t get_offset_of_patrolSpeed_4() { return static_cast<int32_t>(offsetof(Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45, ___patrolSpeed_4)); }
	inline float get_patrolSpeed_4() const { return ___patrolSpeed_4; }
	inline float* get_address_of_patrolSpeed_4() { return &___patrolSpeed_4; }
	inline void set_patrolSpeed_4(float value)
	{
		___patrolSpeed_4 = value;
	}

	inline static int32_t get_offset_of_gizmo_5() { return static_cast<int32_t>(offsetof(Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45, ___gizmo_5)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_gizmo_5() const { return ___gizmo_5; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_gizmo_5() { return &___gizmo_5; }
	inline void set_gizmo_5(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___gizmo_5 = value;
		Il2CppCodeGenWriteBarrier((&___gizmo_5), value);
	}

	inline static int32_t get_offset_of_barrierDetected_6() { return static_cast<int32_t>(offsetof(Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45, ___barrierDetected_6)); }
	inline bool get_barrierDetected_6() const { return ___barrierDetected_6; }
	inline bool* get_address_of_barrierDetected_6() { return &___barrierDetected_6; }
	inline void set_barrierDetected_6(bool value)
	{
		___barrierDetected_6 = value;
	}

	inline static int32_t get_offset_of_info_7() { return static_cast<int32_t>(offsetof(Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45, ___info_7)); }
	inline RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE  get_info_7() const { return ___info_7; }
	inline RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE * get_address_of_info_7() { return &___info_7; }
	inline void set_info_7(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE  value)
	{
		___info_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SLICER_TB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45_H
#ifndef SOUNDMANAGER_TB4134B24E1B190207B84440493F3CF6060F4D4FD_H
#define SOUNDMANAGER_TB4134B24E1B190207B84440493F3CF6060F4D4FD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SoundManager
struct  SoundManager_tB4134B24E1B190207B84440493F3CF6060F4D4FD  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Collections.Generic.List`1<Sound> SoundManager::sounds
	List_1_t4B3595BCFD01CD62DAF26342761E57EA20AAC3E7 * ___sounds_4;

public:
	inline static int32_t get_offset_of_sounds_4() { return static_cast<int32_t>(offsetof(SoundManager_tB4134B24E1B190207B84440493F3CF6060F4D4FD, ___sounds_4)); }
	inline List_1_t4B3595BCFD01CD62DAF26342761E57EA20AAC3E7 * get_sounds_4() const { return ___sounds_4; }
	inline List_1_t4B3595BCFD01CD62DAF26342761E57EA20AAC3E7 ** get_address_of_sounds_4() { return &___sounds_4; }
	inline void set_sounds_4(List_1_t4B3595BCFD01CD62DAF26342761E57EA20AAC3E7 * value)
	{
		___sounds_4 = value;
		Il2CppCodeGenWriteBarrier((&___sounds_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SOUNDMANAGER_TB4134B24E1B190207B84440493F3CF6060F4D4FD_H
#ifndef SPAWNMANAGER_T08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_H
#define SPAWNMANAGER_T08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SpawnManager
struct  SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Collections.Generic.List`1<CustomObject> SpawnManager::objectsList
	List_1_t99FDB733A99492B0B8925E98134406016B269FB7 * ___objectsList_4;
	// System.Single SpawnManager::startTime
	float ___startTime_5;
	// System.Single SpawnManager::maxSpawnRatePerSecond
	float ___maxSpawnRatePerSecond_6;
	// System.Single SpawnManager::minSpawnRatePerSecond
	float ___minSpawnRatePerSecond_7;
	// System.Single SpawnManager::timeToIncrease
	float ___timeToIncrease_8;
	// UnityEngine.GameObject SpawnManager::playership
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___playership_9;
	// UnityEngine.GameObject SpawnManager::score
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___score_10;
	// UnityEngine.Vector3 SpawnManager::positionOfCamera
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positionOfCamera_11;
	// System.Int32[] SpawnManager::originalWeights
	Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* ___originalWeights_12;
	// System.Int32 SpawnManager::average
	int32_t ___average_13;

public:
	inline static int32_t get_offset_of_objectsList_4() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___objectsList_4)); }
	inline List_1_t99FDB733A99492B0B8925E98134406016B269FB7 * get_objectsList_4() const { return ___objectsList_4; }
	inline List_1_t99FDB733A99492B0B8925E98134406016B269FB7 ** get_address_of_objectsList_4() { return &___objectsList_4; }
	inline void set_objectsList_4(List_1_t99FDB733A99492B0B8925E98134406016B269FB7 * value)
	{
		___objectsList_4 = value;
		Il2CppCodeGenWriteBarrier((&___objectsList_4), value);
	}

	inline static int32_t get_offset_of_startTime_5() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___startTime_5)); }
	inline float get_startTime_5() const { return ___startTime_5; }
	inline float* get_address_of_startTime_5() { return &___startTime_5; }
	inline void set_startTime_5(float value)
	{
		___startTime_5 = value;
	}

	inline static int32_t get_offset_of_maxSpawnRatePerSecond_6() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___maxSpawnRatePerSecond_6)); }
	inline float get_maxSpawnRatePerSecond_6() const { return ___maxSpawnRatePerSecond_6; }
	inline float* get_address_of_maxSpawnRatePerSecond_6() { return &___maxSpawnRatePerSecond_6; }
	inline void set_maxSpawnRatePerSecond_6(float value)
	{
		___maxSpawnRatePerSecond_6 = value;
	}

	inline static int32_t get_offset_of_minSpawnRatePerSecond_7() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___minSpawnRatePerSecond_7)); }
	inline float get_minSpawnRatePerSecond_7() const { return ___minSpawnRatePerSecond_7; }
	inline float* get_address_of_minSpawnRatePerSecond_7() { return &___minSpawnRatePerSecond_7; }
	inline void set_minSpawnRatePerSecond_7(float value)
	{
		___minSpawnRatePerSecond_7 = value;
	}

	inline static int32_t get_offset_of_timeToIncrease_8() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___timeToIncrease_8)); }
	inline float get_timeToIncrease_8() const { return ___timeToIncrease_8; }
	inline float* get_address_of_timeToIncrease_8() { return &___timeToIncrease_8; }
	inline void set_timeToIncrease_8(float value)
	{
		___timeToIncrease_8 = value;
	}

	inline static int32_t get_offset_of_playership_9() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___playership_9)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_playership_9() const { return ___playership_9; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_playership_9() { return &___playership_9; }
	inline void set_playership_9(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___playership_9 = value;
		Il2CppCodeGenWriteBarrier((&___playership_9), value);
	}

	inline static int32_t get_offset_of_score_10() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___score_10)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_score_10() const { return ___score_10; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_score_10() { return &___score_10; }
	inline void set_score_10(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___score_10 = value;
		Il2CppCodeGenWriteBarrier((&___score_10), value);
	}

	inline static int32_t get_offset_of_positionOfCamera_11() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___positionOfCamera_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positionOfCamera_11() const { return ___positionOfCamera_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positionOfCamera_11() { return &___positionOfCamera_11; }
	inline void set_positionOfCamera_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positionOfCamera_11 = value;
	}

	inline static int32_t get_offset_of_originalWeights_12() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___originalWeights_12)); }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* get_originalWeights_12() const { return ___originalWeights_12; }
	inline Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074** get_address_of_originalWeights_12() { return &___originalWeights_12; }
	inline void set_originalWeights_12(Int32U5BU5D_t20AF77B812DFA3168922AE8F35FB9FD20D7EA074* value)
	{
		___originalWeights_12 = value;
		Il2CppCodeGenWriteBarrier((&___originalWeights_12), value);
	}

	inline static int32_t get_offset_of_average_13() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E, ___average_13)); }
	inline int32_t get_average_13() const { return ___average_13; }
	inline int32_t* get_address_of_average_13() { return &___average_13; }
	inline void set_average_13(int32_t value)
	{
		___average_13 = value;
	}
};

struct SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_StaticFields
{
public:
	// System.Func`2<CustomObject,System.Int32> SpawnManager::<>f__amU24cache0
	Func_2_t762C596D906C081DEAB6A6125C7EC9900AEBD588 * ___U3CU3Ef__amU24cache0_14;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_14() { return static_cast<int32_t>(offsetof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_StaticFields, ___U3CU3Ef__amU24cache0_14)); }
	inline Func_2_t762C596D906C081DEAB6A6125C7EC9900AEBD588 * get_U3CU3Ef__amU24cache0_14() const { return ___U3CU3Ef__amU24cache0_14; }
	inline Func_2_t762C596D906C081DEAB6A6125C7EC9900AEBD588 ** get_address_of_U3CU3Ef__amU24cache0_14() { return &___U3CU3Ef__amU24cache0_14; }
	inline void set_U3CU3Ef__amU24cache0_14(Func_2_t762C596D906C081DEAB6A6125C7EC9900AEBD588 * value)
	{
		___U3CU3Ef__amU24cache0_14 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_14), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SPAWNMANAGER_T08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_H
#ifndef SPAWNPOINTS_TFF4C4240FFAAD87D45F68AE7EB477BCD018436CC_H
#define SPAWNPOINTS_TFF4C4240FFAAD87D45F68AE7EB477BCD018436CC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// SpawnPoints
struct  SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single SpawnPoints::x1
	float ___x1_4;
	// System.Single SpawnPoints::y1
	float ___y1_5;
	// System.Single SpawnPoints::x2
	float ___x2_6;
	// System.Single SpawnPoints::y2
	float ___y2_7;

public:
	inline static int32_t get_offset_of_x1_4() { return static_cast<int32_t>(offsetof(SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC, ___x1_4)); }
	inline float get_x1_4() const { return ___x1_4; }
	inline float* get_address_of_x1_4() { return &___x1_4; }
	inline void set_x1_4(float value)
	{
		___x1_4 = value;
	}

	inline static int32_t get_offset_of_y1_5() { return static_cast<int32_t>(offsetof(SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC, ___y1_5)); }
	inline float get_y1_5() const { return ___y1_5; }
	inline float* get_address_of_y1_5() { return &___y1_5; }
	inline void set_y1_5(float value)
	{
		___y1_5 = value;
	}

	inline static int32_t get_offset_of_x2_6() { return static_cast<int32_t>(offsetof(SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC, ___x2_6)); }
	inline float get_x2_6() const { return ___x2_6; }
	inline float* get_address_of_x2_6() { return &___x2_6; }
	inline void set_x2_6(float value)
	{
		___x2_6 = value;
	}

	inline static int32_t get_offset_of_y2_7() { return static_cast<int32_t>(offsetof(SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC, ___y2_7)); }
	inline float get_y2_7() const { return ___y2_7; }
	inline float* get_address_of_y2_7() { return &___y2_7; }
	inline void set_y2_7(float value)
	{
		___y2_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SPAWNPOINTS_TFF4C4240FFAAD87D45F68AE7EB477BCD018436CC_H
#ifndef STARCREATOR_TE57FC53AD6167BD4B9CBA53ECF27154169702060_H
#define STARCREATOR_TE57FC53AD6167BD4B9CBA53ECF27154169702060_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// StarCreator
struct  StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject StarCreator::starMove
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___starMove_4;
	// System.Int32 StarCreator::maxNumStars
	int32_t ___maxNumStars_5;
	// UnityEngine.Vector2 StarCreator::bottomLeft
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___bottomLeft_6;
	// UnityEngine.Vector2 StarCreator::topRight
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___topRight_7;

public:
	inline static int32_t get_offset_of_starMove_4() { return static_cast<int32_t>(offsetof(StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060, ___starMove_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_starMove_4() const { return ___starMove_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_starMove_4() { return &___starMove_4; }
	inline void set_starMove_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___starMove_4 = value;
		Il2CppCodeGenWriteBarrier((&___starMove_4), value);
	}

	inline static int32_t get_offset_of_maxNumStars_5() { return static_cast<int32_t>(offsetof(StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060, ___maxNumStars_5)); }
	inline int32_t get_maxNumStars_5() const { return ___maxNumStars_5; }
	inline int32_t* get_address_of_maxNumStars_5() { return &___maxNumStars_5; }
	inline void set_maxNumStars_5(int32_t value)
	{
		___maxNumStars_5 = value;
	}

	inline static int32_t get_offset_of_bottomLeft_6() { return static_cast<int32_t>(offsetof(StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060, ___bottomLeft_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_bottomLeft_6() const { return ___bottomLeft_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_bottomLeft_6() { return &___bottomLeft_6; }
	inline void set_bottomLeft_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___bottomLeft_6 = value;
	}

	inline static int32_t get_offset_of_topRight_7() { return static_cast<int32_t>(offsetof(StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060, ___topRight_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_topRight_7() const { return ___topRight_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_topRight_7() { return &___topRight_7; }
	inline void set_topRight_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___topRight_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STARCREATOR_TE57FC53AD6167BD4B9CBA53ECF27154169702060_H
#ifndef STARS_T17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651_H
#define STARS_T17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Stars
struct  Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single Stars::<StarSpeed>k__BackingField
	float ___U3CStarSpeedU3Ek__BackingField_4;
	// UnityEngine.Vector2 Stars::starPosition
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___starPosition_5;
	// UnityEngine.Vector2 Stars::bottomLeft
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___bottomLeft_6;
	// UnityEngine.Vector2 Stars::topRight
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___topRight_7;

public:
	inline static int32_t get_offset_of_U3CStarSpeedU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651, ___U3CStarSpeedU3Ek__BackingField_4)); }
	inline float get_U3CStarSpeedU3Ek__BackingField_4() const { return ___U3CStarSpeedU3Ek__BackingField_4; }
	inline float* get_address_of_U3CStarSpeedU3Ek__BackingField_4() { return &___U3CStarSpeedU3Ek__BackingField_4; }
	inline void set_U3CStarSpeedU3Ek__BackingField_4(float value)
	{
		___U3CStarSpeedU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_starPosition_5() { return static_cast<int32_t>(offsetof(Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651, ___starPosition_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_starPosition_5() const { return ___starPosition_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_starPosition_5() { return &___starPosition_5; }
	inline void set_starPosition_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___starPosition_5 = value;
	}

	inline static int32_t get_offset_of_bottomLeft_6() { return static_cast<int32_t>(offsetof(Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651, ___bottomLeft_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_bottomLeft_6() const { return ___bottomLeft_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_bottomLeft_6() { return &___bottomLeft_6; }
	inline void set_bottomLeft_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___bottomLeft_6 = value;
	}

	inline static int32_t get_offset_of_topRight_7() { return static_cast<int32_t>(offsetof(Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651, ___topRight_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_topRight_7() const { return ___topRight_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_topRight_7() { return &___topRight_7; }
	inline void set_topRight_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___topRight_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STARS_T17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651_H
#ifndef BENCHMARK01_T375270EB369DC01A4C37A6381970857C4BD87761_H
#define BENCHMARK01_T375270EB369DC01A4C37A6381970857C4BD87761_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark01
struct  Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TMPro.Examples.Benchmark01::BenchmarkType
	int32_t ___BenchmarkType_4;
	// TMPro.TMP_FontAsset TMPro.Examples.Benchmark01::TMProFont
	TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C * ___TMProFont_5;
	// UnityEngine.Font TMPro.Examples.Benchmark01::TextMeshFont
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___TextMeshFont_6;
	// TMPro.TextMeshPro TMPro.Examples.Benchmark01::m_textMeshPro
	TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * ___m_textMeshPro_7;
	// TMPro.TextContainer TMPro.Examples.Benchmark01::m_textContainer
	TextContainer_tF5E5EB56D152102B19C27607F84847CA594391DE * ___m_textContainer_8;
	// UnityEngine.TextMesh TMPro.Examples.Benchmark01::m_textMesh
	TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * ___m_textMesh_9;
	// UnityEngine.Material TMPro.Examples.Benchmark01::m_material01
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___m_material01_12;
	// UnityEngine.Material TMPro.Examples.Benchmark01::m_material02
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___m_material02_13;

public:
	inline static int32_t get_offset_of_BenchmarkType_4() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___BenchmarkType_4)); }
	inline int32_t get_BenchmarkType_4() const { return ___BenchmarkType_4; }
	inline int32_t* get_address_of_BenchmarkType_4() { return &___BenchmarkType_4; }
	inline void set_BenchmarkType_4(int32_t value)
	{
		___BenchmarkType_4 = value;
	}

	inline static int32_t get_offset_of_TMProFont_5() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___TMProFont_5)); }
	inline TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C * get_TMProFont_5() const { return ___TMProFont_5; }
	inline TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C ** get_address_of_TMProFont_5() { return &___TMProFont_5; }
	inline void set_TMProFont_5(TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C * value)
	{
		___TMProFont_5 = value;
		Il2CppCodeGenWriteBarrier((&___TMProFont_5), value);
	}

	inline static int32_t get_offset_of_TextMeshFont_6() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___TextMeshFont_6)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_TextMeshFont_6() const { return ___TextMeshFont_6; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_TextMeshFont_6() { return &___TextMeshFont_6; }
	inline void set_TextMeshFont_6(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___TextMeshFont_6 = value;
		Il2CppCodeGenWriteBarrier((&___TextMeshFont_6), value);
	}

	inline static int32_t get_offset_of_m_textMeshPro_7() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___m_textMeshPro_7)); }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * get_m_textMeshPro_7() const { return ___m_textMeshPro_7; }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 ** get_address_of_m_textMeshPro_7() { return &___m_textMeshPro_7; }
	inline void set_m_textMeshPro_7(TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * value)
	{
		___m_textMeshPro_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMeshPro_7), value);
	}

	inline static int32_t get_offset_of_m_textContainer_8() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___m_textContainer_8)); }
	inline TextContainer_tF5E5EB56D152102B19C27607F84847CA594391DE * get_m_textContainer_8() const { return ___m_textContainer_8; }
	inline TextContainer_tF5E5EB56D152102B19C27607F84847CA594391DE ** get_address_of_m_textContainer_8() { return &___m_textContainer_8; }
	inline void set_m_textContainer_8(TextContainer_tF5E5EB56D152102B19C27607F84847CA594391DE * value)
	{
		___m_textContainer_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_textContainer_8), value);
	}

	inline static int32_t get_offset_of_m_textMesh_9() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___m_textMesh_9)); }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * get_m_textMesh_9() const { return ___m_textMesh_9; }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A ** get_address_of_m_textMesh_9() { return &___m_textMesh_9; }
	inline void set_m_textMesh_9(TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * value)
	{
		___m_textMesh_9 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMesh_9), value);
	}

	inline static int32_t get_offset_of_m_material01_12() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___m_material01_12)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_m_material01_12() const { return ___m_material01_12; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_m_material01_12() { return &___m_material01_12; }
	inline void set_m_material01_12(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___m_material01_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_material01_12), value);
	}

	inline static int32_t get_offset_of_m_material02_13() { return static_cast<int32_t>(offsetof(Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761, ___m_material02_13)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_m_material02_13() const { return ___m_material02_13; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_m_material02_13() { return &___m_material02_13; }
	inline void set_m_material02_13(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___m_material02_13 = value;
		Il2CppCodeGenWriteBarrier((&___m_material02_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BENCHMARK01_T375270EB369DC01A4C37A6381970857C4BD87761_H
#ifndef BENCHMARK01_UGUI_TDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55_H
#define BENCHMARK01_UGUI_TDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark01_UGUI
struct  Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TMPro.Examples.Benchmark01_UGUI::BenchmarkType
	int32_t ___BenchmarkType_4;
	// UnityEngine.Canvas TMPro.Examples.Benchmark01_UGUI::canvas
	Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * ___canvas_5;
	// TMPro.TMP_FontAsset TMPro.Examples.Benchmark01_UGUI::TMProFont
	TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C * ___TMProFont_6;
	// UnityEngine.Font TMPro.Examples.Benchmark01_UGUI::TextMeshFont
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___TextMeshFont_7;
	// TMPro.TextMeshProUGUI TMPro.Examples.Benchmark01_UGUI::m_textMeshPro
	TextMeshProUGUI_tBA60B913AB6151F8563F7078AD67EB6458129438 * ___m_textMeshPro_8;
	// UnityEngine.UI.Text TMPro.Examples.Benchmark01_UGUI::m_textMesh
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___m_textMesh_9;
	// UnityEngine.Material TMPro.Examples.Benchmark01_UGUI::m_material01
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___m_material01_12;
	// UnityEngine.Material TMPro.Examples.Benchmark01_UGUI::m_material02
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___m_material02_13;

public:
	inline static int32_t get_offset_of_BenchmarkType_4() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___BenchmarkType_4)); }
	inline int32_t get_BenchmarkType_4() const { return ___BenchmarkType_4; }
	inline int32_t* get_address_of_BenchmarkType_4() { return &___BenchmarkType_4; }
	inline void set_BenchmarkType_4(int32_t value)
	{
		___BenchmarkType_4 = value;
	}

	inline static int32_t get_offset_of_canvas_5() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___canvas_5)); }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * get_canvas_5() const { return ___canvas_5; }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 ** get_address_of_canvas_5() { return &___canvas_5; }
	inline void set_canvas_5(Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * value)
	{
		___canvas_5 = value;
		Il2CppCodeGenWriteBarrier((&___canvas_5), value);
	}

	inline static int32_t get_offset_of_TMProFont_6() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___TMProFont_6)); }
	inline TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C * get_TMProFont_6() const { return ___TMProFont_6; }
	inline TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C ** get_address_of_TMProFont_6() { return &___TMProFont_6; }
	inline void set_TMProFont_6(TMP_FontAsset_t44D2006105B39FB33AE5A0ADF07A7EF36C72385C * value)
	{
		___TMProFont_6 = value;
		Il2CppCodeGenWriteBarrier((&___TMProFont_6), value);
	}

	inline static int32_t get_offset_of_TextMeshFont_7() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___TextMeshFont_7)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_TextMeshFont_7() const { return ___TextMeshFont_7; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_TextMeshFont_7() { return &___TextMeshFont_7; }
	inline void set_TextMeshFont_7(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___TextMeshFont_7 = value;
		Il2CppCodeGenWriteBarrier((&___TextMeshFont_7), value);
	}

	inline static int32_t get_offset_of_m_textMeshPro_8() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___m_textMeshPro_8)); }
	inline TextMeshProUGUI_tBA60B913AB6151F8563F7078AD67EB6458129438 * get_m_textMeshPro_8() const { return ___m_textMeshPro_8; }
	inline TextMeshProUGUI_tBA60B913AB6151F8563F7078AD67EB6458129438 ** get_address_of_m_textMeshPro_8() { return &___m_textMeshPro_8; }
	inline void set_m_textMeshPro_8(TextMeshProUGUI_tBA60B913AB6151F8563F7078AD67EB6458129438 * value)
	{
		___m_textMeshPro_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMeshPro_8), value);
	}

	inline static int32_t get_offset_of_m_textMesh_9() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___m_textMesh_9)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_m_textMesh_9() const { return ___m_textMesh_9; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_m_textMesh_9() { return &___m_textMesh_9; }
	inline void set_m_textMesh_9(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___m_textMesh_9 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMesh_9), value);
	}

	inline static int32_t get_offset_of_m_material01_12() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___m_material01_12)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_m_material01_12() const { return ___m_material01_12; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_m_material01_12() { return &___m_material01_12; }
	inline void set_m_material01_12(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___m_material01_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_material01_12), value);
	}

	inline static int32_t get_offset_of_m_material02_13() { return static_cast<int32_t>(offsetof(Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55, ___m_material02_13)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_m_material02_13() const { return ___m_material02_13; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_m_material02_13() { return &___m_material02_13; }
	inline void set_m_material02_13(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___m_material02_13 = value;
		Il2CppCodeGenWriteBarrier((&___m_material02_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BENCHMARK01_UGUI_TDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55_H
#ifndef BENCHMARK02_T5AD0E34D131A57AAA8B39CED7AC8E60946686BB5_H
#define BENCHMARK02_T5AD0E34D131A57AAA8B39CED7AC8E60946686BB5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark02
struct  Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TMPro.Examples.Benchmark02::SpawnType
	int32_t ___SpawnType_4;
	// System.Int32 TMPro.Examples.Benchmark02::NumberOfNPC
	int32_t ___NumberOfNPC_5;
	// TMPro.Examples.TextMeshProFloatingText TMPro.Examples.Benchmark02::floatingText_Script
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * ___floatingText_Script_6;

public:
	inline static int32_t get_offset_of_SpawnType_4() { return static_cast<int32_t>(offsetof(Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5, ___SpawnType_4)); }
	inline int32_t get_SpawnType_4() const { return ___SpawnType_4; }
	inline int32_t* get_address_of_SpawnType_4() { return &___SpawnType_4; }
	inline void set_SpawnType_4(int32_t value)
	{
		___SpawnType_4 = value;
	}

	inline static int32_t get_offset_of_NumberOfNPC_5() { return static_cast<int32_t>(offsetof(Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5, ___NumberOfNPC_5)); }
	inline int32_t get_NumberOfNPC_5() const { return ___NumberOfNPC_5; }
	inline int32_t* get_address_of_NumberOfNPC_5() { return &___NumberOfNPC_5; }
	inline void set_NumberOfNPC_5(int32_t value)
	{
		___NumberOfNPC_5 = value;
	}

	inline static int32_t get_offset_of_floatingText_Script_6() { return static_cast<int32_t>(offsetof(Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5, ___floatingText_Script_6)); }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * get_floatingText_Script_6() const { return ___floatingText_Script_6; }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 ** get_address_of_floatingText_Script_6() { return &___floatingText_Script_6; }
	inline void set_floatingText_Script_6(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * value)
	{
		___floatingText_Script_6 = value;
		Il2CppCodeGenWriteBarrier((&___floatingText_Script_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BENCHMARK02_T5AD0E34D131A57AAA8B39CED7AC8E60946686BB5_H
#ifndef BENCHMARK03_TC3AB21ABCF4386EC933960A70AE20001D6D3CD87_H
#define BENCHMARK03_TC3AB21ABCF4386EC933960A70AE20001D6D3CD87_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark03
struct  Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TMPro.Examples.Benchmark03::SpawnType
	int32_t ___SpawnType_4;
	// System.Int32 TMPro.Examples.Benchmark03::NumberOfNPC
	int32_t ___NumberOfNPC_5;
	// UnityEngine.Font TMPro.Examples.Benchmark03::TheFont
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___TheFont_6;

public:
	inline static int32_t get_offset_of_SpawnType_4() { return static_cast<int32_t>(offsetof(Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87, ___SpawnType_4)); }
	inline int32_t get_SpawnType_4() const { return ___SpawnType_4; }
	inline int32_t* get_address_of_SpawnType_4() { return &___SpawnType_4; }
	inline void set_SpawnType_4(int32_t value)
	{
		___SpawnType_4 = value;
	}

	inline static int32_t get_offset_of_NumberOfNPC_5() { return static_cast<int32_t>(offsetof(Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87, ___NumberOfNPC_5)); }
	inline int32_t get_NumberOfNPC_5() const { return ___NumberOfNPC_5; }
	inline int32_t* get_address_of_NumberOfNPC_5() { return &___NumberOfNPC_5; }
	inline void set_NumberOfNPC_5(int32_t value)
	{
		___NumberOfNPC_5 = value;
	}

	inline static int32_t get_offset_of_TheFont_6() { return static_cast<int32_t>(offsetof(Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87, ___TheFont_6)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_TheFont_6() const { return ___TheFont_6; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_TheFont_6() { return &___TheFont_6; }
	inline void set_TheFont_6(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___TheFont_6 = value;
		Il2CppCodeGenWriteBarrier((&___TheFont_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BENCHMARK03_TC3AB21ABCF4386EC933960A70AE20001D6D3CD87_H
#ifndef BENCHMARK04_T428B8F183784D591AAEAD632C4C56D6C227BD6D9_H
#define BENCHMARK04_T428B8F183784D591AAEAD632C4C56D6C227BD6D9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.Benchmark04
struct  Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TMPro.Examples.Benchmark04::SpawnType
	int32_t ___SpawnType_4;
	// System.Int32 TMPro.Examples.Benchmark04::MinPointSize
	int32_t ___MinPointSize_5;
	// System.Int32 TMPro.Examples.Benchmark04::MaxPointSize
	int32_t ___MaxPointSize_6;
	// System.Int32 TMPro.Examples.Benchmark04::Steps
	int32_t ___Steps_7;
	// UnityEngine.Transform TMPro.Examples.Benchmark04::m_Transform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___m_Transform_8;

public:
	inline static int32_t get_offset_of_SpawnType_4() { return static_cast<int32_t>(offsetof(Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9, ___SpawnType_4)); }
	inline int32_t get_SpawnType_4() const { return ___SpawnType_4; }
	inline int32_t* get_address_of_SpawnType_4() { return &___SpawnType_4; }
	inline void set_SpawnType_4(int32_t value)
	{
		___SpawnType_4 = value;
	}

	inline static int32_t get_offset_of_MinPointSize_5() { return static_cast<int32_t>(offsetof(Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9, ___MinPointSize_5)); }
	inline int32_t get_MinPointSize_5() const { return ___MinPointSize_5; }
	inline int32_t* get_address_of_MinPointSize_5() { return &___MinPointSize_5; }
	inline void set_MinPointSize_5(int32_t value)
	{
		___MinPointSize_5 = value;
	}

	inline static int32_t get_offset_of_MaxPointSize_6() { return static_cast<int32_t>(offsetof(Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9, ___MaxPointSize_6)); }
	inline int32_t get_MaxPointSize_6() const { return ___MaxPointSize_6; }
	inline int32_t* get_address_of_MaxPointSize_6() { return &___MaxPointSize_6; }
	inline void set_MaxPointSize_6(int32_t value)
	{
		___MaxPointSize_6 = value;
	}

	inline static int32_t get_offset_of_Steps_7() { return static_cast<int32_t>(offsetof(Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9, ___Steps_7)); }
	inline int32_t get_Steps_7() const { return ___Steps_7; }
	inline int32_t* get_address_of_Steps_7() { return &___Steps_7; }
	inline void set_Steps_7(int32_t value)
	{
		___Steps_7 = value;
	}

	inline static int32_t get_offset_of_m_Transform_8() { return static_cast<int32_t>(offsetof(Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9, ___m_Transform_8)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_m_Transform_8() const { return ___m_Transform_8; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_m_Transform_8() { return &___m_Transform_8; }
	inline void set_m_Transform_8(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___m_Transform_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_Transform_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BENCHMARK04_T428B8F183784D591AAEAD632C4C56D6C227BD6D9_H
#ifndef CAMERACONTROLLER_T1B35987C4C1AC6395807F1CCC998C5ED956D7911_H
#define CAMERACONTROLLER_T1B35987C4C1AC6395807F1CCC998C5ED956D7911_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.CameraController
struct  CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Transform TMPro.Examples.CameraController::cameraTransform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___cameraTransform_4;
	// UnityEngine.Transform TMPro.Examples.CameraController::dummyTarget
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___dummyTarget_5;
	// UnityEngine.Transform TMPro.Examples.CameraController::CameraTarget
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___CameraTarget_6;
	// System.Single TMPro.Examples.CameraController::FollowDistance
	float ___FollowDistance_7;
	// System.Single TMPro.Examples.CameraController::MaxFollowDistance
	float ___MaxFollowDistance_8;
	// System.Single TMPro.Examples.CameraController::MinFollowDistance
	float ___MinFollowDistance_9;
	// System.Single TMPro.Examples.CameraController::ElevationAngle
	float ___ElevationAngle_10;
	// System.Single TMPro.Examples.CameraController::MaxElevationAngle
	float ___MaxElevationAngle_11;
	// System.Single TMPro.Examples.CameraController::MinElevationAngle
	float ___MinElevationAngle_12;
	// System.Single TMPro.Examples.CameraController::OrbitalAngle
	float ___OrbitalAngle_13;
	// TMPro.Examples.CameraController_CameraModes TMPro.Examples.CameraController::CameraMode
	int32_t ___CameraMode_14;
	// System.Boolean TMPro.Examples.CameraController::MovementSmoothing
	bool ___MovementSmoothing_15;
	// System.Boolean TMPro.Examples.CameraController::RotationSmoothing
	bool ___RotationSmoothing_16;
	// System.Boolean TMPro.Examples.CameraController::previousSmoothing
	bool ___previousSmoothing_17;
	// System.Single TMPro.Examples.CameraController::MovementSmoothingValue
	float ___MovementSmoothingValue_18;
	// System.Single TMPro.Examples.CameraController::RotationSmoothingValue
	float ___RotationSmoothingValue_19;
	// System.Single TMPro.Examples.CameraController::MoveSensitivity
	float ___MoveSensitivity_20;
	// UnityEngine.Vector3 TMPro.Examples.CameraController::currentVelocity
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___currentVelocity_21;
	// UnityEngine.Vector3 TMPro.Examples.CameraController::desiredPosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___desiredPosition_22;
	// System.Single TMPro.Examples.CameraController::mouseX
	float ___mouseX_23;
	// System.Single TMPro.Examples.CameraController::mouseY
	float ___mouseY_24;
	// UnityEngine.Vector3 TMPro.Examples.CameraController::moveVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___moveVector_25;
	// System.Single TMPro.Examples.CameraController::mouseWheel
	float ___mouseWheel_26;

public:
	inline static int32_t get_offset_of_cameraTransform_4() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___cameraTransform_4)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_cameraTransform_4() const { return ___cameraTransform_4; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_cameraTransform_4() { return &___cameraTransform_4; }
	inline void set_cameraTransform_4(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___cameraTransform_4 = value;
		Il2CppCodeGenWriteBarrier((&___cameraTransform_4), value);
	}

	inline static int32_t get_offset_of_dummyTarget_5() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___dummyTarget_5)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_dummyTarget_5() const { return ___dummyTarget_5; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_dummyTarget_5() { return &___dummyTarget_5; }
	inline void set_dummyTarget_5(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___dummyTarget_5 = value;
		Il2CppCodeGenWriteBarrier((&___dummyTarget_5), value);
	}

	inline static int32_t get_offset_of_CameraTarget_6() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___CameraTarget_6)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_CameraTarget_6() const { return ___CameraTarget_6; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_CameraTarget_6() { return &___CameraTarget_6; }
	inline void set_CameraTarget_6(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___CameraTarget_6 = value;
		Il2CppCodeGenWriteBarrier((&___CameraTarget_6), value);
	}

	inline static int32_t get_offset_of_FollowDistance_7() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___FollowDistance_7)); }
	inline float get_FollowDistance_7() const { return ___FollowDistance_7; }
	inline float* get_address_of_FollowDistance_7() { return &___FollowDistance_7; }
	inline void set_FollowDistance_7(float value)
	{
		___FollowDistance_7 = value;
	}

	inline static int32_t get_offset_of_MaxFollowDistance_8() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MaxFollowDistance_8)); }
	inline float get_MaxFollowDistance_8() const { return ___MaxFollowDistance_8; }
	inline float* get_address_of_MaxFollowDistance_8() { return &___MaxFollowDistance_8; }
	inline void set_MaxFollowDistance_8(float value)
	{
		___MaxFollowDistance_8 = value;
	}

	inline static int32_t get_offset_of_MinFollowDistance_9() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MinFollowDistance_9)); }
	inline float get_MinFollowDistance_9() const { return ___MinFollowDistance_9; }
	inline float* get_address_of_MinFollowDistance_9() { return &___MinFollowDistance_9; }
	inline void set_MinFollowDistance_9(float value)
	{
		___MinFollowDistance_9 = value;
	}

	inline static int32_t get_offset_of_ElevationAngle_10() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___ElevationAngle_10)); }
	inline float get_ElevationAngle_10() const { return ___ElevationAngle_10; }
	inline float* get_address_of_ElevationAngle_10() { return &___ElevationAngle_10; }
	inline void set_ElevationAngle_10(float value)
	{
		___ElevationAngle_10 = value;
	}

	inline static int32_t get_offset_of_MaxElevationAngle_11() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MaxElevationAngle_11)); }
	inline float get_MaxElevationAngle_11() const { return ___MaxElevationAngle_11; }
	inline float* get_address_of_MaxElevationAngle_11() { return &___MaxElevationAngle_11; }
	inline void set_MaxElevationAngle_11(float value)
	{
		___MaxElevationAngle_11 = value;
	}

	inline static int32_t get_offset_of_MinElevationAngle_12() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MinElevationAngle_12)); }
	inline float get_MinElevationAngle_12() const { return ___MinElevationAngle_12; }
	inline float* get_address_of_MinElevationAngle_12() { return &___MinElevationAngle_12; }
	inline void set_MinElevationAngle_12(float value)
	{
		___MinElevationAngle_12 = value;
	}

	inline static int32_t get_offset_of_OrbitalAngle_13() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___OrbitalAngle_13)); }
	inline float get_OrbitalAngle_13() const { return ___OrbitalAngle_13; }
	inline float* get_address_of_OrbitalAngle_13() { return &___OrbitalAngle_13; }
	inline void set_OrbitalAngle_13(float value)
	{
		___OrbitalAngle_13 = value;
	}

	inline static int32_t get_offset_of_CameraMode_14() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___CameraMode_14)); }
	inline int32_t get_CameraMode_14() const { return ___CameraMode_14; }
	inline int32_t* get_address_of_CameraMode_14() { return &___CameraMode_14; }
	inline void set_CameraMode_14(int32_t value)
	{
		___CameraMode_14 = value;
	}

	inline static int32_t get_offset_of_MovementSmoothing_15() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MovementSmoothing_15)); }
	inline bool get_MovementSmoothing_15() const { return ___MovementSmoothing_15; }
	inline bool* get_address_of_MovementSmoothing_15() { return &___MovementSmoothing_15; }
	inline void set_MovementSmoothing_15(bool value)
	{
		___MovementSmoothing_15 = value;
	}

	inline static int32_t get_offset_of_RotationSmoothing_16() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___RotationSmoothing_16)); }
	inline bool get_RotationSmoothing_16() const { return ___RotationSmoothing_16; }
	inline bool* get_address_of_RotationSmoothing_16() { return &___RotationSmoothing_16; }
	inline void set_RotationSmoothing_16(bool value)
	{
		___RotationSmoothing_16 = value;
	}

	inline static int32_t get_offset_of_previousSmoothing_17() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___previousSmoothing_17)); }
	inline bool get_previousSmoothing_17() const { return ___previousSmoothing_17; }
	inline bool* get_address_of_previousSmoothing_17() { return &___previousSmoothing_17; }
	inline void set_previousSmoothing_17(bool value)
	{
		___previousSmoothing_17 = value;
	}

	inline static int32_t get_offset_of_MovementSmoothingValue_18() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MovementSmoothingValue_18)); }
	inline float get_MovementSmoothingValue_18() const { return ___MovementSmoothingValue_18; }
	inline float* get_address_of_MovementSmoothingValue_18() { return &___MovementSmoothingValue_18; }
	inline void set_MovementSmoothingValue_18(float value)
	{
		___MovementSmoothingValue_18 = value;
	}

	inline static int32_t get_offset_of_RotationSmoothingValue_19() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___RotationSmoothingValue_19)); }
	inline float get_RotationSmoothingValue_19() const { return ___RotationSmoothingValue_19; }
	inline float* get_address_of_RotationSmoothingValue_19() { return &___RotationSmoothingValue_19; }
	inline void set_RotationSmoothingValue_19(float value)
	{
		___RotationSmoothingValue_19 = value;
	}

	inline static int32_t get_offset_of_MoveSensitivity_20() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___MoveSensitivity_20)); }
	inline float get_MoveSensitivity_20() const { return ___MoveSensitivity_20; }
	inline float* get_address_of_MoveSensitivity_20() { return &___MoveSensitivity_20; }
	inline void set_MoveSensitivity_20(float value)
	{
		___MoveSensitivity_20 = value;
	}

	inline static int32_t get_offset_of_currentVelocity_21() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___currentVelocity_21)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_currentVelocity_21() const { return ___currentVelocity_21; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_currentVelocity_21() { return &___currentVelocity_21; }
	inline void set_currentVelocity_21(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___currentVelocity_21 = value;
	}

	inline static int32_t get_offset_of_desiredPosition_22() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___desiredPosition_22)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_desiredPosition_22() const { return ___desiredPosition_22; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_desiredPosition_22() { return &___desiredPosition_22; }
	inline void set_desiredPosition_22(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___desiredPosition_22 = value;
	}

	inline static int32_t get_offset_of_mouseX_23() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___mouseX_23)); }
	inline float get_mouseX_23() const { return ___mouseX_23; }
	inline float* get_address_of_mouseX_23() { return &___mouseX_23; }
	inline void set_mouseX_23(float value)
	{
		___mouseX_23 = value;
	}

	inline static int32_t get_offset_of_mouseY_24() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___mouseY_24)); }
	inline float get_mouseY_24() const { return ___mouseY_24; }
	inline float* get_address_of_mouseY_24() { return &___mouseY_24; }
	inline void set_mouseY_24(float value)
	{
		___mouseY_24 = value;
	}

	inline static int32_t get_offset_of_moveVector_25() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___moveVector_25)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_moveVector_25() const { return ___moveVector_25; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_moveVector_25() { return &___moveVector_25; }
	inline void set_moveVector_25(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___moveVector_25 = value;
	}

	inline static int32_t get_offset_of_mouseWheel_26() { return static_cast<int32_t>(offsetof(CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911, ___mouseWheel_26)); }
	inline float get_mouseWheel_26() const { return ___mouseWheel_26; }
	inline float* get_address_of_mouseWheel_26() { return &___mouseWheel_26; }
	inline void set_mouseWheel_26(float value)
	{
		___mouseWheel_26 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERACONTROLLER_T1B35987C4C1AC6395807F1CCC998C5ED956D7911_H
#ifndef OBJECTSPIN_T5EEBF4BFCCD478B89C227B8F04670C937B7E10B5_H
#define OBJECTSPIN_T5EEBF4BFCCD478B89C227B8F04670C937B7E10B5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.ObjectSpin
struct  ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single TMPro.Examples.ObjectSpin::SpinSpeed
	float ___SpinSpeed_4;
	// System.Int32 TMPro.Examples.ObjectSpin::RotationRange
	int32_t ___RotationRange_5;
	// UnityEngine.Transform TMPro.Examples.ObjectSpin::m_transform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___m_transform_6;
	// System.Single TMPro.Examples.ObjectSpin::m_time
	float ___m_time_7;
	// UnityEngine.Vector3 TMPro.Examples.ObjectSpin::m_prevPOS
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_prevPOS_8;
	// UnityEngine.Vector3 TMPro.Examples.ObjectSpin::m_initial_Rotation
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_initial_Rotation_9;
	// UnityEngine.Vector3 TMPro.Examples.ObjectSpin::m_initial_Position
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_initial_Position_10;
	// UnityEngine.Color32 TMPro.Examples.ObjectSpin::m_lightColor
	Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  ___m_lightColor_11;
	// System.Int32 TMPro.Examples.ObjectSpin::frames
	int32_t ___frames_12;
	// TMPro.Examples.ObjectSpin_MotionType TMPro.Examples.ObjectSpin::Motion
	int32_t ___Motion_13;

public:
	inline static int32_t get_offset_of_SpinSpeed_4() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___SpinSpeed_4)); }
	inline float get_SpinSpeed_4() const { return ___SpinSpeed_4; }
	inline float* get_address_of_SpinSpeed_4() { return &___SpinSpeed_4; }
	inline void set_SpinSpeed_4(float value)
	{
		___SpinSpeed_4 = value;
	}

	inline static int32_t get_offset_of_RotationRange_5() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___RotationRange_5)); }
	inline int32_t get_RotationRange_5() const { return ___RotationRange_5; }
	inline int32_t* get_address_of_RotationRange_5() { return &___RotationRange_5; }
	inline void set_RotationRange_5(int32_t value)
	{
		___RotationRange_5 = value;
	}

	inline static int32_t get_offset_of_m_transform_6() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___m_transform_6)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_m_transform_6() const { return ___m_transform_6; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_m_transform_6() { return &___m_transform_6; }
	inline void set_m_transform_6(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___m_transform_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_transform_6), value);
	}

	inline static int32_t get_offset_of_m_time_7() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___m_time_7)); }
	inline float get_m_time_7() const { return ___m_time_7; }
	inline float* get_address_of_m_time_7() { return &___m_time_7; }
	inline void set_m_time_7(float value)
	{
		___m_time_7 = value;
	}

	inline static int32_t get_offset_of_m_prevPOS_8() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___m_prevPOS_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_prevPOS_8() const { return ___m_prevPOS_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_prevPOS_8() { return &___m_prevPOS_8; }
	inline void set_m_prevPOS_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_prevPOS_8 = value;
	}

	inline static int32_t get_offset_of_m_initial_Rotation_9() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___m_initial_Rotation_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_initial_Rotation_9() const { return ___m_initial_Rotation_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_initial_Rotation_9() { return &___m_initial_Rotation_9; }
	inline void set_m_initial_Rotation_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_initial_Rotation_9 = value;
	}

	inline static int32_t get_offset_of_m_initial_Position_10() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___m_initial_Position_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_initial_Position_10() const { return ___m_initial_Position_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_initial_Position_10() { return &___m_initial_Position_10; }
	inline void set_m_initial_Position_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_initial_Position_10 = value;
	}

	inline static int32_t get_offset_of_m_lightColor_11() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___m_lightColor_11)); }
	inline Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  get_m_lightColor_11() const { return ___m_lightColor_11; }
	inline Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23 * get_address_of_m_lightColor_11() { return &___m_lightColor_11; }
	inline void set_m_lightColor_11(Color32_t23ABC4AE0E0BDFD2E22EE1FA0DA3904FFE5F6E23  value)
	{
		___m_lightColor_11 = value;
	}

	inline static int32_t get_offset_of_frames_12() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___frames_12)); }
	inline int32_t get_frames_12() const { return ___frames_12; }
	inline int32_t* get_address_of_frames_12() { return &___frames_12; }
	inline void set_frames_12(int32_t value)
	{
		___frames_12 = value;
	}

	inline static int32_t get_offset_of_Motion_13() { return static_cast<int32_t>(offsetof(ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5, ___Motion_13)); }
	inline int32_t get_Motion_13() const { return ___Motion_13; }
	inline int32_t* get_address_of_Motion_13() { return &___Motion_13; }
	inline void set_Motion_13(int32_t value)
	{
		___Motion_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJECTSPIN_T5EEBF4BFCCD478B89C227B8F04670C937B7E10B5_H
#ifndef SHADERPROPANIMATOR_TBD6FBF3230284F283E6BC35E93E5A260853D5A72_H
#define SHADERPROPANIMATOR_TBD6FBF3230284F283E6BC35E93E5A260853D5A72_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.ShaderPropAnimator
struct  ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Renderer TMPro.Examples.ShaderPropAnimator::m_Renderer
	Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * ___m_Renderer_4;
	// UnityEngine.Material TMPro.Examples.ShaderPropAnimator::m_Material
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___m_Material_5;
	// UnityEngine.AnimationCurve TMPro.Examples.ShaderPropAnimator::GlowCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___GlowCurve_6;
	// System.Single TMPro.Examples.ShaderPropAnimator::m_frame
	float ___m_frame_7;

public:
	inline static int32_t get_offset_of_m_Renderer_4() { return static_cast<int32_t>(offsetof(ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72, ___m_Renderer_4)); }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * get_m_Renderer_4() const { return ___m_Renderer_4; }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 ** get_address_of_m_Renderer_4() { return &___m_Renderer_4; }
	inline void set_m_Renderer_4(Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * value)
	{
		___m_Renderer_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Renderer_4), value);
	}

	inline static int32_t get_offset_of_m_Material_5() { return static_cast<int32_t>(offsetof(ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72, ___m_Material_5)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_m_Material_5() const { return ___m_Material_5; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_m_Material_5() { return &___m_Material_5; }
	inline void set_m_Material_5(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___m_Material_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Material_5), value);
	}

	inline static int32_t get_offset_of_GlowCurve_6() { return static_cast<int32_t>(offsetof(ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72, ___GlowCurve_6)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_GlowCurve_6() const { return ___GlowCurve_6; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_GlowCurve_6() { return &___GlowCurve_6; }
	inline void set_GlowCurve_6(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___GlowCurve_6 = value;
		Il2CppCodeGenWriteBarrier((&___GlowCurve_6), value);
	}

	inline static int32_t get_offset_of_m_frame_7() { return static_cast<int32_t>(offsetof(ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72, ___m_frame_7)); }
	inline float get_m_frame_7() const { return ___m_frame_7; }
	inline float* get_address_of_m_frame_7() { return &___m_frame_7; }
	inline void set_m_frame_7(float value)
	{
		___m_frame_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SHADERPROPANIMATOR_TBD6FBF3230284F283E6BC35E93E5A260853D5A72_H
#ifndef SIMPLESCRIPT_TBCE5C1CADFA47423C376344DE84BC0C57CEEC844_H
#define SIMPLESCRIPT_TBCE5C1CADFA47423C376344DE84BC0C57CEEC844_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.SimpleScript
struct  SimpleScript_tBCE5C1CADFA47423C376344DE84BC0C57CEEC844  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.TextMeshPro TMPro.Examples.SimpleScript::m_textMeshPro
	TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * ___m_textMeshPro_4;
	// System.Single TMPro.Examples.SimpleScript::m_frame
	float ___m_frame_6;

public:
	inline static int32_t get_offset_of_m_textMeshPro_4() { return static_cast<int32_t>(offsetof(SimpleScript_tBCE5C1CADFA47423C376344DE84BC0C57CEEC844, ___m_textMeshPro_4)); }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * get_m_textMeshPro_4() const { return ___m_textMeshPro_4; }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 ** get_address_of_m_textMeshPro_4() { return &___m_textMeshPro_4; }
	inline void set_m_textMeshPro_4(TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * value)
	{
		___m_textMeshPro_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMeshPro_4), value);
	}

	inline static int32_t get_offset_of_m_frame_6() { return static_cast<int32_t>(offsetof(SimpleScript_tBCE5C1CADFA47423C376344DE84BC0C57CEEC844, ___m_frame_6)); }
	inline float get_m_frame_6() const { return ___m_frame_6; }
	inline float* get_address_of_m_frame_6() { return &___m_frame_6; }
	inline void set_m_frame_6(float value)
	{
		___m_frame_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIMPLESCRIPT_TBCE5C1CADFA47423C376344DE84BC0C57CEEC844_H
#ifndef SKEWTEXTEXAMPLE_T593F30AC17BCC5AC48767730079C01C081EB5DE7_H
#define SKEWTEXTEXAMPLE_T593F30AC17BCC5AC48767730079C01C081EB5DE7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.SkewTextExample
struct  SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.TMP_Text TMPro.Examples.SkewTextExample::m_TextComponent
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___m_TextComponent_4;
	// UnityEngine.AnimationCurve TMPro.Examples.SkewTextExample::VertexCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___VertexCurve_5;
	// System.Single TMPro.Examples.SkewTextExample::CurveScale
	float ___CurveScale_6;
	// System.Single TMPro.Examples.SkewTextExample::ShearAmount
	float ___ShearAmount_7;

public:
	inline static int32_t get_offset_of_m_TextComponent_4() { return static_cast<int32_t>(offsetof(SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7, ___m_TextComponent_4)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_m_TextComponent_4() const { return ___m_TextComponent_4; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_m_TextComponent_4() { return &___m_TextComponent_4; }
	inline void set_m_TextComponent_4(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___m_TextComponent_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_TextComponent_4), value);
	}

	inline static int32_t get_offset_of_VertexCurve_5() { return static_cast<int32_t>(offsetof(SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7, ___VertexCurve_5)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_VertexCurve_5() const { return ___VertexCurve_5; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_VertexCurve_5() { return &___VertexCurve_5; }
	inline void set_VertexCurve_5(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___VertexCurve_5 = value;
		Il2CppCodeGenWriteBarrier((&___VertexCurve_5), value);
	}

	inline static int32_t get_offset_of_CurveScale_6() { return static_cast<int32_t>(offsetof(SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7, ___CurveScale_6)); }
	inline float get_CurveScale_6() const { return ___CurveScale_6; }
	inline float* get_address_of_CurveScale_6() { return &___CurveScale_6; }
	inline void set_CurveScale_6(float value)
	{
		___CurveScale_6 = value;
	}

	inline static int32_t get_offset_of_ShearAmount_7() { return static_cast<int32_t>(offsetof(SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7, ___ShearAmount_7)); }
	inline float get_ShearAmount_7() const { return ___ShearAmount_7; }
	inline float* get_address_of_ShearAmount_7() { return &___ShearAmount_7; }
	inline void set_ShearAmount_7(float value)
	{
		___ShearAmount_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SKEWTEXTEXAMPLE_T593F30AC17BCC5AC48767730079C01C081EB5DE7_H
#ifndef TMP_EXAMPLESCRIPT_01_T4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8_H
#define TMP_EXAMPLESCRIPT_01_T4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TMP_ExampleScript_01
struct  TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.Examples.TMP_ExampleScript_01_objectType TMPro.Examples.TMP_ExampleScript_01::ObjectType
	int32_t ___ObjectType_4;
	// System.Boolean TMPro.Examples.TMP_ExampleScript_01::isStatic
	bool ___isStatic_5;
	// TMPro.TMP_Text TMPro.Examples.TMP_ExampleScript_01::m_text
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___m_text_6;
	// System.Int32 TMPro.Examples.TMP_ExampleScript_01::count
	int32_t ___count_8;

public:
	inline static int32_t get_offset_of_ObjectType_4() { return static_cast<int32_t>(offsetof(TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8, ___ObjectType_4)); }
	inline int32_t get_ObjectType_4() const { return ___ObjectType_4; }
	inline int32_t* get_address_of_ObjectType_4() { return &___ObjectType_4; }
	inline void set_ObjectType_4(int32_t value)
	{
		___ObjectType_4 = value;
	}

	inline static int32_t get_offset_of_isStatic_5() { return static_cast<int32_t>(offsetof(TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8, ___isStatic_5)); }
	inline bool get_isStatic_5() const { return ___isStatic_5; }
	inline bool* get_address_of_isStatic_5() { return &___isStatic_5; }
	inline void set_isStatic_5(bool value)
	{
		___isStatic_5 = value;
	}

	inline static int32_t get_offset_of_m_text_6() { return static_cast<int32_t>(offsetof(TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8, ___m_text_6)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_m_text_6() const { return ___m_text_6; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_m_text_6() { return &___m_text_6; }
	inline void set_m_text_6(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___m_text_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_text_6), value);
	}

	inline static int32_t get_offset_of_count_8() { return static_cast<int32_t>(offsetof(TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8, ___count_8)); }
	inline int32_t get_count_8() const { return ___count_8; }
	inline int32_t* get_address_of_count_8() { return &___count_8; }
	inline void set_count_8(int32_t value)
	{
		___count_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TMP_EXAMPLESCRIPT_01_T4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8_H
#ifndef TMP_FRAMERATECOUNTER_T154205AC6610245B31CEF1C182FA4B4862D9D07F_H
#define TMP_FRAMERATECOUNTER_T154205AC6610245B31CEF1C182FA4B4862D9D07F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TMP_FrameRateCounter
struct  TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single TMPro.Examples.TMP_FrameRateCounter::UpdateInterval
	float ___UpdateInterval_4;
	// System.Single TMPro.Examples.TMP_FrameRateCounter::m_LastInterval
	float ___m_LastInterval_5;
	// System.Int32 TMPro.Examples.TMP_FrameRateCounter::m_Frames
	int32_t ___m_Frames_6;
	// TMPro.Examples.TMP_FrameRateCounter_FpsCounterAnchorPositions TMPro.Examples.TMP_FrameRateCounter::AnchorPosition
	int32_t ___AnchorPosition_7;
	// System.String TMPro.Examples.TMP_FrameRateCounter::htmlColorTag
	String_t* ___htmlColorTag_8;
	// TMPro.TextMeshPro TMPro.Examples.TMP_FrameRateCounter::m_TextMeshPro
	TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * ___m_TextMeshPro_10;
	// UnityEngine.Transform TMPro.Examples.TMP_FrameRateCounter::m_frameCounter_transform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___m_frameCounter_transform_11;
	// UnityEngine.Camera TMPro.Examples.TMP_FrameRateCounter::m_camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___m_camera_12;
	// TMPro.Examples.TMP_FrameRateCounter_FpsCounterAnchorPositions TMPro.Examples.TMP_FrameRateCounter::last_AnchorPosition
	int32_t ___last_AnchorPosition_13;

public:
	inline static int32_t get_offset_of_UpdateInterval_4() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___UpdateInterval_4)); }
	inline float get_UpdateInterval_4() const { return ___UpdateInterval_4; }
	inline float* get_address_of_UpdateInterval_4() { return &___UpdateInterval_4; }
	inline void set_UpdateInterval_4(float value)
	{
		___UpdateInterval_4 = value;
	}

	inline static int32_t get_offset_of_m_LastInterval_5() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___m_LastInterval_5)); }
	inline float get_m_LastInterval_5() const { return ___m_LastInterval_5; }
	inline float* get_address_of_m_LastInterval_5() { return &___m_LastInterval_5; }
	inline void set_m_LastInterval_5(float value)
	{
		___m_LastInterval_5 = value;
	}

	inline static int32_t get_offset_of_m_Frames_6() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___m_Frames_6)); }
	inline int32_t get_m_Frames_6() const { return ___m_Frames_6; }
	inline int32_t* get_address_of_m_Frames_6() { return &___m_Frames_6; }
	inline void set_m_Frames_6(int32_t value)
	{
		___m_Frames_6 = value;
	}

	inline static int32_t get_offset_of_AnchorPosition_7() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___AnchorPosition_7)); }
	inline int32_t get_AnchorPosition_7() const { return ___AnchorPosition_7; }
	inline int32_t* get_address_of_AnchorPosition_7() { return &___AnchorPosition_7; }
	inline void set_AnchorPosition_7(int32_t value)
	{
		___AnchorPosition_7 = value;
	}

	inline static int32_t get_offset_of_htmlColorTag_8() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___htmlColorTag_8)); }
	inline String_t* get_htmlColorTag_8() const { return ___htmlColorTag_8; }
	inline String_t** get_address_of_htmlColorTag_8() { return &___htmlColorTag_8; }
	inline void set_htmlColorTag_8(String_t* value)
	{
		___htmlColorTag_8 = value;
		Il2CppCodeGenWriteBarrier((&___htmlColorTag_8), value);
	}

	inline static int32_t get_offset_of_m_TextMeshPro_10() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___m_TextMeshPro_10)); }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * get_m_TextMeshPro_10() const { return ___m_TextMeshPro_10; }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 ** get_address_of_m_TextMeshPro_10() { return &___m_TextMeshPro_10; }
	inline void set_m_TextMeshPro_10(TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * value)
	{
		___m_TextMeshPro_10 = value;
		Il2CppCodeGenWriteBarrier((&___m_TextMeshPro_10), value);
	}

	inline static int32_t get_offset_of_m_frameCounter_transform_11() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___m_frameCounter_transform_11)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_m_frameCounter_transform_11() const { return ___m_frameCounter_transform_11; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_m_frameCounter_transform_11() { return &___m_frameCounter_transform_11; }
	inline void set_m_frameCounter_transform_11(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___m_frameCounter_transform_11 = value;
		Il2CppCodeGenWriteBarrier((&___m_frameCounter_transform_11), value);
	}

	inline static int32_t get_offset_of_m_camera_12() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___m_camera_12)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_m_camera_12() const { return ___m_camera_12; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_m_camera_12() { return &___m_camera_12; }
	inline void set_m_camera_12(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___m_camera_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_camera_12), value);
	}

	inline static int32_t get_offset_of_last_AnchorPosition_13() { return static_cast<int32_t>(offsetof(TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F, ___last_AnchorPosition_13)); }
	inline int32_t get_last_AnchorPosition_13() const { return ___last_AnchorPosition_13; }
	inline int32_t* get_address_of_last_AnchorPosition_13() { return &___last_AnchorPosition_13; }
	inline void set_last_AnchorPosition_13(int32_t value)
	{
		___last_AnchorPosition_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TMP_FRAMERATECOUNTER_T154205AC6610245B31CEF1C182FA4B4862D9D07F_H
#ifndef TMP_TEXTEVENTCHECK_T5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB_H
#define TMP_TEXTEVENTCHECK_T5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TMP_TextEventCheck
struct  TMP_TextEventCheck_t5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.TMP_TextEventHandler TMPro.Examples.TMP_TextEventCheck::TextEventHandler
	TMP_TextEventHandler_t6046295E0F06C5138916541DBE6B476E6FE66B54 * ___TextEventHandler_4;

public:
	inline static int32_t get_offset_of_TextEventHandler_4() { return static_cast<int32_t>(offsetof(TMP_TextEventCheck_t5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB, ___TextEventHandler_4)); }
	inline TMP_TextEventHandler_t6046295E0F06C5138916541DBE6B476E6FE66B54 * get_TextEventHandler_4() const { return ___TextEventHandler_4; }
	inline TMP_TextEventHandler_t6046295E0F06C5138916541DBE6B476E6FE66B54 ** get_address_of_TextEventHandler_4() { return &___TextEventHandler_4; }
	inline void set_TextEventHandler_4(TMP_TextEventHandler_t6046295E0F06C5138916541DBE6B476E6FE66B54 * value)
	{
		___TextEventHandler_4 = value;
		Il2CppCodeGenWriteBarrier((&___TextEventHandler_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TMP_TEXTEVENTCHECK_T5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB_H
#ifndef TELETYPE_TD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716_H
#define TELETYPE_TD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TeleType
struct  TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String TMPro.Examples.TeleType::label01
	String_t* ___label01_4;
	// System.String TMPro.Examples.TeleType::label02
	String_t* ___label02_5;
	// TMPro.TMP_Text TMPro.Examples.TeleType::m_textMeshPro
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___m_textMeshPro_6;

public:
	inline static int32_t get_offset_of_label01_4() { return static_cast<int32_t>(offsetof(TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716, ___label01_4)); }
	inline String_t* get_label01_4() const { return ___label01_4; }
	inline String_t** get_address_of_label01_4() { return &___label01_4; }
	inline void set_label01_4(String_t* value)
	{
		___label01_4 = value;
		Il2CppCodeGenWriteBarrier((&___label01_4), value);
	}

	inline static int32_t get_offset_of_label02_5() { return static_cast<int32_t>(offsetof(TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716, ___label02_5)); }
	inline String_t* get_label02_5() const { return ___label02_5; }
	inline String_t** get_address_of_label02_5() { return &___label02_5; }
	inline void set_label02_5(String_t* value)
	{
		___label02_5 = value;
		Il2CppCodeGenWriteBarrier((&___label02_5), value);
	}

	inline static int32_t get_offset_of_m_textMeshPro_6() { return static_cast<int32_t>(offsetof(TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716, ___m_textMeshPro_6)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_m_textMeshPro_6() const { return ___m_textMeshPro_6; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_m_textMeshPro_6() { return &___m_textMeshPro_6; }
	inline void set_m_textMeshPro_6(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___m_textMeshPro_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMeshPro_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TELETYPE_TD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716_H
#ifndef TEXTCONSOLESIMULATOR_T259F9E6207B0D6762776D957F966754564B55163_H
#define TEXTCONSOLESIMULATOR_T259F9E6207B0D6762776D957F966754564B55163_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextConsoleSimulator
struct  TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.TMP_Text TMPro.Examples.TextConsoleSimulator::m_TextComponent
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___m_TextComponent_4;
	// System.Boolean TMPro.Examples.TextConsoleSimulator::hasTextChanged
	bool ___hasTextChanged_5;

public:
	inline static int32_t get_offset_of_m_TextComponent_4() { return static_cast<int32_t>(offsetof(TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163, ___m_TextComponent_4)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_m_TextComponent_4() const { return ___m_TextComponent_4; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_m_TextComponent_4() { return &___m_TextComponent_4; }
	inline void set_m_TextComponent_4(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___m_TextComponent_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_TextComponent_4), value);
	}

	inline static int32_t get_offset_of_hasTextChanged_5() { return static_cast<int32_t>(offsetof(TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163, ___hasTextChanged_5)); }
	inline bool get_hasTextChanged_5() const { return ___hasTextChanged_5; }
	inline bool* get_address_of_hasTextChanged_5() { return &___hasTextChanged_5; }
	inline void set_hasTextChanged_5(bool value)
	{
		___hasTextChanged_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTCONSOLESIMULATOR_T259F9E6207B0D6762776D957F966754564B55163_H
#ifndef TEXTMESHPROFLOATINGTEXT_TD52C5B081FC480F24349C2C0F5099F0693EEC913_H
#define TEXTMESHPROFLOATINGTEXT_TD52C5B081FC480F24349C2C0F5099F0693EEC913_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextMeshProFloatingText
struct  TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Font TMPro.Examples.TextMeshProFloatingText::TheFont
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___TheFont_4;
	// UnityEngine.GameObject TMPro.Examples.TextMeshProFloatingText::m_floatingText
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___m_floatingText_5;
	// TMPro.TextMeshPro TMPro.Examples.TextMeshProFloatingText::m_textMeshPro
	TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * ___m_textMeshPro_6;
	// UnityEngine.TextMesh TMPro.Examples.TextMeshProFloatingText::m_textMesh
	TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * ___m_textMesh_7;
	// UnityEngine.Transform TMPro.Examples.TextMeshProFloatingText::m_transform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___m_transform_8;
	// UnityEngine.Transform TMPro.Examples.TextMeshProFloatingText::m_floatingText_Transform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___m_floatingText_Transform_9;
	// UnityEngine.Transform TMPro.Examples.TextMeshProFloatingText::m_cameraTransform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___m_cameraTransform_10;
	// UnityEngine.Vector3 TMPro.Examples.TextMeshProFloatingText::lastPOS
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lastPOS_11;
	// UnityEngine.Quaternion TMPro.Examples.TextMeshProFloatingText::lastRotation
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___lastRotation_12;
	// System.Int32 TMPro.Examples.TextMeshProFloatingText::SpawnType
	int32_t ___SpawnType_13;

public:
	inline static int32_t get_offset_of_TheFont_4() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___TheFont_4)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_TheFont_4() const { return ___TheFont_4; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_TheFont_4() { return &___TheFont_4; }
	inline void set_TheFont_4(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___TheFont_4 = value;
		Il2CppCodeGenWriteBarrier((&___TheFont_4), value);
	}

	inline static int32_t get_offset_of_m_floatingText_5() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___m_floatingText_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_m_floatingText_5() const { return ___m_floatingText_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_m_floatingText_5() { return &___m_floatingText_5; }
	inline void set_m_floatingText_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___m_floatingText_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_floatingText_5), value);
	}

	inline static int32_t get_offset_of_m_textMeshPro_6() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___m_textMeshPro_6)); }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * get_m_textMeshPro_6() const { return ___m_textMeshPro_6; }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 ** get_address_of_m_textMeshPro_6() { return &___m_textMeshPro_6; }
	inline void set_m_textMeshPro_6(TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * value)
	{
		___m_textMeshPro_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMeshPro_6), value);
	}

	inline static int32_t get_offset_of_m_textMesh_7() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___m_textMesh_7)); }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * get_m_textMesh_7() const { return ___m_textMesh_7; }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A ** get_address_of_m_textMesh_7() { return &___m_textMesh_7; }
	inline void set_m_textMesh_7(TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * value)
	{
		___m_textMesh_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_textMesh_7), value);
	}

	inline static int32_t get_offset_of_m_transform_8() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___m_transform_8)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_m_transform_8() const { return ___m_transform_8; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_m_transform_8() { return &___m_transform_8; }
	inline void set_m_transform_8(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___m_transform_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_transform_8), value);
	}

	inline static int32_t get_offset_of_m_floatingText_Transform_9() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___m_floatingText_Transform_9)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_m_floatingText_Transform_9() const { return ___m_floatingText_Transform_9; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_m_floatingText_Transform_9() { return &___m_floatingText_Transform_9; }
	inline void set_m_floatingText_Transform_9(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___m_floatingText_Transform_9 = value;
		Il2CppCodeGenWriteBarrier((&___m_floatingText_Transform_9), value);
	}

	inline static int32_t get_offset_of_m_cameraTransform_10() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___m_cameraTransform_10)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_m_cameraTransform_10() const { return ___m_cameraTransform_10; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_m_cameraTransform_10() { return &___m_cameraTransform_10; }
	inline void set_m_cameraTransform_10(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___m_cameraTransform_10 = value;
		Il2CppCodeGenWriteBarrier((&___m_cameraTransform_10), value);
	}

	inline static int32_t get_offset_of_lastPOS_11() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___lastPOS_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lastPOS_11() const { return ___lastPOS_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lastPOS_11() { return &___lastPOS_11; }
	inline void set_lastPOS_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lastPOS_11 = value;
	}

	inline static int32_t get_offset_of_lastRotation_12() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___lastRotation_12)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_lastRotation_12() const { return ___lastRotation_12; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_lastRotation_12() { return &___lastRotation_12; }
	inline void set_lastRotation_12(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___lastRotation_12 = value;
	}

	inline static int32_t get_offset_of_SpawnType_13() { return static_cast<int32_t>(offsetof(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913, ___SpawnType_13)); }
	inline int32_t get_SpawnType_13() const { return ___SpawnType_13; }
	inline int32_t* get_address_of_SpawnType_13() { return &___SpawnType_13; }
	inline void set_SpawnType_13(int32_t value)
	{
		___SpawnType_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTMESHPROFLOATINGTEXT_TD52C5B081FC480F24349C2C0F5099F0693EEC913_H
#ifndef TEXTMESHSPAWNER_T7A50739A3F9750469C9F130607DA20D66CA22686_H
#define TEXTMESHSPAWNER_T7A50739A3F9750469C9F130607DA20D66CA22686_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// TMPro.Examples.TextMeshSpawner
struct  TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TMPro.Examples.TextMeshSpawner::SpawnType
	int32_t ___SpawnType_4;
	// System.Int32 TMPro.Examples.TextMeshSpawner::NumberOfNPC
	int32_t ___NumberOfNPC_5;
	// UnityEngine.Font TMPro.Examples.TextMeshSpawner::TheFont
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___TheFont_6;
	// TMPro.Examples.TextMeshProFloatingText TMPro.Examples.TextMeshSpawner::floatingText_Script
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * ___floatingText_Script_7;

public:
	inline static int32_t get_offset_of_SpawnType_4() { return static_cast<int32_t>(offsetof(TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686, ___SpawnType_4)); }
	inline int32_t get_SpawnType_4() const { return ___SpawnType_4; }
	inline int32_t* get_address_of_SpawnType_4() { return &___SpawnType_4; }
	inline void set_SpawnType_4(int32_t value)
	{
		___SpawnType_4 = value;
	}

	inline static int32_t get_offset_of_NumberOfNPC_5() { return static_cast<int32_t>(offsetof(TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686, ___NumberOfNPC_5)); }
	inline int32_t get_NumberOfNPC_5() const { return ___NumberOfNPC_5; }
	inline int32_t* get_address_of_NumberOfNPC_5() { return &___NumberOfNPC_5; }
	inline void set_NumberOfNPC_5(int32_t value)
	{
		___NumberOfNPC_5 = value;
	}

	inline static int32_t get_offset_of_TheFont_6() { return static_cast<int32_t>(offsetof(TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686, ___TheFont_6)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_TheFont_6() const { return ___TheFont_6; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_TheFont_6() { return &___TheFont_6; }
	inline void set_TheFont_6(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___TheFont_6 = value;
		Il2CppCodeGenWriteBarrier((&___TheFont_6), value);
	}

	inline static int32_t get_offset_of_floatingText_Script_7() { return static_cast<int32_t>(offsetof(TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686, ___floatingText_Script_7)); }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * get_floatingText_Script_7() const { return ___floatingText_Script_7; }
	inline TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 ** get_address_of_floatingText_Script_7() { return &___floatingText_Script_7; }
	inline void set_floatingText_Script_7(TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913 * value)
	{
		___floatingText_Script_7 = value;
		Il2CppCodeGenWriteBarrier((&___floatingText_Script_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTMESHSPAWNER_T7A50739A3F9750469C9F130607DA20D66CA22686_H
#ifndef TEMPLATE_T84905F33028DA975E24ED30359B0289BE0D58737_H
#define TEMPLATE_T84905F33028DA975E24ED30359B0289BE0D58737_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Template
struct  Template_t84905F33028DA975E24ED30359B0289BE0D58737  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject Template::rank
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___rank_4;
	// UnityEngine.GameObject Template::player
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___player_5;
	// UnityEngine.GameObject Template::score
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___score_6;

public:
	inline static int32_t get_offset_of_rank_4() { return static_cast<int32_t>(offsetof(Template_t84905F33028DA975E24ED30359B0289BE0D58737, ___rank_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_rank_4() const { return ___rank_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_rank_4() { return &___rank_4; }
	inline void set_rank_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___rank_4 = value;
		Il2CppCodeGenWriteBarrier((&___rank_4), value);
	}

	inline static int32_t get_offset_of_player_5() { return static_cast<int32_t>(offsetof(Template_t84905F33028DA975E24ED30359B0289BE0D58737, ___player_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_player_5() const { return ___player_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_player_5() { return &___player_5; }
	inline void set_player_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___player_5 = value;
		Il2CppCodeGenWriteBarrier((&___player_5), value);
	}

	inline static int32_t get_offset_of_score_6() { return static_cast<int32_t>(offsetof(Template_t84905F33028DA975E24ED30359B0289BE0D58737, ___score_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_score_6() const { return ___score_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_score_6() { return &___score_6; }
	inline void set_score_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___score_6 = value;
		Il2CppCodeGenWriteBarrier((&___score_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEMPLATE_T84905F33028DA975E24ED30359B0289BE0D58737_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2400 = { sizeof (U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2400[4] = 
{
	U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4::get_offset_of_U24this_0(),
	U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4::get_offset_of_U24current_1(),
	U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4::get_offset_of_U24disposing_2(),
	U3CRefreshU3Ec__Iterator0_t491A3481D3E1363C2F2E126516D088D0D19082F4::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2401 = { sizeof (Eliminate_tD19E434B1BA30A6843A103A9C12F718FC7CEB58C), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2402 = { sizeof (EnemyCollider_tA27BF3664568741AC689D0579029618549B94906), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2402[7] = 
{
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_killScore_4(),
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_enemyMaxHP_5(),
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_damage_6(),
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_collisionDetected_7(),
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_scoreText_8(),
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_explosionAnimationObject_9(),
	EnemyCollider_tA27BF3664568741AC689D0579029618549B94906::get_offset_of_isBlinkable_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2403 = { sizeof (EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2403[6] = 
{
	EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616::get_offset_of_missileSpeed_4(),
	EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616::get_offset_of_missileDirection_5(),
	EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616::get_offset_of_missilePosition_6(),
	EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616::get_offset_of_isDirectionSet_7(),
	EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616::get_offset_of_topRight_8(),
	EnemyMissile_t5B59658B2A3A83D8D000EDD07D448C9821E5D616::get_offset_of_bottomLeft_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2404 = { sizeof (EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2404[5] = 
{
	EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40::get_offset_of_enemyMissile_4(),
	EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40::get_offset_of_playerShip_5(),
	EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40::get_offset_of_direction_6(),
	EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40::get_offset_of_startTime_7(),
	EnemyShooter_t98A33AB24BEB6E9D1EC2328DB2D3026F43B5BE40::get_offset_of_repeatTime_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2405 = { sizeof (Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2405[5] = 
{
	Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB::get_offset_of_speed_4(),
	Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB::get_offset_of_stopped_5(),
	Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB::get_offset_of_player_6(),
	Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB::get_offset_of_stop_7(),
	Follow_t6B5FCF15867FC785BC06DB09383B5A48E0B4A9AB::get_offset_of_stoppingDistance_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2406 = { sizeof (GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2406[3] = 
{
	GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258::get_offset_of_gameOver_4(),
	GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258::get_offset_of_spawnManager_5(),
	GameManager_t0CECDB772A95511D7F1B74DA25E1BDA4BEE39258::get_offset_of_gameIsOver_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2407 = { sizeof (U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2407[5] = 
{
	U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC::get_offset_of_time_0(),
	U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC::get_offset_of_go_1(),
	U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC::get_offset_of_U24current_2(),
	U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC::get_offset_of_U24disposing_3(),
	U3CShowObjectU3Ec__Iterator0_tE22CD38779E13CD2EF83A3074FDC7791AB8731BC::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2408 = { sizeof (U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2408[5] = 
{
	U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22::get_offset_of_time_0(),
	U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22::get_offset_of_go_1(),
	U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22::get_offset_of_U24current_2(),
	U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22::get_offset_of_U24disposing_3(),
	U3CDisableObjectU3Ec__Iterator1_t336C5B2D046246A629236BA814DA0D3C09D14A22::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2409 = { sizeof (GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89), -1, sizeof(GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2409[3] = 
{
	GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89_StaticFields::get_offset_of_U3CPausedU3Ek__BackingField_4(),
	GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89::get_offset_of_pauseKey_5(),
	GameMenu_t152B20D958EF22AD18FAB0AC8ABCB9A1F280BC89::get_offset_of_gameMenuUI_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2410 = { sizeof (Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2410[5] = 
{
	Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45::get_offset_of_speed_4(),
	Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45::get_offset_of_maxDistance_5(),
	Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45::get_offset_of_bottomLeft_6(),
	Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45::get_offset_of_gunnerPosition_7(),
	Gunner_t4BB6FBBA75E238C2E87AC097E5DDC29A3F469B45::get_offset_of_nextPosition_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2411 = { sizeof (HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2411[7] = 
{
	0,
	HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC::get_offset_of_livesText_5(),
	HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC::get_offset_of_healthBar_6(),
	HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC::get_offset_of_currentLives_7(),
	HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC::get_offset_of_U3CDamageHPU3Ek__BackingField_8(),
	HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC::get_offset_of_U3CMaxHPU3Ek__BackingField_9(),
	HealthPoints_tC670158B3E1CFD400DEF519CAD7AE417B30A5FDC::get_offset_of_hpRatio_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2412 = { sizeof (HeartCollider_t8500C8D4D1517183AC18F2687487198EF403BF7D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2412[2] = 
{
	HeartCollider_t8500C8D4D1517183AC18F2687487198EF403BF7D::get_offset_of_playerShip_4(),
	HeartCollider_t8500C8D4D1517183AC18F2687487198EF403BF7D::get_offset_of_isBlinkable_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2413 = { sizeof (HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2413[1] = 
{
	HumbleMovement_t04AB4236479ACEDFD7458821DD750DCB0CFAC30C::get_offset_of_speed_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2414 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2415 = { sizeof (UnityService_tFBBD4B37C3CFC02004512FB59BA0A8E7833A8754), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2416 = { sizeof (Menu_t92DE8FC91DDF60C97E1542988D57700F9882B3B5), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2417 = { sizeof (MissileCollider_tD7605E471DEE089998553FB9DD4251081E878FEB), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2418 = { sizeof (MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2418[12] = 
{
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_speed_4(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_startWaitTime_5(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_waitTime_6(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_randomPosition_7(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_movingPositions_8(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_positionObjects_9(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_playerShip_10(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_direction_11(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_rotationSpeed_12(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_topRight_13(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_bottomLeft_14(),
	MotherShip_t89DEA61980C543BB64202F85B98CBAF7B2711D30::get_offset_of_spawnManager_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2419 = { sizeof (ObjectGravity_t3769B3F8C7DA666CDC6589A1FE52B64AA520128A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2419[2] = 
{
	ObjectGravity_t3769B3F8C7DA666CDC6589A1FE52B64AA520128A::get_offset_of_speed_4(),
	ObjectGravity_t3769B3F8C7DA666CDC6589A1FE52B64AA520128A::get_offset_of_objectPosition_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2420 = { sizeof (OutOfBounds_t39D816E798B19EEB5F689B04AED1854299C0273E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2420[1] = 
{
	OutOfBounds_t39D816E798B19EEB5F689B04AED1854299C0273E::get_offset_of_bottomLeft_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2421 = { sizeof (PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2421[7] = 
{
	PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF::get_offset_of_U3CPlayerNameU3Ek__BackingField_4(),
	PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF::get_offset_of_U3CScoreU3Ek__BackingField_5(),
	PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF::get_offset_of_scoreText_6(),
	PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF::get_offset_of_nameInput_7(),
	PlayerScore_tBD5A594D2AE925522560066A2E6A55F6127C14FF::get_offset_of_submitButton_8(),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2422 = { sizeof (PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2422[9] = 
{
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_playerShipMissileMovement_4(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_playerMissilePosition1_5(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_playerMissilePosition2_6(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_playerExplosionAnimationObject_7(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_boundary_8(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_maxNumMissiles_9(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_currentNumMissiles_10(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_reloadTime_11(),
	PlayerShip_tFD87E5F7047F0DA055206EEFFD15B1B5A000D158::get_offset_of_isReloading_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2423 = { sizeof (U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2423[4] = 
{
	U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496::get_offset_of_U24this_0(),
	U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496::get_offset_of_U24current_1(),
	U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496::get_offset_of_U24disposing_2(),
	U3CReloadNumMissilesU3Ec__Iterator0_tEBB6F5C5B352C279E3B41396E713A35F2B9FC496::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2424 = { sizeof (PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2424[4] = 
{
	PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A::get_offset_of_playerSpeed_4(),
	PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A::get_offset_of_playerPosition_5(),
	PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A::get_offset_of_humbleMovement_6(),
	PlayershipController_tDAF10AEA10FD5B02D76ACDBA26237882E204AC6A::get_offset_of_unityService_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2425 = { sizeof (PlayerShipMissile_tD44491B0A48E697AD01C297474E22B1EE6F18649), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2425[2] = 
{
	PlayerShipMissile_tD44491B0A48E697AD01C297474E22B1EE6F18649::get_offset_of_missileSpeed_4(),
	PlayerShipMissile_tD44491B0A48E697AD01C297474E22B1EE6F18649::get_offset_of_missilePosition_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2426 = { sizeof (Ranking_t387D158090B6D04BF47953B530388C56E96B9810)+ sizeof (RuntimeObject), sizeof(Ranking_t387D158090B6D04BF47953B530388C56E96B9810_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2426[2] = 
{
	Ranking_t387D158090B6D04BF47953B530388C56E96B9810::get_offset_of_name_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Ranking_t387D158090B6D04BF47953B530388C56E96B9810::get_offset_of_score_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2427 = { sizeof (RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2427[7] = 
{
	0,
	0,
	0,
	RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5::get_offset_of_rankingList_7(),
	RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5::get_offset_of_display_8(),
	0,
	RankingManager_tEBE86C24FDA8A947A4ABC7FD598A2A2603E990C5::get_offset_of_averageScore_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2428 = { sizeof (U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2428[6] = 
{
	U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8::get_offset_of_name_0(),
	U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8::get_offset_of_score_1(),
	U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8::get_offset_of_U3CwwwU3E__0_2(),
	U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8::get_offset_of_U24current_3(),
	U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8::get_offset_of_U24disposing_4(),
	U3CUploadScoreU3Ec__Iterator0_t1CDFADC80EB6364A8BCC9FF0E855D69B00951DE8::get_offset_of_U24PC_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2429 = { sizeof (U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE), -1, sizeof(U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2429[6] = 
{
	U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE::get_offset_of_U3CwwwU3E__0_0(),
	U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE::get_offset_of_U24this_1(),
	U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE::get_offset_of_U24current_2(),
	U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE::get_offset_of_U24disposing_3(),
	U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE::get_offset_of_U24PC_4(),
	U3CDownloadRankingsFromDatabaseU3Ec__Iterator1_t2395A532B2B74FBCBB773C6C38117D3EF69B01EE_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2430 = { sizeof (Ring_t82C8E3DF8F89694921DD83C565B90931BB2AE3AF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2430[2] = 
{
	Ring_t82C8E3DF8F89694921DD83C565B90931BB2AE3AF::get_offset_of_velocity_4(),
	Ring_t82C8E3DF8F89694921DD83C565B90931BB2AE3AF::get_offset_of_degree_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2431 = { sizeof (Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2431[4] = 
{
	Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45::get_offset_of_patrolSpeed_4(),
	Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45::get_offset_of_gizmo_5(),
	Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45::get_offset_of_barrierDetected_6(),
	Slicer_tB05C124FF0D195DAF8C8FEBC879772EB8D0F0D45::get_offset_of_info_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2432 = { sizeof (Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2432[7] = 
{
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_audioSource_0(),
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_loop_1(),
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_audio_2(),
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_audioName_3(),
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_audioPitch_4(),
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_audioVolume_5(),
	Sound_t4BEF5956FBCC1B98645BE4F0E8F74E15A07CD30E::get_offset_of_blend_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2433 = { sizeof (SoundManager_tB4134B24E1B190207B84440493F3CF6060F4D4FD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2433[1] = 
{
	SoundManager_tB4134B24E1B190207B84440493F3CF6060F4D4FD::get_offset_of_sounds_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2434 = { sizeof (U3CPlayU3Ec__AnonStorey0_tE9F12C6A82F00C24759129E343897F1556D7A1A4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2434[1] = 
{
	U3CPlayU3Ec__AnonStorey0_tE9F12C6A82F00C24759129E343897F1556D7A1A4::get_offset_of_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2435 = { sizeof (U3CPauseBGMU3Ec__AnonStorey1_t83D3B0F0B349EA8AF19FF21F3B152401F90BF051), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2435[1] = 
{
	U3CPauseBGMU3Ec__AnonStorey1_t83D3B0F0B349EA8AF19FF21F3B152401F90BF051::get_offset_of_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2436 = { sizeof (U3CStopBGMU3Ec__AnonStorey2_tF5F4EBB797E8C73E54C8D29223893FAB467B58C2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2436[1] = 
{
	U3CStopBGMU3Ec__AnonStorey2_tF5F4EBB797E8C73E54C8D29223893FAB467B58C2::get_offset_of_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2437 = { sizeof (U3CPlayOnceU3Ec__AnonStorey3_tA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2437[1] = 
{
	U3CPlayOnceU3Ec__AnonStorey3_tA9C1875DC572BA901AE5B4B43B8CAE8F54EE2F12::get_offset_of_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2438 = { sizeof (SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E), -1, sizeof(SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2438[11] = 
{
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_objectsList_4(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_startTime_5(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_maxSpawnRatePerSecond_6(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_minSpawnRatePerSecond_7(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_timeToIncrease_8(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_playership_9(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_score_10(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_positionOfCamera_11(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_originalWeights_12(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E::get_offset_of_average_13(),
	SpawnManager_t08FCF92BB9C5BB5B82F73FDF8ED596DB591F5A3E_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2439 = { sizeof (SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2439[4] = 
{
	SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC::get_offset_of_x1_4(),
	SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC::get_offset_of_y1_5(),
	SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC::get_offset_of_x2_6(),
	SpawnPoints_tFF4C4240FFAAD87D45F68AE7EB477BCD018436CC::get_offset_of_y2_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2440 = { sizeof (StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2440[4] = 
{
	StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060::get_offset_of_starMove_4(),
	StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060::get_offset_of_maxNumStars_5(),
	StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060::get_offset_of_bottomLeft_6(),
	StarCreator_tE57FC53AD6167BD4B9CBA53ECF27154169702060::get_offset_of_topRight_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2441 = { sizeof (Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2441[4] = 
{
	Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651::get_offset_of_U3CStarSpeedU3Ek__BackingField_4(),
	Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651::get_offset_of_starPosition_5(),
	Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651::get_offset_of_bottomLeft_6(),
	Stars_t17B3C861DA8BBEFC0EDB4439D04F0F8DEC41E651::get_offset_of_topRight_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2442 = { sizeof (Template_t84905F33028DA975E24ED30359B0289BE0D58737), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2442[3] = 
{
	Template_t84905F33028DA975E24ED30359B0289BE0D58737::get_offset_of_rank_4(),
	Template_t84905F33028DA975E24ED30359B0289BE0D58737::get_offset_of_player_5(),
	Template_t84905F33028DA975E24ED30359B0289BE0D58737::get_offset_of_score_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2443 = { sizeof (U3CModuleU3E_t6CDDDF959E7E18A6744E43B613F41CDAC780256A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2444 = { sizeof (DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2444[5] = 
{
	DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54::get_offset_of_session_0(),
	DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54::get_offset_of_method_1(),
	DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54::get_offset_of_upath_2(),
	DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54::get_offset_of_key_3(),
	DriverRequest_tA1CDE9FCC919C41546154F2D8917254371889A54::get_offset_of_value_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2445 = { sizeof (DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2445[5] = 
{
	DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D::get_offset_of_session_0(),
	DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D::get_offset_of_method_1(),
	DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D::get_offset_of_result_2(),
	DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D::get_offset_of_errormessage_3(),
	DriverResponse_tC7A742E830EC85DB946EC52B6FECF22708129B9D::get_offset_of_statuscode_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2446 = { sizeof (ErrorMessages_tC2C6195E8704C009FCC56F8A8E09CE2F6DB02172), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2446[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2447 = { sizeof (ScreenCoordinates_tB5F27E411B2685288432A8C0F450795E3B508AA0), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2447[2] = 
{
	ScreenCoordinates_tB5F27E411B2685288432A8C0F450795E3B508AA0::get_offset_of_X_0(),
	ScreenCoordinates_tB5F27E411B2685288432A8C0F450795E3B508AA0::get_offset_of_Y_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2448 = { sizeof (SessionInfo_t78925ED0E6155BB75F0C07C5082BFEAC4989A14D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2448[1] = 
{
	SessionInfo_t78925ED0E6155BB75F0C07C5082BFEAC4989A14D::get_offset_of_Session_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2449 = { sizeof (CustomDriverHandler_t58C1D7FF0BDE8F720704B1507BFDDC40340FBC52), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2450 = { sizeof (DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07), -1, sizeof(DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2450[6] = 
{
	0,
	DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07::get_offset_of__thread_1(),
	DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07::get_offset_of__client_2(),
	DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07_StaticFields::get_offset_of__instance_3(),
	DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07::get_offset_of_U3CPortU3Ek__BackingField_4(),
	DriverApiClient_tEEDA5DDC66C2A38EE2A3752F737CD1A8E2BE5F07::get_offset_of_U3CIpAddressU3Ek__BackingField_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2451 = { sizeof (DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229), -1, sizeof(DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2451[12] = 
{
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__switchU24map0_0(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_1(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache1_2(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache2_3(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache3_4(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache4_5(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache5_6(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache6_7(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache7_8(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache8_9(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cache9_10(),
	DriverHandler_t32101232D25D40AA9AC96264AF3CD15F9BAB3229_StaticFields::get_offset_of_U3CU3Ef__amU24cacheA_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2452 = { sizeof (U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2452[1] = 
{
	U3CHandleDriverRequestU3Ec__AnonStorey1_tC085566AAFAEB764D7E9BA108D523A3315274885::get_offset_of_request_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2453 = { sizeof (U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2453[3] = 
{
	U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956::get_offset_of_swipeDirection_0(),
	U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956::get_offset_of_path_1(),
	U3CHandleDriverRequestU3Ec__AnonStorey2_tCE7319B26ED709B9C242041243C421F7C5907956::get_offset_of_U3CU3Ef__refU241_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2454 = { sizeof (U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2454[9] = 
{
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_go_0(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_U3CcurrentCoordinatesU3E__0_1(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_dragPointer_2(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_screenCoordinates_3(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_U3CdragDeltaU3E__0_4(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_U3CiU3E__1_5(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_U24current_6(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_U24disposing_7(),
	U3CDragCoroutineU3Ec__Iterator0_t53A0AB6AF394428462610EDBB7215EFF75E3F36D::get_offset_of_U24PC_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2455 = { sizeof (FindGameObjectHelper_t23594A0561F660C38E54C5274FA29A583E319505), -1, sizeof(FindGameObjectHelper_t23594A0561F660C38E54C5274FA29A583E319505_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2455[7] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	FindGameObjectHelper_t23594A0561F660C38E54C5274FA29A583E319505_StaticFields::get_offset_of_U3CU3Ef__switchU24map1_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2456 = { sizeof (InGameApiClientLoader_t4833912E6352D3821206C67C532AD18A7804C32C), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2457 = { sizeof (MainThreadHelper_t6707B844B9B93866058C7DA20936C2FC97AC3451), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2458 = { sizeof (U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2458[4] = 
{
	U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664::get_offset_of_upath_0(),
	U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664::get_offset_of_onComplete_1(),
	U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664::get_offset_of_response_2(),
	U3CExecuteGameObjectEmulationU3Ec__AnonStorey0_tACF40F1EF8A67ED2D09BB276CA060472EC614664::get_offset_of_autoEvent_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2459 = { sizeof (U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2459[4] = 
{
	U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8::get_offset_of_upath_0(),
	U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8::get_offset_of_onComplete_1(),
	U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8::get_offset_of_response_2(),
	U3CExecuteGameObjectsEmulationU3Ec__AnonStorey1_t9A67CF8A13AC21927B7CC4BF1D6D38BB452870C8::get_offset_of_autoEvent_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2460 = { sizeof (U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2460[3] = 
{
	U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D::get_offset_of_action_0(),
	U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D::get_offset_of_response_1(),
	U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey2_tBADFFEE24F735AB5BDAE226B10226E1F5BA0CD8D::get_offset_of_autoEvent_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2461 = { sizeof (U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2461[3] = 
{
	U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8::get_offset_of_action_0(),
	U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8::get_offset_of_response_1(),
	U3CInvokeOnMainThreadAndWaitU3Ec__AnonStorey3_t5F6F0270E8DE0C07ADD590351E8C35FCCBDB81B8::get_offset_of_autoEvent_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2462 = { sizeof (MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919), -1, sizeof(MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2462[3] = 
{
	MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919::get_offset_of_requestedActions_4(),
	MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919::get_offset_of_currentActions_5(),
	MainThreadQueue_t4526AB6279A6E9A202B2082EE3251F2EF93BF919_StaticFields::get_offset_of__instance_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2463 = { sizeof (ScreenHelper_tD87C1BD8FC297CD317C9C76117D8A3F59BABBCDD), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2464 = { sizeof (Logger_t4DECB1CDD98DCFE720C202E15F81C7BDDF662214), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2465 = { sizeof (Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2465[10] = 
{
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_BenchmarkType_4(),
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_TMProFont_5(),
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_TextMeshFont_6(),
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_m_textMeshPro_7(),
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_m_textContainer_8(),
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_m_textMesh_9(),
	0,
	0,
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_m_material01_12(),
	Benchmark01_t375270EB369DC01A4C37A6381970857C4BD87761::get_offset_of_m_material02_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2466 = { sizeof (U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2466[5] = 
{
	U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983::get_offset_of_U3CiU3E__1_0(),
	U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983::get_offset_of_U24this_1(),
	U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983::get_offset_of_U24current_2(),
	U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983::get_offset_of_U24disposing_3(),
	U3CStartU3Ec__Iterator0_t9773F6F451324B5BE08303CA8473793A5A1A0983::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2467 = { sizeof (Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2467[10] = 
{
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_BenchmarkType_4(),
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_canvas_5(),
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_TMProFont_6(),
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_TextMeshFont_7(),
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_m_textMeshPro_8(),
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_m_textMesh_9(),
	0,
	0,
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_m_material01_12(),
	Benchmark01_UGUI_tDD8C13B9B8E4ED9FD1680BAD52CF615726F14B55::get_offset_of_m_material02_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2468 = { sizeof (U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2468[5] = 
{
	U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5::get_offset_of_U3CiU3E__1_0(),
	U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5::get_offset_of_U24this_1(),
	U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5::get_offset_of_U24current_2(),
	U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5::get_offset_of_U24disposing_3(),
	U3CStartU3Ec__Iterator0_tB09B8CA6B313051AC5AB40F7176915D70036EFD5::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2469 = { sizeof (Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2469[3] = 
{
	Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5::get_offset_of_SpawnType_4(),
	Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5::get_offset_of_NumberOfNPC_5(),
	Benchmark02_t5AD0E34D131A57AAA8B39CED7AC8E60946686BB5::get_offset_of_floatingText_Script_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2470 = { sizeof (Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2470[3] = 
{
	Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87::get_offset_of_SpawnType_4(),
	Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87::get_offset_of_NumberOfNPC_5(),
	Benchmark03_tC3AB21ABCF4386EC933960A70AE20001D6D3CD87::get_offset_of_TheFont_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2471 = { sizeof (Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2471[5] = 
{
	Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9::get_offset_of_SpawnType_4(),
	Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9::get_offset_of_MinPointSize_5(),
	Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9::get_offset_of_MaxPointSize_6(),
	Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9::get_offset_of_Steps_7(),
	Benchmark04_t428B8F183784D591AAEAD632C4C56D6C227BD6D9::get_offset_of_m_Transform_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2472 = { sizeof (CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2472[25] = 
{
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_cameraTransform_4(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_dummyTarget_5(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_CameraTarget_6(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_FollowDistance_7(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MaxFollowDistance_8(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MinFollowDistance_9(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_ElevationAngle_10(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MaxElevationAngle_11(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MinElevationAngle_12(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_OrbitalAngle_13(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_CameraMode_14(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MovementSmoothing_15(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_RotationSmoothing_16(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_previousSmoothing_17(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MovementSmoothingValue_18(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_RotationSmoothingValue_19(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_MoveSensitivity_20(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_currentVelocity_21(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_desiredPosition_22(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_mouseX_23(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_mouseY_24(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_moveVector_25(),
	CameraController_t1B35987C4C1AC6395807F1CCC998C5ED956D7911::get_offset_of_mouseWheel_26(),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2473 = { sizeof (CameraModes_t4B24D50582F214FB9AB0B82E700305CB97C9CF9D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2473[4] = 
{
	CameraModes_t4B24D50582F214FB9AB0B82E700305CB97C9CF9D::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2474 = { sizeof (ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2474[3] = 
{
	ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB::get_offset_of_TMP_ChatInput_4(),
	ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB::get_offset_of_TMP_ChatOutput_5(),
	ChatController_t49D7A1D868EED265CD37C4469FAFCF44235384FB::get_offset_of_ChatScrollbar_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2475 = { sizeof (EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2475[3] = 
{
	EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73::get_offset_of_RotationSpeeds_4(),
	EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73::get_offset_of_m_textMeshPro_5(),
	EnvMapAnimator_t32AABBB2CDB4C83E2DE3B1387090D0D7C6B9EF73::get_offset_of_m_material_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2476 = { sizeof (U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2476[5] = 
{
	U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16::get_offset_of_U3CmatrixU3E__0_0(),
	U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16::get_offset_of_U24this_1(),
	U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16::get_offset_of_U24current_2(),
	U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16::get_offset_of_U24disposing_3(),
	U3CStartU3Ec__Iterator0_t49699E552D5107F74192EFBFB84CA9D4390B7E16::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2477 = { sizeof (ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2477[10] = 
{
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_SpinSpeed_4(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_RotationRange_5(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_m_transform_6(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_m_time_7(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_m_prevPOS_8(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_m_initial_Rotation_9(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_m_initial_Position_10(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_m_lightColor_11(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_frames_12(),
	ObjectSpin_t5EEBF4BFCCD478B89C227B8F04670C937B7E10B5::get_offset_of_Motion_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2478 = { sizeof (MotionType_t0B038BCA79B1865C903414BFE3B65AF46B2A6833)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2478[4] = 
{
	MotionType_t0B038BCA79B1865C903414BFE3B65AF46B2A6833::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2479 = { sizeof (ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2479[4] = 
{
	ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72::get_offset_of_m_Renderer_4(),
	ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72::get_offset_of_m_Material_5(),
	ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72::get_offset_of_GlowCurve_6(),
	ShaderPropAnimator_tBD6FBF3230284F283E6BC35E93E5A260853D5A72::get_offset_of_m_frame_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2480 = { sizeof (U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2480[5] = 
{
	U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5::get_offset_of_U3CglowPowerU3E__1_0(),
	U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5::get_offset_of_U24this_1(),
	U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5::get_offset_of_U24current_2(),
	U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5::get_offset_of_U24disposing_3(),
	U3CAnimatePropertiesU3Ec__Iterator0_t46D8DBC8E5800C77BA5D6C76B7983576447A1CF5::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2481 = { sizeof (SimpleScript_tBCE5C1CADFA47423C376344DE84BC0C57CEEC844), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2481[3] = 
{
	SimpleScript_tBCE5C1CADFA47423C376344DE84BC0C57CEEC844::get_offset_of_m_textMeshPro_4(),
	0,
	SimpleScript_tBCE5C1CADFA47423C376344DE84BC0C57CEEC844::get_offset_of_m_frame_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2482 = { sizeof (SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2482[4] = 
{
	SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7::get_offset_of_m_TextComponent_4(),
	SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7::get_offset_of_VertexCurve_5(),
	SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7::get_offset_of_CurveScale_6(),
	SkewTextExample_t593F30AC17BCC5AC48767730079C01C081EB5DE7::get_offset_of_ShearAmount_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2483 = { sizeof (U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2483[13] = 
{
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3Cold_CurveScaleU3E__0_0(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3Cold_ShearValueU3E__0_1(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3Cold_curveU3E__0_2(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3CtextInfoU3E__1_3(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3CcharacterCountU3E__1_4(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3CboundsMinXU3E__1_5(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3CboundsMaxXU3E__1_6(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3CverticesU3E__2_7(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U3CmatrixU3E__2_8(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U24this_9(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U24current_10(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U24disposing_11(),
	U3CWarpTextU3Ec__Iterator0_t0275814BC3ED63C685B86286D7DD936B90EC71AA::get_offset_of_U24PC_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2484 = { sizeof (TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2484[3] = 
{
	TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716::get_offset_of_label01_4(),
	TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716::get_offset_of_label02_5(),
	TeleType_tD2F8D2B74053727BA68E58C7CD70CBD8AD9D2716::get_offset_of_m_textMeshPro_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2485 = { sizeof (U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2485[7] = 
{
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U3CtotalVisibleCharactersU3E__0_0(),
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U3CcounterU3E__0_1(),
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U3CvisibleCountU3E__0_2(),
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U24this_3(),
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U24current_4(),
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U24disposing_5(),
	U3CStartU3Ec__Iterator0_t438726BF18FBCABCE5555E618B5A5B0DE934B94A::get_offset_of_U24PC_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2486 = { sizeof (TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2486[2] = 
{
	TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163::get_offset_of_m_TextComponent_4(),
	TextConsoleSimulator_t259F9E6207B0D6762776D957F966754564B55163::get_offset_of_hasTextChanged_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2487 = { sizeof (U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2487[8] = 
{
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_textComponent_0(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U3CtextInfoU3E__0_1(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U3CtotalVisibleCharactersU3E__0_2(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U3CvisibleCountU3E__0_3(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U24this_4(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U24current_5(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U24disposing_6(),
	U3CRevealCharactersU3Ec__Iterator0_tE4A39B5FABDABB7BB85C935C9E234676154219D8::get_offset_of_U24PC_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2488 = { sizeof (U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2488[9] = 
{
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_textComponent_0(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U3CtotalWordCountU3E__0_1(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U3CtotalVisibleCharactersU3E__0_2(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U3CcounterU3E__0_3(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U3CcurrentWordU3E__0_4(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U3CvisibleCountU3E__0_5(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U24current_6(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U24disposing_7(),
	U3CRevealWordsU3Ec__Iterator1_tA0378C234D4F01B254D8F9900BD8D00AA238D49D::get_offset_of_U24PC_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2489 = { sizeof (TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2489[10] = 
{
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_TheFont_4(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_m_floatingText_5(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_m_textMeshPro_6(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_m_textMesh_7(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_m_transform_8(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_m_floatingText_Transform_9(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_m_cameraTransform_10(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_lastPOS_11(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_lastRotation_12(),
	TextMeshProFloatingText_tD52C5B081FC480F24349C2C0F5099F0693EEC913::get_offset_of_SpawnType_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2490 = { sizeof (U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2490[12] = 
{
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3CCountDurationU3E__0_0(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3Cstarting_CountU3E__0_1(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3Ccurrent_CountU3E__0_2(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3Cstart_posU3E__0_3(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3Cstart_colorU3E__0_4(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3CalphaU3E__0_5(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3Cint_counterU3E__0_6(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U3CfadeDurationU3E__0_7(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U24this_8(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U24current_9(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U24disposing_10(),
	U3CDisplayTextMeshProFloatingTextU3Ec__Iterator0_t4B346781A46C6DD8AE230D0664D0282888DC6913::get_offset_of_U24PC_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2491 = { sizeof (U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2491[12] = 
{
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3CCountDurationU3E__0_0(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3Cstarting_CountU3E__0_1(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3Ccurrent_CountU3E__0_2(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3Cstart_posU3E__0_3(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3Cstart_colorU3E__0_4(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3CalphaU3E__0_5(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3Cint_counterU3E__0_6(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U3CfadeDurationU3E__0_7(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U24this_8(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U24current_9(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U24disposing_10(),
	U3CDisplayTextMeshFloatingTextU3Ec__Iterator1_t8B35D925CB51BFBD52D30048DB0DCAC27D2CB71E::get_offset_of_U24PC_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2492 = { sizeof (TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2492[4] = 
{
	TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686::get_offset_of_SpawnType_4(),
	TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686::get_offset_of_NumberOfNPC_5(),
	TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686::get_offset_of_TheFont_6(),
	TextMeshSpawner_t7A50739A3F9750469C9F130607DA20D66CA22686::get_offset_of_floatingText_Script_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2493 = { sizeof (TMP_DigitValidator_tD53B3EF123D04F923055895ED56555317D239AB5), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2494 = { sizeof (TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2494[5] = 
{
	TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8::get_offset_of_ObjectType_4(),
	TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8::get_offset_of_isStatic_5(),
	TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8::get_offset_of_m_text_6(),
	0,
	TMP_ExampleScript_01_t4208AD096DD4FCE676E1EE1FA3F4DFD6341D81A8::get_offset_of_count_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2495 = { sizeof (objectType_t4A9206B564B1134F55E176CB1D6A831B7F2CD0BE)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2495[3] = 
{
	objectType_t4A9206B564B1134F55E176CB1D6A831B7F2CD0BE::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2496 = { sizeof (TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2496[10] = 
{
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_UpdateInterval_4(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_m_LastInterval_5(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_m_Frames_6(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_AnchorPosition_7(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_htmlColorTag_8(),
	0,
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_m_TextMeshPro_10(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_m_frameCounter_transform_11(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_m_camera_12(),
	TMP_FrameRateCounter_t154205AC6610245B31CEF1C182FA4B4862D9D07F::get_offset_of_last_AnchorPosition_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2497 = { sizeof (FpsCounterAnchorPositions_tF97255C7539822AFCA3511F3C0C4E6803A11EA97)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2497[5] = 
{
	FpsCounterAnchorPositions_tF97255C7539822AFCA3511F3C0C4E6803A11EA97::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2498 = { sizeof (TMP_PhoneNumberValidator_t7EB41CFDB7C6AA586BF5AF04151FC2228F565BD2), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2499 = { sizeof (TMP_TextEventCheck_t5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2499[1] = 
{
	TMP_TextEventCheck_t5AF390C2FFBE0FBCFA4F905503A504F5DD891CAB::get_offset_of_TextEventHandler_4(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
